require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// ── Alpaca credentials from .env ──
const ALPACA_KEY    = process.env.ALPACA_KEY_ID;
const ALPACA_SECRET = process.env.ALPACA_SECRET_KEY;
const DATA_URL      = process.env.ALPACA_DATA_URL || 'https://data.alpaca.markets/v2';

const HEADERS = {
  'APCA-API-KEY-ID':     ALPACA_KEY,
  'APCA-API-SECRET-KEY': ALPACA_SECRET,
  'Accept':              'application/json'
};

// ── Simple in-memory cache (avoid hammering Alpaca on 3s frontend polling) ──
const indicatorCache = {};  // { 'AAPL': { data: {...}, ts: Date.now() } }
const CACHE_TTL = 30000;    // 30 seconds — 5min bars don't change faster than this

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// ════════════════════════════════════════════════════════
// TECHNICAL INDICATOR MATH
// ════════════════════════════════════════════════════════

function emaCalc(data, period) {
  const k = 2 / (period + 1);
  const result = [data[0]];
  for (let i = 1; i < data.length; i++) {
    result.push(data[i] * k + result[i - 1] * (1 - k));
  }
  return result;
}

function smaCalc(data, period) {
  const result = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) { result.push(null); continue; }
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += data[j];
    result.push(sum / period);
  }
  return result;
}

function calcRSI(closes, period = 14) {
  if (closes.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) gains += diff; else losses -= diff;
  }
  let avgGain = gains / period;
  let avgLoss = losses / period;
  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    avgGain = (avgGain * (period - 1) + (diff > 0 ? diff : 0)) / period;
    avgLoss = (avgLoss * (period - 1) + (diff < 0 ? -diff : 0)) / period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function calcMACD(closes) {
  if (closes.length < 26) return { line: 0, signal: 0, hist: 0 };
  const ema12 = emaCalc(closes, 12);
  const ema26 = emaCalc(closes, 26);
  const macdLine = ema12.map((v, i) => v - ema26[i]);
  const signalLine = emaCalc(macdLine, 9);
  const last = closes.length - 1;
  return {
    line: macdLine[last],
    signal: signalLine[last],
    hist: macdLine[last] - signalLine[last]
  };
}

function calcADX(highs, lows, closes, period = 14) {
  if (highs.length < period * 2) return 20;
  const trueRanges = [], plusDM = [], minusDM = [];
  for (let i = 1; i < highs.length; i++) {
    const hl = highs[i] - lows[i];
    const hpc = Math.abs(highs[i] - closes[i - 1]);
    const lpc = Math.abs(lows[i] - closes[i - 1]);
    trueRanges.push(Math.max(hl, hpc, lpc));
    const upMove = highs[i] - highs[i - 1];
    const downMove = lows[i - 1] - lows[i];
    plusDM.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDM.push(downMove > upMove && downMove > 0 ? downMove : 0);
  }
  let atr = trueRanges.slice(0, period).reduce((a, b) => a + b, 0);
  let aPlusDM = plusDM.slice(0, period).reduce((a, b) => a + b, 0);
  let aMinusDM = minusDM.slice(0, period).reduce((a, b) => a + b, 0);
  const dxValues = [];
  for (let i = period; i < trueRanges.length; i++) {
    atr = atr - atr / period + trueRanges[i];
    aPlusDM = aPlusDM - aPlusDM / period + plusDM[i];
    aMinusDM = aMinusDM - aMinusDM / period + minusDM[i];
    const plusDI = (aPlusDM / atr) * 100;
    const minusDI = (aMinusDM / atr) * 100;
    const diSum = plusDI + minusDI;
    dxValues.push(diSum === 0 ? 0 : Math.abs(plusDI - minusDI) / diSum * 100);
  }
  if (dxValues.length < period) return dxValues.length > 0 ? dxValues[dxValues.length - 1] : 20;
  let adx = dxValues.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < dxValues.length; i++) {
    adx = (adx * (period - 1) + dxValues[i]) / period;
  }
  return adx;
}

function calcStochastic(highs, lows, closes, kPeriod = 14, dPeriod = 3) {
  if (closes.length < kPeriod) return { k: 50, d: 50 };
  const kValues = [];
  for (let i = kPeriod - 1; i < closes.length; i++) {
    const highSlice = highs.slice(i - kPeriod + 1, i + 1);
    const lowSlice = lows.slice(i - kPeriod + 1, i + 1);
    const hh = Math.max(...highSlice);
    const ll = Math.min(...lowSlice);
    kValues.push(hh === ll ? 50 : ((closes[i] - ll) / (hh - ll)) * 100);
  }
  const dValues = smaCalc(kValues, dPeriod);
  return {
    k: Math.round(kValues[kValues.length - 1]),
    d: Math.round(dValues[dValues.length - 1] || kValues[kValues.length - 1])
  };
}

function calcVWAP(highs, lows, closes, volumes) {
  let cumVol = 0, cumTP = 0;
  for (let i = 0; i < closes.length; i++) {
    const tp = (highs[i] + lows[i] + closes[i]) / 3;
    cumVol += volumes[i];
    cumTP += tp * volumes[i];
  }
  return cumVol === 0 ? closes[closes.length - 1] : cumTP / cumVol;
}

// ════════════════════════════════════════════════════════
// FETCH BARS FROM ALPACA
// ════════════════════════════════════════════════════════

async function fetchBars(symbol, timeframe = '5Min', limit = 200) {
  // Calculate start date: go back enough calendar days to cover the requested bars
  const now = new Date();
  let daysBack = 10; // default for 5min (covers weekends + holidays)
  if (timeframe === '1Hour') daysBack = 30;
  if (timeframe === '1Day')  daysBack = 365;
  const start = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
  const startISO = start.toISOString();

  // Use sort=desc to get the LATEST bars first, then reverse for chronological order
  const url = `${DATA_URL}/stocks/${symbol}/bars?timeframe=${timeframe}&limit=${limit}&start=${startISO}&adjustment=raw&sort=desc`;
  console.log(`[fetchBars] ${symbol} ${timeframe} limit=${limit}`);

  // Retry with backoff on 429 (rate limit)
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(url, { headers: HEADERS });
    if (res.status === 429) {
      const wait = (attempt + 1) * 1500; // 1.5s, 3s, 4.5s
      console.log(`[fetchBars] ${symbol} ${timeframe} → 429 rate limited, retrying in ${wait}ms...`);
      await new Promise(r => setTimeout(r, wait));
      continue;
    }
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Alpaca API error ${res.status}: ${errText}`);
    }
    const data = await res.json();
    const bars = (data.bars || []).reverse(); // oldest → newest for indicator math
    console.log(`[fetchBars] ${symbol} ${timeframe} → ${bars.length} bars (latest: ${bars.length ? bars[bars.length-1].t : 'none'})`);
    return bars;
  }
  throw new Error('Rate limited after 3 retries');
}

// ════════════════════════════════════════════════════════
// API: GET /api/indicators/:symbol
// ════════════════════════════════════════════════════════

app.get('/api/indicators/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol.toUpperCase();

    // Timeframe from query: 1, 5, 15, 30, 60, 240 (minutes)
    const tfMinutes = parseInt(req.query.tf) || 5;
    const tfMap = { 1: '1Min', 5: '5Min', 15: '15Min', 30: '30Min', 60: '1Hour', 240: '4Hour' };
    const alpacaTF = tfMap[tfMinutes] || '5Min';
    // How many bars to fetch (more for smaller timeframes)
    const barLimit = tfMinutes <= 5 ? 500 : tfMinutes <= 30 ? 300 : 500;
    // Days back for start date
    const daysBack = tfMinutes <= 5 ? 10 : tfMinutes <= 30 ? 20 : 60;
    // HTF for trend analysis (one step above selected tf)
    const htfTFMap = { 1: '5Min', 5: '1Hour', 15: '1Hour', 30: '1Hour', 60: '4Hour', 240: '1Day' };
    const htfTF = htfTFMap[tfMinutes] || '1Hour';

    console.log(`[API] ${symbol} tf=${tfMinutes}min → bars=${alpacaTF}, htf=${htfTF}`);

    // Check cache (key includes timeframe)
    const cacheKey = `${symbol}_${tfMinutes}`;
    const cached = indicatorCache[cacheKey];
    if (cached && (Date.now() - cached.ts) < CACHE_TTL) {
      return res.json(cached.data);
    }

    const [rawBars, htfBars] = await Promise.all([
      fetchBars(symbol, alpacaTF, barLimit),
      fetchBars(symbol, htfTF, 100)
    ]);

    // ── Filter to Regular Trading Hours only (9:30 AM – 4:00 PM ET) ──
    // Extended hours bars have near-zero movement which corrupts ADX/RSI/MACD
    const bars5m = rawBars.filter(b => {
      const d = new Date(b.t);
      // Convert UTC → ET (EST = UTC-5, EDT = UTC-4)
      // Use simple approach: check if US daylight saving is active
      const month = d.getUTCMonth(); // 0-indexed
      const isDST = month >= 2 && month <= 10; // Mar-Nov rough DST
      const etHour = d.getUTCHours() - (isDST ? 4 : 5);
      const etMin  = d.getUTCMinutes();
      const etTime = etHour + etMin / 60;
      // RTH = 9:30 AM (9.5) to 4:00 PM (16.0) ET
      return etTime >= 9.5 && etTime < 16;
    });

    console.log(`[RTH filter] ${symbol} ${alpacaTF}: ${rawBars.length} raw → ${bars5m.length} RTH bars`);

    if (!bars5m.length) {
      return res.json({ error: 'No regular-hours bar data available. Market may be closed.', stale: true });
    }

    const highs   = bars5m.map(b => b.h);
    const lows    = bars5m.map(b => b.l);
    const closes  = bars5m.map(b => b.c);
    const volumes = bars5m.map(b => b.v);

    const lastPrice = closes[closes.length - 1];
    const lastBar   = bars5m[bars5m.length - 1];

    // ── Compute indicators ──
    const rsi       = calcRSI(closes, 14);
    const macd      = calcMACD(closes);
    const stoch     = calcStochastic(highs, lows, closes, 14, 3);
    const vwap      = calcVWAP(highs, lows, closes, volumes);
    const ema9vals  = emaCalc(closes, 9);
    const ema21vals = emaCalc(closes, 21);
    const ema9      = ema9vals[ema9vals.length - 1];
    const ema21     = ema21vals[ema21vals.length - 1];

    // ── ADX from the SAME timeframe bars (so it changes per TF selection) ──
    let adx = 20; // default
    if (highs.length >= 30) {
      adx = calcADX(highs, lows, closes, 14);
    }
    console.log(`[Indicators] ${symbol}: ADX(${alpacaTF})=${adx.toFixed(1)} RSI=${rsi.toFixed(1)} MACD=${macd.hist.toFixed(4)}`);

    // Volume ratio
    const recentVols = volumes.slice(-20);
    const avgVol = recentVols.reduce((a, b) => a + b, 0) / recentVols.length;
    const lastVol = volumes[volumes.length - 1];
    const volRatio = avgVol > 0 ? lastVol / avgVol : 1;
    const volIncreasing = volumes.length >= 3 && volumes[volumes.length - 1] > volumes[volumes.length - 2];

    // ── ATR (Average True Range) — realistic stop/target sizing per timeframe ──
    let atr = 0;
    if (highs.length >= 3) {
      const trList = [];
      for (let i = 1; i < highs.length; i++) {
        const tr = Math.max(
          highs[i] - lows[i],
          Math.abs(highs[i] - closes[i - 1]),
          Math.abs(lows[i] - closes[i - 1])
        );
        trList.push(tr);
      }
      // ATR-14: smoothed average (or simple average if fewer bars)
      const atrPeriod = Math.min(14, trList.length);
      let atrSum = trList.slice(0, atrPeriod).reduce((a, b) => a + b, 0);
      let atrVal = atrSum / atrPeriod;
      for (let i = atrPeriod; i < trList.length; i++) {
        atrVal = (atrVal * (atrPeriod - 1) + trList[i]) / atrPeriod;
      }
      atr = atrVal;
    }
    // Suggested stop = 1.5 × ATR (tight enough for the timeframe, wide enough to avoid noise)
    const suggestedStop = +(atr * 1.5).toFixed(2);
    // Suggested targets: T1 = 1.5×ATR (1:1), T2 = 3×ATR (2:1)
    const suggestedT1   = +(atr * 1.5).toFixed(2);
    const suggestedT2   = +(atr * 3.0).toFixed(2);
    console.log(`[ATR] ${symbol} ${alpacaTF}: ATR=${atr.toFixed(4)} → stop=$${suggestedStop} t1=$${suggestedT1} t2=$${suggestedT2}`);

    // Candle analysis
    const bodySize = Math.abs(lastBar.c - lastBar.o);
    const totalRange = lastBar.h - lastBar.l;
    const strongCandle = totalRange > 0 && (bodySize / totalRange) > 0.5;
    const bullCandle = lastBar.c > lastBar.o;

    // Opening Range (first 30 min of the most recent trading day)
    // Group bars by date, pick the latest date
    const barsByDate = {};
    bars5m.forEach(b => {
      const dateKey = b.t.slice(0, 10);
      if (!barsByDate[dateKey]) barsByDate[dateKey] = [];
      barsByDate[dateKey].push(b);
    });
    const tradingDates = Object.keys(barsByDate).sort();
    const latestDate = tradingDates[tradingDates.length - 1];
    const latestDayBars = barsByDate[latestDate] || [];
    // Number of bars in 30-min OR depends on timeframe
    const orBarCount = Math.max(1, Math.ceil(30 / tfMinutes));
    const orBars = latestDayBars.slice(0, orBarCount);
    let orHigh, orLow;
    if (orBars.length > 0) {
      orHigh = Math.max(...orBars.map(b => b.h));
      orLow  = Math.min(...orBars.map(b => b.l));
    } else {
      orHigh = lastPrice + 1;
      orLow  = lastPrice - 1;
    }

    // HTF analysis (using higher timeframe bars)
    let htfBull = true;
    if (htfBars.length >= 21) {
      const htfCloses1h = htfBars.map(b => b.c);
      const htfEma9  = emaCalc(htfCloses1h, 9);
      const htfEma21 = emaCalc(htfCloses1h, 21);
      htfBull = htfEma9[htfEma9.length - 1] > htfEma21[htfEma21.length - 1];
    }

    // Consolidation check
    const last5 = bars5m.slice(-5);
    const last5Range = Math.max(...last5.map(b => b.h)) - Math.min(...last5.map(b => b.l));
    const avgRange = bars5m.slice(-20).reduce((s, b) => s + (b.h - b.l), 0) / 20;
    const consolidated = last5Range < avgRange * 2.5;

    // RSI divergence
    let divergence = false;
    if (closes.length >= 24) {
      const rsiNow  = calcRSI(closes, 14);
      const rsiBack = calcRSI(closes.slice(0, -10), 14);
      const priceNow  = closes[closes.length - 1];
      const priceBack = closes[closes.length - 11];
      if (priceNow > priceBack && rsiNow < rsiBack - 5) divergence = true;
      if (priceNow < priceBack && rsiNow > rsiBack + 5) divergence = true;
    }

    // ── ADX thresholds scale with timeframe (lower TFs have naturally lower ADX) ──
    const adxThresholds = {
      1:   { low: 8,  high: 15 },
      5:   { low: 10, high: 18 },
      15:  { low: 11, high: 20 },
      30:  { low: 12, high: 22 },
      60:  { low: 15, high: 25 },
      240: { low: 18, high: 30 }
    };
    const adxTH = adxThresholds[tfMinutes] || { low: 15, high: 25 };

    // ── Determine mode ──
    const vwapAbove = lastPrice > vwap;
    const emaBull = ema9 > ema21;
    const macdBull = macd.hist > 0;

    let mode = 'wait';
    const bullSignals = [vwapAbove, emaBull, macdBull, rsi > 50, adx >= adxTH.low].filter(Boolean).length;
    const bearSignals = [!vwapAbove, !emaBull, !macdBull, rsi < 50, adx >= adxTH.low].filter(Boolean).length;

    if (adx < adxTH.low) {
      mode = 'dead';
    } else if (bullSignals >= 4 && lastPrice > orHigh) {
      mode = 'long';
    } else if (bearSignals >= 4) {
      mode = 'short';
    }

    const result = {
      symbol,
      timeframe: tfMinutes,
      lastPrice: +lastPrice.toFixed(2),
      timestamp: lastBar.t,
      stale: false,
      mode,
      adxThresholds: adxTH,
      atr:           +atr.toFixed(4),
      suggestedStop: suggestedStop,
      suggestedT1:   suggestedT1,
      suggestedT2:   suggestedT2,
      indicators: {
        adx:         +adx.toFixed(1),
        rsi:         +rsi.toFixed(1),
        macdBull,
        macdHist:    +macd.hist.toFixed(4),
        macdLine:    +macd.line.toFixed(4),
        macdSignal:  +macd.signal.toFixed(4),
        stochK:      stoch.k,
        stochD:      stoch.d,
        vwapAbove,
        vwapVal:     +vwap.toFixed(2),
        emaBull,
        ema9:        +ema9.toFixed(2),
        ema21:       +ema21.toFixed(2),
        volume:      +volRatio.toFixed(2),
        volInc:      volIncreasing,
        strongCandle,
        bullCandle,
        htfBull,
        consolidated,
        divergence,
        orHigh:      +orHigh.toFixed(2),
        orLow:       +orLow.toFixed(2)
      }
    };

    // Cache the result (keyed by symbol+timeframe)
    indicatorCache[cacheKey] = { data: result, ts: Date.now() };
    res.json(result);

  } catch (err) {
    console.error('Indicator API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
// API: GET /api/bars/:symbol — raw OHLCV + RSI + SMA for charting
// ════════════════════════════════════════════════════════
const barsCache = {};
const BARS_CACHE_TTL = 10000;  // 10s — keep main chart responsive during market hours

app.get('/api/bars/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol.toUpperCase();
    const tfMinutes = parseInt(req.query.tf) || 5;
    const tfMap = { 1:'1Min', 5:'5Min', 15:'15Min', 30:'30Min', 60:'1Hour', 240:'4Hour' };
    const alpacaTF = tfMap[tfMinutes] || '5Min';
    // More bars for lower TFs to get enough multi-day data after RTH filter
    const barLimit = tfMinutes <= 1 ? 500 : tfMinutes <= 5 ? 500 : tfMinutes <= 15 ? 400 : 200;
    const daysBack = tfMinutes <= 1 ? 5 : tfMinutes <= 5 ? 10 : tfMinutes <= 60 ? 60 : 365;

    const cacheKey = `bars_${symbol}_${tfMinutes}`;
    const cached = barsCache[cacheKey];
    if (cached && (Date.now() - cached.ts) < BARS_CACHE_TTL) {
      return res.json(cached.data);
    }

    const now = new Date();
    const start = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
    const url = `${DATA_URL}/stocks/${symbol}/bars?timeframe=${alpacaTF}&limit=${barLimit}&start=${start.toISOString()}&adjustment=raw&sort=desc`;
    const apiRes = await fetch(url, { headers: HEADERS });
    if (!apiRes.ok) throw new Error(`Alpaca ${apiRes.status}`);
    const raw = await apiRes.json();
    const bars = (raw.bars || []).reverse();

    // Filter RTH
    const rthBars = bars.filter(b => {
      const d = new Date(b.t);
      const month = d.getUTCMonth();
      const isDST = month >= 2 && month <= 10;
      const etHour = d.getUTCHours() - (isDST ? 4 : 5);
      const etMin  = d.getUTCMinutes();
      const etTime = etHour + etMin / 60;
      return etTime >= 9.5 && etTime < 16;
    });

    if (!rthBars.length) {
      return res.json({ bars: [], rsi: [], sma20: [], sma9: [], vwap: [], macdLine: [], macdSignal: [], macdHist: [] });
    }

    const closes  = rthBars.map(b => b.c);
    const highs   = rthBars.map(b => b.h);
    const lows    = rthBars.map(b => b.l);
    const volumes = rthBars.map(b => b.v);

    // RSI series (14-period, for each bar)
    const rsiSeries = [];
    for (let i = 0; i < closes.length; i++) {
      if (i < 14) { rsiSeries.push(null); continue; }
      const slice = closes.slice(0, i + 1);
      rsiSeries.push(+calcRSI(slice, 14).toFixed(1));
    }

    // SMA-9 and SMA-20 series
    const sma9  = smaCalc(closes, 9).map(v => v !== null ? +v.toFixed(2) : null);
    const sma20 = smaCalc(closes, 20).map(v => v !== null ? +v.toFixed(2) : null);

    // ── VWAP series (resets each trading day for intraday TFs, continuous for higher TFs) ──
    const vwapSeries = [];
    let vCumVol = 0, vCumTP = 0, prevDate = '';
    const resetVwapDaily = tfMinutes <= 30;  // only reset VWAP daily for ≤30min TFs
    for (let i = 0; i < rthBars.length; i++) {
      if (resetVwapDaily) {
        const dateKey = rthBars[i].t.slice(0, 10);
        if (dateKey !== prevDate) { vCumVol = 0; vCumTP = 0; prevDate = dateKey; }
      }
      const tp = (highs[i] + lows[i] + closes[i]) / 3;
      vCumVol += volumes[i];
      vCumTP  += tp * volumes[i];
      vwapSeries.push(vCumVol === 0 ? +closes[i].toFixed(2) : +(vCumTP / vCumVol).toFixed(2));
    }

    // ── MACD series (12, 26, 9) ──
    const ema12 = emaCalc(closes, 12);
    const ema26 = emaCalc(closes, 26);
    const macdLineArr = ema12.map((v, i) => v - ema26[i]);
    const macdSignalArr = emaCalc(macdLineArr, 9);
    const macdLineSeries   = macdLineArr.map(v => +v.toFixed(4));
    const macdSignalSeries = macdSignalArr.map(v => +v.toFixed(4));
    const macdHistSeries   = macdLineArr.map((v, i) => +((v - macdSignalArr[i]).toFixed(4)));

    // Format bars for lightweight-charts
    // Use sequential business-time to eliminate overnight/weekend gaps
    // Strategy: keep timestamps within each day, but stitch days together seamlessly
    const chartBars = [];
    let prevDayEnd = null;
    const intervalSec = tfMinutes * 60;
    
    for (let i = 0; i < rthBars.length; i++) {
      const b = rthBars[i];
      const realTime = Math.floor(new Date(b.t).getTime() / 1000);
      
      let chartTime;
      if (i === 0) {
        chartTime = realTime;
      } else {
        const prevTime = chartBars[i - 1].time;
        const gap = realTime - Math.floor(new Date(rthBars[i - 1].t).getTime() / 1000);
        
        // If gap is larger than 2x the interval, it's an overnight/weekend gap — compress it
        if (gap > intervalSec * 2) {
          chartTime = prevTime + intervalSec;  // just advance by 1 bar width
        } else {
          chartTime = prevTime + gap;  // keep natural spacing within the day
        }
      }
      
      chartBars.push({
        time: chartTime,
        open: +b.o.toFixed(2),
        high: +b.h.toFixed(2),
        low:  +b.l.toFixed(2),
        close: +b.c.toFixed(2),
        volume: b.v,
        realTime: b.t  // keep original for tooltip reference
      });
    }

    const result = { bars: chartBars, rsi: rsiSeries, sma9, sma20, vwap: vwapSeries, macdLine: macdLineSeries, macdSignal: macdSignalSeries, macdHist: macdHistSeries };
    barsCache[cacheKey] = { data: result, ts: Date.now() };
    res.json(result);
  } catch (err) {
    console.error('Bars API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
// API: GET /api/bars-all/:symbol — ALL 6 TFs in one response (for synced MTF charts)
// ════════════════════════════════════════════════════════
const ALL_TFS = [1, 5, 15, 30, 60, 240];

app.get('/api/bars-all/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol.toUpperCase();
    const tfMap = { 1:'1Min', 5:'5Min', 15:'15Min', 30:'30Min', 60:'1Hour', 240:'4Hour' };

    // Fetch all 6 TFs in parallel (use cache where available)
    const results = {};
    await Promise.all(ALL_TFS.map(async (tfMin) => {
      const cacheKey = `bars_${symbol}_${tfMin}`;
      const cached = barsCache[cacheKey];
      if (cached && (Date.now() - cached.ts) < BARS_CACHE_TTL) {
        results[tfMin] = cached.data;
        return;
      }

      const alpacaTF = tfMap[tfMin];
      const barLimit = tfMin <= 1 ? 500 : tfMin <= 5 ? 500 : tfMin <= 15 ? 400 : 200;
      const daysBack = tfMin <= 1 ? 5 : tfMin <= 5 ? 10 : tfMin <= 60 ? 60 : 365;
      const now = new Date();
      const start = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
      const url = `${DATA_URL}/stocks/${symbol}/bars?timeframe=${alpacaTF}&limit=${barLimit}&start=${start.toISOString()}&adjustment=raw&sort=desc`;

      try {
        const apiRes = await fetch(url, { headers: HEADERS });
        if (!apiRes.ok) { results[tfMin] = { bars: [], rsi: [], sma9: [], sma20: [] }; return; }
        const raw = await apiRes.json();
        const bars = (raw.bars || []).reverse();

        const rthBars = bars.filter(b => {
          const d = new Date(b.t);
          const month = d.getUTCMonth();
          const isDST = month >= 2 && month <= 10;
          const etHour = d.getUTCHours() - (isDST ? 4 : 5);
          const etMin  = d.getUTCMinutes();
          const etTime = etHour + etMin / 60;
          return etTime >= 9.5 && etTime < 16;
        });

        if (!rthBars.length) { results[tfMin] = { bars: [], rsi: [], sma9: [], sma20: [] }; return; }

        const closes = rthBars.map(b => b.c);
        const rsiSeries = [];
        for (let i = 0; i < closes.length; i++) {
          if (i < 14) { rsiSeries.push(null); continue; }
          rsiSeries.push(+calcRSI(closes.slice(0, i + 1), 14).toFixed(1));
        }
        const sma9  = smaCalc(closes, 9).map(v => v !== null ? +v.toFixed(2) : null);
        const sma20 = smaCalc(closes, 20).map(v => v !== null ? +v.toFixed(2) : null);

        const chartBars = [];
        const intervalSec = tfMin * 60;
        for (let i = 0; i < rthBars.length; i++) {
          const b = rthBars[i];
          const realTime = Math.floor(new Date(b.t).getTime() / 1000);
          let chartTime;
          if (i === 0) { chartTime = realTime; }
          else {
            const prevTime = chartBars[i - 1].time;
            const gap = realTime - Math.floor(new Date(rthBars[i - 1].t).getTime() / 1000);
            chartTime = gap > intervalSec * 2 ? prevTime + intervalSec : prevTime + gap;
          }
          chartBars.push({ time: chartTime, open: +b.o.toFixed(2), high: +b.h.toFixed(2), low: +b.l.toFixed(2), close: +b.c.toFixed(2), volume: b.v });
        }

        const tfResult = { bars: chartBars, rsi: rsiSeries, sma9, sma20 };
        barsCache[cacheKey] = { data: tfResult, ts: Date.now() };
        results[tfMin] = tfResult;
      } catch (e) {
        results[tfMin] = { bars: [], rsi: [], sma9: [], sma20: [] };
      }
    }));

    res.json(results);
  } catch (err) {
    console.error('Bars-all API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
// API: GET /api/snapshot/:symbol — real-time price from Alpaca latest trade + minuteBar
// No caching — this must be as fresh as possible
// ════════════════════════════════════════════════════════
app.get('/api/snapshot/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol.toUpperCase();
    const url = `${DATA_URL}/stocks/${symbol}/snapshot`;
    const apiRes = await fetch(url, { headers: HEADERS });
    if (!apiRes.ok) throw new Error(`Alpaca snapshot ${apiRes.status}`);
    const snap = await apiRes.json();

    const trade = snap.latestTrade || {};
    const mBar  = snap.minuteBar || {};
    const dBar  = snap.dailyBar || {};
    const prevDBar = snap.prevDailyBar || {};

    res.json({
      symbol,
      price:     trade.p || mBar.c || 0,
      tradeTime: trade.t || null,
      minuteBar: mBar.t ? {
        time: mBar.t,
        open: mBar.o, high: mBar.h, low: mBar.l, close: mBar.c, volume: mBar.v
      } : null,
      dailyBar: dBar.t ? {
        open: dBar.o, high: dBar.h, low: dBar.l, close: dBar.c, volume: dBar.v
      } : null,
      prevClose: prevDBar.c || null,
    });
  } catch (err) {
    console.error('Snapshot API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
// API: GET /api/scan?symbols=AAPL,TSLA,NVDA&tf=5
// ADVANCED SCANNER — weighted scoring, multi-TF alignment, relative strength, alerts
// ════════════════════════════════════════════════════════
const DEFAULT_SCAN_LIST = ['SPY','QQQ','AAPL','TSLA','NVDA','AMD','MSFT','AMZN','META','GOOG','NFLX','BA','JPM','V','COIN'];

// Track previous scan for alert detection + signal hysteresis
let prevScanResults = {};
// Scan cache: avoid hammering API on 30s refreshes (cache for 25s)
let scanCache = { data: null, key: '', ts: 0 };
const SCAN_CACHE_TTL = 25000; // 25 seconds

app.get('/api/scan', async (req, res) => {
  try {
    const symbolsRaw = req.query.symbols || DEFAULT_SCAN_LIST.join(',');
    const symbols = symbolsRaw.split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
    const tfMinutes = parseInt(req.query.tf) || 5;

    // Return cached result if same symbols/tf and fresh enough
    const cacheKey = symbols.join(',') + ':' + tfMinutes;
    if (scanCache.data && scanCache.key === cacheKey && (Date.now() - scanCache.ts) < SCAN_CACHE_TTL) {
      return res.json(scanCache.data);
    }

    const tfMap = { 1:'1Min', 5:'5Min', 15:'15Min', 30:'30Min', 60:'1Hour', 240:'4Hour' };
    const alpacaTF = tfMap[tfMinutes] || '5Min';
    const htfTFMap = { 1:'5Min', 5:'15Min', 15:'1Hour', 30:'1Hour', 60:'4Hour', 240:'1Day' };
    const htfTF = htfTFMap[tfMinutes] || '1Hour';
    // Also fetch a second HTF for multi-TF alignment (2 levels up)
    const htf2TFMap = { 1:'15Min', 5:'1Hour', 15:'4Hour', 30:'1Day', 60:'1Day', 240:'1Day' };
    const htf2TF = htf2TFMap[tfMinutes] || '1Day';
    const barLimit = tfMinutes <= 5 ? 500 : tfMinutes <= 30 ? 300 : 500;

    const adxThresholds = {
      1:   { low: 8,  high: 15 },
      5:   { low: 10, high: 18 },
      15:  { low: 11, high: 20 },
      30:  { low: 12, high: 22 },
      60:  { low: 15, high: 25 },
      240: { low: 18, high: 30 }
    };
    const adxTH = adxThresholds[tfMinutes] || { low: 15, high: 25 };

    // Fetch SPY for relative strength calculation
    let spyChange = 0;
    let spyTrendBull = true;  // SPY daily trend (market regime)
    let spyAbove20EMA = true;
    try {
      const spyBars = await fetchBars('SPY', alpacaTF, 50);
      const spyRTH = spyBars.filter(b => {
        const d = new Date(b.t);
        const month = d.getUTCMonth();
        const isDST = month >= 2 && month <= 10;
        const etHour = d.getUTCHours() - (isDST ? 4 : 5);
        const etMin  = d.getUTCMinutes();
        const etTime = etHour + etMin / 60;
        return etTime >= 9.5 && etTime < 16;
      });
      if (spyRTH.length >= 2) {
        const spyOpen = spyRTH[0].o;
        const spyClose = spyRTH[spyRTH.length - 1].c;
        spyChange = (spyClose - spyOpen) / spyOpen * 100;
      }
      // Market regime: fetch SPY daily for trend context
      const spyDaily = await fetchBars('SPY', '1Day', 30);
      if (spyDaily.length >= 21) {
        const spyDCloses = spyDaily.map(b => b.c);
        const spyEma20 = emaCalc(spyDCloses, 20);
        const spyEma50 = smaCalc(spyDCloses, 50);
        spyAbove20EMA = spyDCloses[spyDCloses.length - 1] > spyEma20[spyEma20.length - 1];
        const spy50 = spyEma50[spyEma50.length - 1];
        spyTrendBull = spyAbove20EMA && (spy50 ? spyDCloses[spyDCloses.length - 1] > spy50 : true);
      }
    } catch(e) { /* SPY unavailable, RS will be 0 */ }

    // Process symbols in parallel (max 5 concurrent to avoid rate limits)
    const results = [];
    const batchSize = 5;
    for (let i = 0; i < symbols.length; i += batchSize) {
      const batch = symbols.slice(i, i + batchSize);
      const batchResults = await Promise.all(batch.map(async (symbol) => {
        try {
          // Fetch bars + real-time snapshot in parallel
          const snapPromise = fetch(`${DATA_URL}/stocks/${symbol}/snapshot`, { headers: HEADERS })
            .then(r => r.ok ? r.json() : null).catch(() => null);
          const [rawBars, htfBars, htf2Bars, snapshot] = await Promise.all([
            fetchBars(symbol, alpacaTF, barLimit),
            fetchBars(symbol, htfTF, 100),
            fetchBars(symbol, htf2TF, 50),
            snapPromise
          ]);
          // Real-time price from snapshot (falls back to last bar close)
          const livePrice = snapshot ? (snapshot.latestTrade?.p || snapshot.minuteBar?.c || null) : null;

          // RTH filter
          const bars5m = rawBars.filter(b => {
            const d = new Date(b.t);
            const month = d.getUTCMonth();
            const isDST = month >= 2 && month <= 10;
            const etHour = d.getUTCHours() - (isDST ? 4 : 5);
            const etMin  = d.getUTCMinutes();
            const etTime = etHour + etMin / 60;
            return etTime >= 9.5 && etTime < 16;
          });

          if (!bars5m.length) return { symbol, error: 'No RTH data' };

          const highs   = bars5m.map(b => b.h);
          const lows    = bars5m.map(b => b.l);
          const closes  = bars5m.map(b => b.c);
          const volumes = bars5m.map(b => b.v);
          const lastPrice = livePrice || closes[closes.length - 1];
          const lastBar   = bars5m[bars5m.length - 1];

          const rsi       = calcRSI(closes, 14);
          const macd      = calcMACD(closes);
          const stoch     = calcStochastic(highs, lows, closes, 14, 3);
          const vwap      = calcVWAP(highs, lows, closes, volumes);
          const ema9vals  = emaCalc(closes, 9);
          const ema21vals = emaCalc(closes, 21);
          const ema50vals = smaCalc(closes, 50);
          const ema9      = ema9vals[ema9vals.length - 1];
          const ema21     = ema21vals[ema21vals.length - 1];
          const sma50     = ema50vals[ema50vals.length - 1];
          let adx = 20;
          if (highs.length >= 30) adx = calcADX(highs, lows, closes, 14);

          // ── Volume analysis (deeper) ──
          const recentVols = volumes.slice(-20);
          const avgVol = recentVols.reduce((a, b) => a + b, 0) / recentVols.length;
          const lastVol = volumes[volumes.length - 1];
          const volRatio = avgVol > 0 ? lastVol / avgVol : 1;
          const volIncreasing = volumes.length >= 3 && volumes[volumes.length - 1] > volumes[volumes.length - 2];
          // Volume spike: last 3 bars avg vs 20-bar avg
          const last3Vol = volumes.slice(-3).reduce((a,b) => a+b, 0) / 3;
          const volSpike = avgVol > 0 ? last3Vol / avgVol : 1;

          // ── Liquidity check (Zanger: only trade liquid names) ──
          // Use daily volume from snapshot if available, else estimate from bar volume
          const dailyVolEst = snapshot?.dailyBar?.v || (avgVol * (390 / tfMinutes));  // extrapolate to daily
          const isLiquid = dailyVolEst >= 500000;  // 500K shares/day minimum
          const liquidityScore = dailyVolEst >= 2000000 ? 1 : dailyVolEst >= 1000000 ? 0.8 : dailyVolEst >= 500000 ? 0.5 : 0.2;

          // ── ATR ──
          let atr = 0;
          if (highs.length >= 3) {
            const trList = [];
            for (let j = 1; j < highs.length; j++) {
              trList.push(Math.max(highs[j] - lows[j], Math.abs(highs[j] - closes[j-1]), Math.abs(lows[j] - closes[j-1])));
            }
            const atrPeriod = Math.min(14, trList.length);
            let atrVal = trList.slice(0, atrPeriod).reduce((a, b) => a + b, 0) / atrPeriod;
            for (let j = atrPeriod; j < trList.length; j++) {
              atrVal = (atrVal * (atrPeriod - 1) + trList[j]) / atrPeriod;
            }
            atr = atrVal;
          }
          const atrPct = lastPrice > 0 ? (atr / lastPrice * 100) : 0;

          // ── Candle analysis ──
          const bodySize = Math.abs(lastBar.c - lastBar.o);
          const totalRange = lastBar.h - lastBar.l;
          const strongCandle = totalRange > 0 && (bodySize / totalRange) > 0.5;
          const bullCandle = lastBar.c > lastBar.o;

          // ── Opening Range ──
          const barsByDate = {};
          bars5m.forEach(b => { const dk = b.t.slice(0,10); if (!barsByDate[dk]) barsByDate[dk]=[]; barsByDate[dk].push(b); });
          const tradingDates = Object.keys(barsByDate).sort();
          const latestDayBars = barsByDate[tradingDates[tradingDates.length-1]] || [];
          const orBarCount = Math.max(1, Math.ceil(30 / tfMinutes));
          const orBars = latestDayBars.slice(0, orBarCount);
          const orHigh = orBars.length ? Math.max(...orBars.map(b => b.h)) : lastPrice + 1;
          const orLow  = orBars.length ? Math.min(...orBars.map(b => b.l)) : lastPrice - 1;
          const orBreakout = lastPrice > orHigh ? 'above' : lastPrice < orLow ? 'below' : 'inside';

          // ── Gap % from previous day close ──
          let gapPct = 0;
          let prevDayHigh = 0, prevDayLow = 0, prevDayClose = 0;
          if (tradingDates.length >= 2) {
            const prevDayBars = barsByDate[tradingDates[tradingDates.length - 2]] || [];
            if (prevDayBars.length) {
              prevDayClose = prevDayBars[prevDayBars.length - 1].c;
              prevDayHigh = Math.max(...prevDayBars.map(b => b.h));
              prevDayLow = Math.min(...prevDayBars.map(b => b.l));
              const todayOpen = latestDayBars.length ? latestDayBars[0].o : lastPrice;
              gapPct = (todayOpen - prevDayClose) / prevDayClose * 100;
            }
          }

          // ── Intraday Extension Detection (Tudor Jones: don't chase) ──
          const todayOpenPrice = latestDayBars.length ? latestDayBars[0].o : lastPrice;
          const intradayMovePct = Math.abs((lastPrice - todayOpenPrice) / todayOpenPrice * 100);
          const intradayMoveATR = atr > 0 ? Math.abs(lastPrice - todayOpenPrice) / atr : 0;
          const isIntradayExtended = intradayMoveATR > 2.5;
          const isIntradayStretched = intradayMoveATR > 1.8;

          // ── Gap Fill Risk (O'Neil: large gaps tend to partially fill) ──
          const hasLargeGap = Math.abs(gapPct) > 3;
          const gapDirection = gapPct > 0 ? 'up' : gapPct < 0 ? 'down' : 'none';
          const gapFillRisk = (gapPct > 3 && lastPrice < todayOpenPrice * 1.01) ? 'high' :
                              (gapPct > 2) ? 'medium' : 'low';

          // ── Day Range % (where is price within today's H-L range) ──
          const dayHigh = latestDayBars.length ? Math.max(...latestDayBars.map(b => b.h)) : lastPrice;
          const dayLow = latestDayBars.length ? Math.min(...latestDayBars.map(b => b.l)) : lastPrice;
          const dayRange = dayHigh - dayLow;
          const dayRangePct = dayRange > 0 ? Math.round(((lastPrice - dayLow) / dayRange) * 100) : 50;

          // ── Relative Strength vs SPY ──
          let relStrength = 0;
          if (latestDayBars.length >= 2) {
            const stockChange = (lastPrice - latestDayBars[0].o) / latestDayBars[0].o * 100;
            relStrength = stockChange - spyChange;
          }

          // ── Distance from VWAP (%) ──
          const vwapDist = vwap > 0 ? ((lastPrice - vwap) / vwap * 100) : 0;

          // ── HTF1 analysis ──
          let htfBull = true;
          let htfRsi = 50;
          if (htfBars.length >= 21) {
            const htfCloses = htfBars.map(b => b.c);
            const htfEma9  = emaCalc(htfCloses, 9);
            const htfEma21 = emaCalc(htfCloses, 21);
            htfBull = htfEma9[htfEma9.length-1] > htfEma21[htfEma21.length-1];
            htfRsi = calcRSI(htfCloses, 14);
          }

          // ── HTF2 analysis (2 levels up) ──
          let htf2Bull = true;
          if (htf2Bars.length >= 21) {
            const htf2Closes = htf2Bars.map(b => b.c);
            const htf2Ema9  = emaCalc(htf2Closes, 9);
            const htf2Ema21 = emaCalc(htf2Closes, 21);
            htf2Bull = htf2Ema9[htf2Ema9.length-1] > htf2Ema21[htf2Ema21.length-1];
          }

          // ── Multi-TF alignment (current + HTF1 + HTF2 must agree) ──
          const emaBull = ema9 > ema21;
          const macdBull = macd.hist > 0;
          const vwapAbove = lastPrice > vwap;
          const mtfAligned = (emaBull && htfBull && htf2Bull) || (!emaBull && !htfBull && !htf2Bull);

          // ── RSI divergence ──
          let divergence = 'none';
          if (closes.length >= 24) {
            const rsiNow  = calcRSI(closes, 14);
            const rsiBack = calcRSI(closes.slice(0, -10), 14);
            const priceNow  = closes[closes.length - 1];
            const priceBack = closes[closes.length - 11];
            if (priceNow > priceBack && rsiNow < rsiBack - 5) divergence = 'bearish';
            if (priceNow < priceBack && rsiNow > rsiBack + 5) divergence = 'bullish';
          }

          // ── Consolidation / squeeze detection ──
          const last10 = bars5m.slice(-10);
          const last10Range = Math.max(...last10.map(b => b.h)) - Math.min(...last10.map(b => b.l));
          const avgBarRange = bars5m.slice(-30).reduce((s, b) => s + (b.h - b.l), 0) / 30;
          const squeezeFactor = avgBarRange > 0 ? last10Range / (avgBarRange * 10) : 1;
          const isSqueeze = squeezeFactor < 0.6; // tight consolidation

          // ── Mode determination ──
          let mode = 'wait';
          const bullSignals = [vwapAbove, emaBull, macdBull, rsi > 50, adx >= adxTH.low].filter(Boolean).length;
          const bearSignals = [!vwapAbove, !emaBull, !macdBull, rsi < 50, adx >= adxTH.low].filter(Boolean).length;
          if (adx < adxTH.low) mode = 'dead';
          else if (bullSignals >= 4 && lastPrice > orHigh) mode = 'long';
          else if (bearSignals >= 4) mode = 'short';

          // ── Hysteresis: harder to LOSE a signal than to gain one ──
          // If previously had an active signal, allow slightly weaker conditions to hold it
          const prevResult = prevScanResults[symbol];
          if (mode === 'wait' && prevResult) {
            // Was long last scan: hold if still 3/5 bull + within 0.3% of OR high
            if (prevResult.mode === 'long' && bullSignals >= 3 && lastPrice > orHigh * 0.997) {
              mode = 'long';
            }
            // Was short last scan: hold if still 3/5 bear
            else if (prevResult.mode === 'short' && bearSignals >= 3) {
              mode = 'short';
            }
            // Was pullback_long: hold if HTF still bullish
            else if (prevResult.mode === 'pullback_long' && htfBull && htf2Bull && rsi < 55) {
              mode = 'pullback_long';
            }
            // Was pullback_short: hold if HTF still bearish
            else if (prevResult.mode === 'pullback_short' && !htfBull && !htf2Bull && rsi > 45) {
              mode = 'pullback_short';
            }
          }

          // ── Pullback detection ──
          // HTF bullish + current TF bearish + RSI oversold = pullback long (dip buy into uptrend)
          // HTF bearish + current TF bullish + RSI overbought = pullback short (bounce sell into downtrend)
          if (mode === 'wait' || mode === 'short') {
            // Pullback LONG: HTF trend is UP but current TF pulled back
            if (htfBull && htf2Bull && !emaBull && rsi < 45 && adx >= adxTH.low) {
              // Price within 1% above VWAP or below it (discount zone)
              if (vwapDist <= 1.0) {
                mode = 'pullback_long';
              }
            }
          }
          if (mode === 'wait' || mode === 'long') {
            // Pullback SHORT: HTF trend is DOWN but current TF bounced up
            if (!htfBull && !htf2Bull && emaBull && rsi > 55 && adx >= adxTH.low) {
              // Price within 1% below VWAP or above it (premium zone)
              if (vwapDist >= -1.0) {
                mode = 'pullback_short';
              }
            }
          }

          // ════════════════════════════════════════════
          // WEIGHTED CONFIDENCE SCORING (0–100%)
          // Higher weights = more important factors
          // Inspired by: Minervini (trend), O'Neil (RS+volume),
          // Tudor Jones (don't chase), Zanger (volume on breakout)
          // ════════════════════════════════════════════
          const isLong = mode === 'long', isShort = mode === 'short';
          const isPBLong = mode === 'pullback_long', isPBShort = mode === 'pullback_short';
          const isPullback = isPBLong || isPBShort;
          const hasSignal = isLong || isShort || isPullback;

          let weightedChecks;
          if (isPullback) {
            // Pullback scoring: emphasize HTF trend, RSI mean-reversion, and VWAP proximity
            weightedChecks = [
              { name: 'HTF Trend (primary)',  weight: 22, pass: (isPBLong ? (htfBull && htf2Bull) : (!htfBull && !htf2Bull)) ? 1 : 0.5 },
              { name: 'RSI Stretched',        weight: 18, pass: isPBLong ? (rsi < 35 ? 1 : rsi < 40 ? 0.8 : rsi < 45 ? 0.5 : 0.3) : (rsi > 65 ? 1 : rsi > 60 ? 0.8 : rsi > 55 ? 0.5 : 0.3) },
              { name: 'VWAP Proximity',       weight: 14, pass: isPBLong ? (vwapDist <= -0.3 ? 1 : vwapDist <= 0 ? 0.7 : 0.4) : (vwapDist >= 0.3 ? 1 : vwapDist >= 0 ? 0.7 : 0.4) },
              { name: 'ADX Trend Active',     weight: 12, pass: adx >= adxTH.high ? 1 : adx >= adxTH.low ? 0.6 : 0 },
              { name: 'Volume Confirm',       weight: 10, pass: volSpike >= 1.5 ? 1 : volRatio >= 1.0 ? 0.5 : 0.3 },
              { name: 'Divergence',           weight: 8,  pass: isPBLong ? (divergence === 'bullish' ? 1 : 0.3) : (divergence === 'bearish' ? 1 : 0.3) },
              { name: 'Market Regime',        weight: 8,  pass: isPBLong ? (spyTrendBull ? 1 : 0.3) : (!spyTrendBull ? 1 : 0.5) },
              { name: 'Stoch Confirm',        weight: 5,  pass: isPBLong ? (stoch.k < 25 ? 1 : stoch.k < 40 ? 0.6 : 0.2) : (stoch.k > 75 ? 1 : stoch.k > 60 ? 0.6 : 0.2) },
              { name: 'Squeeze',              weight: 3,  pass: isSqueeze ? 1 : 0.3 },
            ];
          } else {
            weightedChecks = [
              // Factor                                      Weight  Pass?
              { name: 'ADX Trend',       weight: 16, pass: adx >= adxTH.high ? 1 : adx >= adxTH.low ? 0.6 : 0 },
              { name: 'Volume Confirm',  weight: 14, pass: volSpike >= 1.5 ? 1 : volRatio >= 1.2 && volIncreasing ? 0.7 : volRatio >= 1.0 ? 0.3 : 0 },
              { name: 'VWAP Position',   weight: 11, pass: isLong ? (vwapAbove ? 1 : 0) : isShort ? (!vwapAbove ? 1 : 0) : 0 },
              { name: 'EMA Stack',       weight: 11, pass: isLong ? (emaBull ? 1 : 0) : isShort ? (!emaBull ? 1 : 0) : 0 },
              { name: 'HTF Alignment',   weight: 11, pass: mtfAligned ? 1 : (isLong ? htfBull : isShort ? !htfBull : false) ? 0.5 : 0 },
              { name: 'Market Regime',   weight: 9,  pass: isLong ? (spyTrendBull ? 1 : (spyAbove20EMA ? 0.5 : 0.2)) : isShort ? (!spyTrendBull ? 1 : (!spyAbove20EMA ? 0.5 : 0.3)) : 0.5 },
              { name: 'MACD Momentum',   weight: 8,  pass: isLong ? (macdBull ? 1 : 0) : isShort ? (!macdBull ? 1 : 0) : 0 },
              { name: 'RSI Zone',        weight: 6,  pass: isLong ? (rsi > 50 && rsi < 70 ? 1 : rsi >= 40 ? 0.5 : 0) : isShort ? (rsi < 50 && rsi > 30 ? 1 : rsi <= 60 ? 0.5 : 0) : 0 },
              { name: 'Stochastic',      weight: 5,  pass: isLong ? (stoch.k > 30 && stoch.k < 80 ? 1 : stoch.k > 80 ? 0.2 : 0.4) : isShort ? (stoch.k < 70 && stoch.k > 20 ? 1 : stoch.k < 20 ? 0.2 : 0.4) : 0.5 },
              { name: 'OR Breakout',     weight: 5,  pass: isLong ? (orBreakout === 'above' ? 1 : 0) : isShort ? (orBreakout === 'below' ? 1 : 0.5) : 0 },
              { name: 'Candle Quality',  weight: 4,  pass: strongCandle ? (isLong ? (bullCandle ? 1 : 0.3) : isShort ? (!bullCandle ? 1 : 0.3) : 0.5) : 0 },
            ];
          }

          const totalWeight = weightedChecks.reduce((s, c) => s + c.weight, 0);
          const earnedWeight = weightedChecks.reduce((s, c) => s + c.weight * c.pass, 0);
          let confidence = hasSignal ? Math.round((earnedWeight / totalWeight) * 100) : 0;

          // ── PENALTIES (Tudor Jones / Druckenmiller: protect capital) ──
          if (hasSignal) {
            // Penalty: chasing intraday — already moved too far today
            if (isIntradayExtended) confidence = Math.max(10, confidence - 12);
            else if (isIntradayStretched) confidence = Math.max(10, confidence - 5);
            // Penalty: poor liquidity (Zanger: wide spreads kill edge)
            if (!isLiquid) confidence = Math.max(10, confidence - 10);
            // Penalty: large gap not yet confirmed (gap fill risk)
            if (gapFillRisk === 'high' && isLong && gapDirection === 'up') confidence = Math.max(10, confidence - 8);
            // Penalty: trading against market regime (Tudor Jones rule)
            if (isLong && !spyTrendBull && !spyAbove20EMA) confidence = Math.max(10, confidence - 6);
            if (isShort && spyTrendBull) confidence = Math.max(10, confidence - 6);
            // Penalty: stochastic overbought on longs / oversold on shorts
            if (isLong && stoch.k > 85) confidence = Math.max(10, confidence - 5);
            if (isShort && stoch.k < 15) confidence = Math.max(10, confidence - 5);
          }

          // Simple 9-point score (for backward compatibility)
          const effLong = isLong || isPBLong;
          const effShort = isShort || isPBShort;
          const score = [
            hasSignal,
            effLong ? vwapAbove : effShort ? !vwapAbove : false,
            effLong ? emaBull : effShort ? !emaBull : isPBLong ? htfBull : isPBShort ? !htfBull : false,
            effLong ? macdBull : effShort ? !macdBull : false,
            adx >= adxTH.low,
            effLong ? (rsi > 50 && rsi < 70) : effShort ? (rsi < 50 && rsi > 30) : isPBLong ? (rsi < 45) : isPBShort ? (rsi > 55) : false,
            volRatio >= 1.2 && volIncreasing,
            strongCandle,
            effLong ? htfBull : effShort ? !htfBull : false,
          ].filter(Boolean).length;

          // ── Signal freshness (how many bars ago did signal appear) ──
          let signalAge = 0;
          if (hasSignal && latestDayBars.length > 1) {
            // Walk backward to find when mode changed
            for (let k = latestDayBars.length - 2; k >= 0; k--) {
              const barClose = latestDayBars[k].c;
              const barAboveOR = barClose > orHigh;
              if ((isLong) && !barAboveOR) { signalAge = latestDayBars.length - 1 - k; break; }
              if ((isShort) && barClose > vwap) { signalAge = latestDayBars.length - 1 - k; break; }
              // Pullback: age from when RSI crossed into oversold/overbought zone
              if (isPBLong && barClose > vwap) { signalAge = latestDayBars.length - 1 - k; break; }
              if (isPBShort && barClose < vwap) { signalAge = latestDayBars.length - 1 - k; break; }
            }
          }
          const signalAgeMin = signalAge * tfMinutes;

          // ── Alert detection (new signal vs previous scan) ──
          const prev = prevScanResults[symbol];
          let alertType = 'none';
          if (prev) {
            if (hasSignal && prev.mode !== mode) alertType = 'new_signal';
            else if (hasSignal && confidence > (prev.confidence || 0) + 10) alertType = 'strengthened';
            else if (!hasSignal && (prev.mode === 'long' || prev.mode === 'short' || prev.mode === 'pullback_long' || prev.mode === 'pullback_short')) alertType = 'signal_lost';
          } else if (hasSignal) {
            alertType = 'new_signal';
          }

          return {
            symbol,
            price: +lastPrice.toFixed(2),
            mode,
            score,
            confidence,
            adx: +adx.toFixed(1),
            rsi: +rsi.toFixed(1),
            macdHist: +macd.hist.toFixed(4),
            stochK: stoch.k,
            stochD: stoch.d,
            vwapAbove,
            vwapDist: +vwapDist.toFixed(2),
            emaBull,
            ema9: +ema9.toFixed(2),
            ema21: +ema21.toFixed(2),
            sma50: sma50 ? +sma50.toFixed(2) : null,
            volume: +volRatio.toFixed(2),
            volSpike: +volSpike.toFixed(2),
            htfBull,
            htf2Bull,
            mtfAligned,
            htfRsi: +htfRsi.toFixed(1),
            atr: +atr.toFixed(4),
            atrPct: +atrPct.toFixed(2),
            suggestedStop: +(atr * 1.5).toFixed(2),
            orHigh: +orHigh.toFixed(2),
            orLow: +orLow.toFixed(2),
            orBreakout,
            gapPct: +gapPct.toFixed(2),
            relStrength: +relStrength.toFixed(2),
            divergence,
            isSqueeze,
            signalAgeMin,
            alertType,
            // Market context
            spyTrendBull,
            spyAbove20EMA,
            // Liquidity
            isLiquid,
            dailyVolEst: Math.round(dailyVolEst),
            // Intraday extension
            intradayMoveATR: +intradayMoveATR.toFixed(1),
            isIntradayExtended,
            isIntradayStretched,
            // Gap risk
            gapFillRisk,
            // Day range, prev day levels, R:R
            dayRangePct,
            dayHigh: +dayHigh.toFixed(2),
            dayLow: +dayLow.toFixed(2),
            prevDayHigh: +prevDayHigh.toFixed(2),
            prevDayLow: +prevDayLow.toFixed(2),
            prevDayClose: +prevDayClose.toFixed(2),
            rrRatio: +(() => {
              const stop = atr * 1.5;
              const target = stop * 2;
              if (!prevDayHigh) return 2.0;
              // Check if key level blocks target
              const isLDir = mode === 'long' || mode === 'pullback_long';
              const isSDir = mode === 'short' || mode === 'pullback_short';
              if (isLDir) {
                const levels = [prevDayHigh, prevDayClose].filter(l => l > lastPrice && l < lastPrice + target);
                if (levels.length) { const nearest = Math.min(...levels); return Math.max(0.5, (nearest - lastPrice) / stop); }
              }
              if (isSDir) {
                const levels = [prevDayLow, prevDayClose].filter(l => l < lastPrice && l > lastPrice - target);
                if (levels.length) { const nearest = Math.max(...levels); return Math.max(0.5, (lastPrice - nearest) / stop); }
              }
              return 2.0;
            })().toFixed(1),
            timestamp: lastBar.t
          };
        } catch (err) {
          return { symbol, error: err.message };
        }
      }));
      results.push(...batchResults);
    }

    // Save current results for alert comparison next scan
    results.forEach(r => { if (!r.error) prevScanResults[r.symbol] = r; });

    // Sort: highest confidence actionable signals first, then pullbacks, then wait, then dead
    results.sort((a, b) => {
      if (a.error && !b.error) return 1;
      if (!a.error && b.error) return -1;
      const modeOrder = { long: 0, short: 0, pullback_long: 1, pullback_short: 1, wait: 2, dead: 3 };
      const ma = modeOrder[a.mode] ?? 4, mb = modeOrder[b.mode] ?? 4;
      if (ma !== mb) return ma - mb;
      if ((a.confidence || 0) !== (b.confidence || 0)) return (b.confidence || 0) - (a.confidence || 0);
      return (b.score || 0) - (a.score || 0);
    });

    const response = { timeframe: tfMinutes, scannedAt: new Date().toISOString(), spyChange: +spyChange.toFixed(2), spyTrendBull, spyAbove20EMA, results };
    scanCache.data = response;
    scanCache.key = cacheKey;
    scanCache.ts = Date.now();
    res.json(response);
  } catch (err) {
    console.error('Scan API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
// API: GET /api/scan-longterm?symbols=AAPL,MSFT,GOOG
// LONG-TERM INVESTMENT SCANNER — Daily/Weekly timeframes, fundamental bias
// Scans for swing/position trades (weeks to months)
// ════════════════════════════════════════════════════════
const DEFAULT_LT_LIST = ['AAPL','MSFT','GOOG','AMZN','NVDA','META','TSLA','V','JPM','JNJ','UNH','HD','PG','MA','XOM','COST','AVGO','LLY','ABBV','MRK','PEP','KO','WMT','NFLX','CRM','AMD','ORCL','ADBE','INTC','DIS'];

const ltScanCache = { data: null, ts: 0 };
const LT_CACHE_TTL = 300000; // 5 minutes (daily data doesn't change fast)

app.get('/api/scan-longterm', async (req, res) => {
  try {
    const symbolsRaw = req.query.symbols || DEFAULT_LT_LIST.join(',');
    const symbols = symbolsRaw.split(',').map(s => s.trim().toUpperCase()).filter(Boolean);

    // Check cache
    const cacheKey = symbols.join(',');
    if (ltScanCache.data && ltScanCache.key === cacheKey && (Date.now() - ltScanCache.ts) < LT_CACHE_TTL) {
      return res.json(ltScanCache.data);
    }

    // Fetch SPY daily for relative strength
    let spyWeeklyChange = 0, spyMonthlyChange = 0;
    let marketRegime = 'bull'; // bull, correction, bear
    let spyAbove200 = true;
    try {
      const spyBars = await fetchBars('SPY', '1Day', 200);
      if (spyBars.length >= 22) {
        const spyNow = spyBars[spyBars.length - 1].c;
        const spy5d = spyBars[spyBars.length - 6]?.c || spyNow;
        const spy22d = spyBars[spyBars.length - 23]?.c || spyNow;
        spyWeeklyChange = (spyNow - spy5d) / spy5d * 100;
        spyMonthlyChange = (spyNow - spy22d) / spy22d * 100;

        // Market regime detection (Druckenmiller / O'Neil: don't fight the market)
        const spyCloses = spyBars.map(b => b.c);
        const spySma50 = smaCalc(spyCloses, 50);
        const spySma200 = smaCalc(spyCloses, 200);
        const spy50Val = spySma50[spySma50.length - 1];
        const spy200Val = spySma200[spySma200.length - 1];
        spyAbove200 = spy200Val ? spyNow > spy200Val : true;
        const spyAbove50 = spy50Val ? spyNow > spy50Val : true;
        const spy50Above200 = (spy50Val && spy200Val) ? spy50Val > spy200Val : true;

        if (spyAbove200 && spyAbove50 && spy50Above200) marketRegime = 'bull';
        else if (spyAbove200 && (!spyAbove50 || !spy50Above200)) marketRegime = 'correction';
        else marketRegime = 'bear';
      }
    } catch(e) { /* SPY unavailable */ }

    const results = [];
    const batchSize = 5;

    for (let i = 0; i < symbols.length; i += batchSize) {
      const batch = symbols.slice(i, i + batchSize);
      const batchResults = await Promise.all(batch.map(async (symbol) => {
        try {
          // Fetch daily bars (200 days for 200 SMA) and get snapshot
          const [dailyBars, snapshot] = await Promise.all([
            fetchBars(symbol, '1Day', 200),
            fetch(`${DATA_URL}/stocks/${symbol}/snapshot`, { headers: HEADERS })
              .then(r => r.ok ? r.json() : null).catch(() => null)
          ]);

          if (!dailyBars.length || dailyBars.length < 50) {
            return { symbol, error: 'Insufficient daily data' };
          }

          const closes  = dailyBars.map(b => b.c);
          const highs   = dailyBars.map(b => b.h);
          const lows    = dailyBars.map(b => b.l);
          const volumes = dailyBars.map(b => b.v);
          const lastPrice = snapshot?.latestTrade?.p || closes[closes.length - 1];

          // ── Moving Averages ──
          const sma20Arr  = smaCalc(closes, 20);
          const sma50Arr  = smaCalc(closes, 50);
          const sma200Arr = smaCalc(closes, 200);
          const ema12Arr  = emaCalc(closes, 12);
          const ema26Arr  = emaCalc(closes, 26);

          const sma20  = sma20Arr[sma20Arr.length - 1];
          const sma50  = sma50Arr[sma50Arr.length - 1];
          const sma200 = sma200Arr[sma200Arr.length - 1];
          const ema12  = ema12Arr[ema12Arr.length - 1];
          const ema26  = ema26Arr[ema26Arr.length - 1];

          // ── Weekly RSI (use 14 daily bars as proxy for weekly) ──
          const rsi14 = calcRSI(closes, 14);

          // ── MACD (12,26,9) on daily ──
          const macd = calcMACD(closes);

          // ── ADX (daily, 14-period) ──
          let adx = 20;
          if (highs.length >= 30) adx = calcADX(highs, lows, closes, 14);

          // ── Volume analysis (daily avg) ──
          const avg20Vol = volumes.slice(-20).reduce((a,b) => a+b, 0) / 20;
          const avg5Vol  = volumes.slice(-5).reduce((a,b) => a+b, 0) / 5;
          const volRatio = avg20Vol > 0 ? avg5Vol / avg20Vol : 1;

          // ── ATR (14-day) ──
          let atr = 0;
          if (highs.length >= 15) {
            const trList = [];
            for (let j = 1; j < highs.length; j++) {
              trList.push(Math.max(highs[j] - lows[j], Math.abs(highs[j] - closes[j-1]), Math.abs(lows[j] - closes[j-1])));
            }
            const atrPeriod = 14;
            let atrVal = trList.slice(0, atrPeriod).reduce((a, b) => a + b, 0) / atrPeriod;
            for (let j = atrPeriod; j < trList.length; j++) {
              atrVal = (atrVal * (atrPeriod - 1) + trList[j]) / atrPeriod;
            }
            atr = atrVal;
          }

          // ── Performance metrics ──
          const perf1w  = closes.length >= 6  ? ((lastPrice - closes[closes.length - 6]) / closes[closes.length - 6] * 100) : 0;
          const perf1m  = closes.length >= 23 ? ((lastPrice - closes[closes.length - 23]) / closes[closes.length - 23] * 100) : 0;
          const perf3m  = closes.length >= 66 ? ((lastPrice - closes[closes.length - 66]) / closes[closes.length - 66] * 100) : 0;
          const perf6m  = closes.length >= 130 ? ((lastPrice - closes[closes.length - 130]) / closes[closes.length - 130] * 100) : 0;

          // ── Relative strength vs SPY ──
          const rsWeekly  = perf1w - spyWeeklyChange;
          const rsMonthly = perf1m - spyMonthlyChange;

          // ── 52-week high/low proximity ──
          const high52w = Math.max(...highs.slice(-200));
          const low52w  = Math.min(...lows.slice(-200));
          const range52w = high52w - low52w;
          const pctFrom52wHigh = range52w > 0 ? ((high52w - lastPrice) / high52w * 100) : 0;
          const pctFrom52wLow  = range52w > 0 ? ((lastPrice - low52w) / low52w * 100) : 0;

          // ── Trend structure ──
          const aboveSMA20  = lastPrice > sma20;
          const aboveSMA50  = lastPrice > sma50;
          const aboveSMA200 = sma200 ? lastPrice > sma200 : true;
          const goldenCross = sma50 > sma200; // 50 above 200
          const deathCross  = sma200 && sma50 < sma200;
          const maStackBull = sma20 > sma50 && sma50 > (sma200 || 0); // all MAs stacked bullish
          const maStackBear = sma20 < sma50 && sma50 < (sma200 || Infinity);

          // ── Consolidation (tight daily range last 10 days) ──
          const last10Bars = dailyBars.slice(-10);
          const last10Range = Math.max(...last10Bars.map(b => b.h)) - Math.min(...last10Bars.map(b => b.l));
          const avgDailyRange = dailyBars.slice(-30).reduce((s, b) => s + (b.h - b.l), 0) / 30;
          const isConsolidating = last10Range < avgDailyRange * 6; // tight relative to average

          // ════════════════════════════════════════════
          // VCP — Volatility Contraction Pattern (Minervini)
          // Each successive contraction should be tighter than the last
          // ════════════════════════════════════════════
          let vcpScore = 0; // 0-3 (number of contracting pivots)
          let isVCP = false;
          if (dailyBars.length >= 40) {
            // Split last 40 bars into 4 segments of 10, check if ranges contract
            const seg1Range = Math.max(...dailyBars.slice(-40, -30).map(b => b.h)) - Math.min(...dailyBars.slice(-40, -30).map(b => b.l));
            const seg2Range = Math.max(...dailyBars.slice(-30, -20).map(b => b.h)) - Math.min(...dailyBars.slice(-30, -20).map(b => b.l));
            const seg3Range = Math.max(...dailyBars.slice(-20, -10).map(b => b.h)) - Math.min(...dailyBars.slice(-20, -10).map(b => b.l));
            const seg4Range = last10Range;
            if (seg2Range < seg1Range) vcpScore++;
            if (seg3Range < seg2Range) vcpScore++;
            if (seg4Range < seg3Range) vcpScore++;
            // True VCP: at least 2 contractions + price near high of base + above 50 SMA
            isVCP = vcpScore >= 2 && aboveSMA50 && (high52w - lastPrice) / high52w < 0.25;
          }

          // ════════════════════════════════════════════
          // ACCUMULATION / DISTRIBUTION (O'Neil)
          // Up-days should have higher volume than down-days = institutions buying
          // ════════════════════════════════════════════
          let accumDist = 0; // positive = accumulation, negative = distribution
          const adLookback = Math.min(50, dailyBars.length);
          let upDayVol = 0, downDayVol = 0, upDays = 0, downDays = 0;
          for (let j = dailyBars.length - adLookback; j < dailyBars.length; j++) {
            const bar = dailyBars[j];
            if (bar.c > bar.o) { upDayVol += bar.v; upDays++; }
            else if (bar.c < bar.o) { downDayVol += bar.v; downDays++; }
          }
          const avgUpVol = upDays > 0 ? upDayVol / upDays : 0;
          const avgDownVol = downDays > 0 ? downDayVol / downDays : 0;
          // A/D ratio >1.2 = institutional accumulation, <0.8 = distribution
          const adRatio = avgDownVol > 0 ? avgUpVol / avgDownVol : 1;
          accumDist = adRatio;
          const isAccumulating = adRatio > 1.2;
          const isDistributing = adRatio < 0.8;

          // ════════════════════════════════════════════
          // BASE DEPTH (Minervini: ideal base = 10-35% correction)
          // Too shallow (<8%) = no shakeout. Too deep (>50%) = damaged goods.
          // ════════════════════════════════════════════
          // Find the most recent swing high (within last 100 bars)
          const recentHighs = dailyBars.slice(-100);
          const recentSwingHigh = Math.max(...recentHighs.map(b => b.h));
          const recentSwingLow = Math.min(...dailyBars.slice(-50).map(b => b.l));
          const baseDepthPct = recentSwingHigh > 0 ? ((recentSwingHigh - recentSwingLow) / recentSwingHigh * 100) : 0;
          const isProperBase = baseDepthPct >= 10 && baseDepthPct <= 35;
          const isDamagedBase = baseDepthPct > 50;

          // ════════════════════════════════════════════
          // TIGHT CLOSES (Minervini: last 5 days closing within 1.5% of each other = ready to move)
          // ════════════════════════════════════════════
          const last5Closes = closes.slice(-5);
          const maxClose5 = Math.max(...last5Closes);
          const minClose5 = Math.min(...last5Closes);
          const tightClosesPct = maxClose5 > 0 ? ((maxClose5 - minClose5) / maxClose5 * 100) : 0;
          const hasTightCloses = tightClosesPct < 1.5;

          // ── RSI divergence (weekly-level) ──
          let divergence = 'none';
          if (closes.length >= 30) {
            const rsiNow  = calcRSI(closes, 14);
            const rsiBack = calcRSI(closes.slice(0, -15), 14);
            const priceNow  = closes[closes.length - 1];
            const priceBack = closes[closes.length - 16];
            if (priceNow > priceBack && rsiNow < rsiBack - 5) divergence = 'bearish';
            if (priceNow < priceBack && rsiNow > rsiBack + 5) divergence = 'bullish';
          }

          // ════════════════════════════════════════════
          // EXTENSION / CHASING DETECTION
          // Prevents buying after big spikes when price is far from support
          // ════════════════════════════════════════════
          const lastDailyBar = dailyBars[dailyBars.length - 1];
          const prevClose = closes.length >= 2 ? closes[closes.length - 2] : lastPrice;

          // 1. Single-day spike: today's candle moved more than 5%
          const dailyChangePct = ((lastDailyBar.c - lastDailyBar.o) / lastDailyBar.o) * 100;
          const dailyGapPct = ((lastDailyBar.o - prevClose) / prevClose) * 100;
          const totalDayMovePct = Math.abs(dailyChangePct) + Math.abs(dailyGapPct > 2 ? dailyGapPct : 0);
          const isSpikeDay = totalDayMovePct > 5; // >5% intraday move

          // 2. Distance from 20 SMA: if price is stretched >5% above, it's extended
          const distFromSMA20 = sma20 > 0 ? ((lastPrice - sma20) / sma20 * 100) : 0;
          const isExtendedFromMA = distFromSMA20 > 5; // >5% above 20 SMA

          // 3. Distance from 50 SMA: if >10% above, very extended
          const distFromSMA50 = sma50 > 0 ? ((lastPrice - sma50) / sma50 * 100) : 0;
          const isVeryExtended = distFromSMA50 > 10; // >10% above 50 SMA

          // 4. RSI spike: RSI jumped more than 15 points in last 3 days
          let rsiAcceleration = 0;
          if (closes.length >= 17) {
            const rsi3dAgo = calcRSI(closes.slice(0, -3), 14);
            rsiAcceleration = rsi14 - rsi3dAgo;
          }
          const isRsiSpike = rsiAcceleration > 15;

          // 5. Volume exhaustion: last day volume > 3x average = potential blowoff
          const lastDayVol = volumes[volumes.length - 1];
          const isVolumeExhaustion = avg20Vol > 0 && lastDayVol > avg20Vol * 3 && dailyChangePct > 3;

          // 6. Multi-day extension: gained >8% in last 5 days without pullback
          const isMultiDayRun = perf1w > 8;

          // Combined extension score (0-100, higher = more dangerous to chase)
          const extensionScore = Math.min(100, Math.round(
            (isSpikeDay ? 25 : 0) +
            (isExtendedFromMA ? 20 : (distFromSMA20 > 3 ? 10 : 0)) +
            (isVeryExtended ? 20 : 0) +
            (isRsiSpike ? 15 : (rsiAcceleration > 10 ? 8 : 0)) +
            (isVolumeExhaustion ? 15 : 0) +
            (isMultiDayRun ? 10 : 0) +
            (rsi14 > 75 ? 10 : (rsi14 > 70 ? 5 : 0))
          ));
          const isExtended = extensionScore >= 40; // 40+ = too extended to buy now
          const isSeverelyExtended = extensionScore >= 65; // 65+ = definitely chasing

          // Ideal entry distance: how far price needs to pull back for a safe entry
          // Best entry = near 20 SMA or at least halfway back from the spike
          const idealEntryPrice = isExtended
            ? +(sma20 + (lastPrice - sma20) * 0.3).toFixed(2) // 30% of extension above 20 SMA
            : +lastPrice.toFixed(2);
          const pullbackNeeded = isExtended ? +((lastPrice - idealEntryPrice) / lastPrice * 100).toFixed(1) : 0;

          // ── Signal determination ──
          // Inspired by: Minervini (trend template + VCP), O'Neil (CANSLIM),
          // Tudor Jones (200 SMA), Druckenmiller (market regime)
          // Long-term BUY signals:
          //   1. Uptrend continuation: above all MAs, golden cross, strong RSI
          //   2. VCP breakout: proper base with volatility contraction + volume
          //   3. Value entry: pullback to 50/200 SMA in uptrend
          // Long-term AVOID signals:
          //   1. Death cross, below all MAs
          //   2. RSI extremely overbought (>80 on daily)
          //   3. Bear market regime (Druckenmiller: don't fight the market)
          //   4. Distribution pattern (institutions selling)

          let signal = 'hold'; // buy, accumulate, hold, reduce, avoid
          let signalReason = '';

          const bullPoints = [
            aboveSMA200,
            aboveSMA50,
            goldenCross,
            rsi14 > 50 && rsi14 < 70,
            macd.hist > 0,
            adx >= 20,
            perf1m > 0,
            volRatio >= 1.0,
            rsMonthly > 0,
            maStackBull,
            isAccumulating,  // O'Neil: institutional buying
            !isDamagedBase   // Minervini: base not too deep
          ].filter(Boolean).length;

          const bearPoints = [
            !aboveSMA200,
            !aboveSMA50,
            deathCross,
            rsi14 < 40,
            macd.hist < 0,
            perf1m < -5,
            rsMonthly < -3,
            maStackBear,
            isDistributing,  // institutions selling
            isDamagedBase    // base too deep = damaged goods
          ].filter(Boolean).length;

          // Strong buy conditions (Minervini trend template)
          if (bullPoints >= 9 && isAccumulating) {
            signal = 'strong_buy';
            signalReason = 'Strong uptrend, institutional accumulation, all indicators aligned';
          } else if (isVCP && aboveSMA50 && adx >= 15 && isAccumulating) {
            signal = 'strong_buy';
            signalReason = `VCP pattern (${vcpScore}/3 contractions) — volatility coiling for breakout`;
          } else if (bullPoints >= 8) {
            signal = 'strong_buy';
            signalReason = 'Strong uptrend, all indicators aligned';
          } else if (bullPoints >= 6 && aboveSMA200 && goldenCross) {
            signal = 'buy';
            signalReason = 'Healthy uptrend with golden cross';
          } else if (aboveSMA200 && !aboveSMA50 && rsi14 < 45 && goldenCross && !isDistributing) {
            signal = 'accumulate';
            signalReason = 'Pullback to support in long-term uptrend';
          } else if (aboveSMA200 && isConsolidating && hasTightCloses && adx < 20 && !isDistributing) {
            signal = 'accumulate';
            signalReason = 'Tight consolidation near support — potential breakout setup';
          } else if (bearPoints >= 7 || (marketRegime === 'bear' && bearPoints >= 5)) {
            signal = 'avoid';
            signalReason = 'Downtrend' + (marketRegime === 'bear' ? ' in bear market' : '') + (isDistributing ? ', institutional distribution' : ', major weakness');
          } else if (bearPoints >= 4 || (deathCross && rsi14 < 40)) {
            signal = 'reduce';
            signalReason = 'Weakening trend' + (isDistributing ? ', distribution detected' : ', consider reducing position');
          } else if (pctFrom52wHigh < 5 && rsi14 > 75) {
            signal = 'hold';
            signalReason = 'Near 52w high with overbought RSI — wait for pullback';
          } else {
            signal = 'hold';
            signalReason = 'No clear entry signal';
          }

          // ═══ Market regime penalty (Druckenmiller: never go heavy in a bear market) ═══
          if (marketRegime === 'bear' && (signal === 'strong_buy' || signal === 'buy')) {
            signal = 'accumulate';
            signalReason += ' (downgraded: bear market — smaller positions only)';
          } else if (marketRegime === 'correction' && signal === 'strong_buy') {
            signal = 'buy';
            signalReason += ' (downgraded: market in correction)';
          }

          // ═══ EXTENSION OVERRIDE: Downgrade signals when chasing ═══
          // This prevents buying after a big spike day or when price is far from support
          let extensionWarning = '';
          if (isExtended && (signal === 'strong_buy' || signal === 'buy' || signal === 'accumulate')) {
            if (isSeverelyExtended) {
              // Very extended: downgrade completely to "wait for pullback"
              extensionWarning = `EXTENDED (${extensionScore}/100) — Price ${distFromSMA20.toFixed(1)}% above 20 SMA. Wait for pullback to ~$${idealEntryPrice}`;
              signal = 'wait_pullback';
              signalReason = `Too extended to buy — need ${pullbackNeeded}% pullback. ` + (isSpikeDay ? `Today's move: +${totalDayMovePct.toFixed(1)}%. ` : '') + `Wait for price near $${idealEntryPrice}`;
            } else {
              // Moderately extended: downgrade one level + add warning
              extensionWarning = `Caution: ${distFromSMA20.toFixed(1)}% above 20 SMA` + (isSpikeDay ? `, spike day (+${totalDayMovePct.toFixed(1)}%)` : '');
              if (signal === 'strong_buy') { signal = 'buy'; signalReason += ' (downgraded: extended from support)'; }
              else if (signal === 'buy') { signal = 'accumulate'; signalReason += ' (downgraded: consider smaller position, price stretched)'; }
              // accumulate stays but gets warning
            }
          }

          // ── Confidence score (0-100) ──
          let confidence = 0;
          if (signal === 'strong_buy' || signal === 'buy' || signal === 'accumulate') {
            const checks = [
              { weight: 18, pass: aboveSMA200 ? 1 : 0 },
              { weight: 14, pass: goldenCross ? 1 : (aboveSMA50 ? 0.5 : 0) },
              { weight: 12, pass: macd.hist > 0 ? 1 : (macd.hist > -0.5 ? 0.3 : 0) },
              { weight: 10, pass: rsi14 > 45 && rsi14 < 70 ? 1 : (rsi14 > 40 ? 0.5 : 0) },
              { weight: 8,  pass: adx >= 25 ? 1 : (adx >= 15 ? 0.5 : 0.2) },
              { weight: 8,  pass: volRatio >= 1.2 ? 1 : (volRatio >= 0.8 ? 0.5 : 0.2) },
              { weight: 8,  pass: rsMonthly > 2 ? 1 : (rsMonthly > 0 ? 0.6 : 0.2) },
              { weight: 7,  pass: perf3m > 5 ? 1 : (perf3m > 0 ? 0.5 : 0) },
              // New elite checks:
              { weight: 8,  pass: isAccumulating ? 1 : (adRatio > 1.0 ? 0.5 : 0) },  // O'Neil A/D
              { weight: 7,  pass: isProperBase ? 1 : (!isDamagedBase ? 0.4 : 0) },     // Minervini base
            ];
            const totalW = checks.reduce((s, c) => s + c.weight, 0);
            const earnedW = checks.reduce((s, c) => s + c.weight * c.pass, 0);
            confidence = Math.round((earnedW / totalW) * 100);

            // Bonuses
            if (isVCP) confidence = Math.min(99, confidence + 8);            // VCP = high probability breakout
            if (hasTightCloses && isConsolidating) confidence = Math.min(99, confidence + 5); // Ready to move

            // Penalties
            if (isExtended) confidence = Math.max(10, confidence - Math.round(extensionScore * 0.4));
            if (marketRegime === 'bear') confidence = Math.max(10, confidence - 15);         // Druckenmiller
            else if (marketRegime === 'correction') confidence = Math.max(10, confidence - 7);
            if (isDistributing) confidence = Math.max(10, confidence - 10);                   // Institutions selling
            if (isDamagedBase) confidence = Math.max(10, confidence - 12);                    // Base too deep
          } else if (signal === 'wait_pullback') {
            confidence = Math.round(bullPoints / 12 * 100);
          } else if (signal === 'avoid' || signal === 'reduce') {
            confidence = Math.round(bearPoints / 10 * 100);
          }

          // ── Suggested entry/stop for position trades ──
          // Entry zone accounts for extension — suggests waiting for pullback level
          let entryZone;
          if (signal === 'wait_pullback') {
            // Entry should be near the 20 SMA or the ideal pullback price
            entryZone = { low: +(sma20).toFixed(2), high: +idealEntryPrice.toFixed(2) };
          } else if (signal === 'accumulate') {
            entryZone = { low: +(sma50 || sma20).toFixed(2), high: +lastPrice.toFixed(2) };
          } else if (isExtended) {
            // Even for buy signals, suggest a lower entry when stretched
            entryZone = { low: +idealEntryPrice.toFixed(2), high: +(lastPrice - atr * 0.3).toFixed(2) };
          } else {
            entryZone = { low: +(lastPrice - atr * 0.5).toFixed(2), high: +(lastPrice + atr * 0.5).toFixed(2) };
          }
          const stopLoss = +(lastPrice - atr * 2.5).toFixed(2); // wider stops for long-term
          const target1  = +(lastPrice + atr * 5).toFixed(2);
          const target2  = +(lastPrice + atr * 8).toFixed(2);

          // ── Timeframe suggestion ──
          let holdPeriod = 'weeks';
          if (signal === 'strong_buy' && maStackBull && adx > 25) holdPeriod = 'months';
          else if (signal === 'accumulate') holdPeriod = 'weeks_to_months';
          else if (signal === 'buy') holdPeriod = 'weeks';

          return {
            symbol,
            price: +lastPrice.toFixed(2),
            signal,
            signalReason,
            confidence,
            holdPeriod,
            // Technical data
            sma20: sma20 ? +sma20.toFixed(2) : null,
            sma50: sma50 ? +sma50.toFixed(2) : null,
            sma200: sma200 ? +sma200.toFixed(2) : null,
            rsi: +rsi14.toFixed(1),
            macdHist: +macd.hist.toFixed(4),
            adx: +adx.toFixed(1),
            atr: +atr.toFixed(2),
            volRatio: +volRatio.toFixed(2),
            // Trend flags
            aboveSMA20, aboveSMA50, aboveSMA200,
            goldenCross, deathCross,
            maStackBull, maStackBear,
            isConsolidating,
            divergence,
            // Elite scanner data (Minervini/O'Neil/Druckenmiller)
            isVCP, vcpScore,
            accumDist: +accumDist.toFixed(2),
            isAccumulating, isDistributing,
            baseDepthPct: +baseDepthPct.toFixed(1),
            isProperBase, isDamagedBase,
            hasTightCloses,
            marketRegime,
            // Extension / chasing data
            isExtended,
            extensionScore,
            distFromSMA20: +distFromSMA20.toFixed(1),
            distFromSMA50: +distFromSMA50.toFixed(1),
            isSpikeDay,
            dailyChangePct: +dailyChangePct.toFixed(1),
            idealEntryPrice,
            pullbackNeeded: +pullbackNeeded,
            extensionWarning,
            // Performance
            perf1w: +perf1w.toFixed(2),
            perf1m: +perf1m.toFixed(2),
            perf3m: +perf3m.toFixed(2),
            perf6m: +perf6m.toFixed(2),
            // Relative strength vs SPY
            rsWeekly: +rsWeekly.toFixed(2),
            rsMonthly: +rsMonthly.toFixed(2),
            // 52-week
            high52w: +high52w.toFixed(2),
            low52w: +low52w.toFixed(2),
            pctFrom52wHigh: +pctFrom52wHigh.toFixed(1),
            pctFrom52wLow: +pctFrom52wLow.toFixed(1),
            // Trade plan
            entryZone,
            stopLoss,
            target1,
            target2,
            timestamp: dailyBars[dailyBars.length - 1].t
          };
        } catch (err) {
          return { symbol, error: err.message };
        }
      }));
      results.push(...batchResults);
    }

    // Sort: strong_buy first, then buy, accumulate, wait_pullback, hold, reduce, avoid
    const signalOrder = { strong_buy: 0, buy: 1, accumulate: 2, wait_pullback: 3, hold: 4, reduce: 5, avoid: 6 };
    results.sort((a, b) => {
      if (a.error && !b.error) return 1;
      if (!a.error && b.error) return -1;
      const sa = signalOrder[a.signal] ?? 6, sb = signalOrder[b.signal] ?? 6;
      if (sa !== sb) return sa - sb;
      return (b.confidence || 0) - (a.confidence || 0);
    });

    const response = {
      scannedAt: new Date().toISOString(),
      spyWeeklyChange: +spyWeeklyChange.toFixed(2),
      spyMonthlyChange: +spyMonthlyChange.toFixed(2),
      marketRegime,
      results
    };

    ltScanCache.data = response;
    ltScanCache.key = cacheKey;
    ltScanCache.ts = Date.now();

    res.json(response);
  } catch (err) {
    console.error('Long-term scan API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Health check ──
app.get('/api/status', (req, res) => {
  res.json({ status: 'running', timestamp: new Date().toISOString() });
});

// Catch-all — serve index.html for unmatched routes (but NOT for /recommendations.html)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n  ⚡ Trading Command Center is live!`);
  console.log(`  ➜ Open: http://localhost:${PORT}`);
  console.log(`  ➜ Alpaca: Paper account connected`);
  console.log(`  ➜ API:  http://localhost:${PORT}/api/indicators/SPY\n`);
});
