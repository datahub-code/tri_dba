<?php
declare(strict_types=1);
if (!defined('ZG_APP')) { http_response_code(404); exit; }

ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");

/** A problem the visitor can fix (bad input, out of stock...). The message is safe to show. */
class UserError extends RuntimeException {}

set_exception_handler(function (Throwable $e): void {
    error_log('Zorvo Group: ' . get_class($e) . ': ' . $e->getMessage());
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'The store is temporarily unavailable. Check the private configuration file, the database connection, whether setup.php has been run, and the hosting error log.';
});

// Private configuration lives in the folder ABOVE public_html.
$configPath = dirname(__DIR__, 2) . '/zorvo-config.php';
if (!is_file($configPath)) {
    http_response_code(503);
    exit('Setup required: place zorvo-config.php in the folder that contains public_html (not inside it). See START_HERE.txt.');
}
$config = require $configPath;
if (!is_array($config)) { throw new RuntimeException('Invalid configuration file.'); }

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
if (($config['require_https'] ?? true) && !$https) {
    http_response_code(400);
    exit('HTTPS is required. Enable SSL for this domain and open the https:// address.');
}

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_name('zorvo_session');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => $https, 'httponly' => true, 'samesite' => 'Lax']);
session_start();

// Idle timeout: 30 minutes for the admin panel, 24 hours for shoppers (so carts survive a break).
$idleLimit = !empty($_SESSION['admin_id']) ? 1800 : 86400;
if (isset($_SESSION['last_seen']) && time() - (int)$_SESSION['last_seen'] > $idleLimit) {
    $_SESSION = [];
    session_regenerate_id(true);
}
$_SESSION['last_seen'] = time();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); }

function e(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function csrf(): string { return (string)$_SESSION['csrf']; }
function flash(string $message): void { $_SESSION['messages'][] = $message; }
function take_flashes(): array { $m = $_SESSION['messages'] ?? []; unset($_SESSION['messages']); return is_array($m) ? $m : []; }
function redirect(string $url): never { header('Location: ' . $url, true, 303); exit; }
function fail(int $code, string $message): never { http_response_code($code); header('Content-Type: text/plain; charset=utf-8'); exit($message); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $limit = defined('ZG_ADMIN') ? 12000000 : 150000;
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > $limit) { fail(413, 'Request too large.'); }
    $sent = $_POST['csrf'] ?? null;
    if (!is_string($sent) || !hash_equals(csrf(), $sent)) { fail(400, 'Invalid or expired request token. Go back, reload the page and try again. (If you were uploading a large image, make it smaller.)'); }
}

function db(): PDO {
    static $pdo = null;
    global $config;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . $config['db_host'] . ';port=' . (int)($config['db_port'] ?? 3306) . ';dbname=' . $config['db_name'] . ';charset=utf8mb4';
        $pdo = new PDO($dsn, (string)$config['db_user'], (string)$config['db_password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}

function q(string $sql, array $params = []): PDOStatement {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

function defaults(): array { return require __DIR__ . '/defaults.php'; }

/** All store settings (defaults overlaid with saved values). */
function settings(): array {
    static $cache = null;
    if ($cache === null) {
        $cache = defaults();
        foreach (q('SELECT k, v FROM zg_settings')->fetchAll() as $row) {
            if (array_key_exists($row['k'], $cache)) { $cache[$row['k']] = (string)$row['v']; }
        }
    }
    return $cache;
}

function save_settings(array $values): void {
    $allowed = defaults();
    foreach ($values as $k => $v) {
        if (!array_key_exists((string)$k, $allowed)) { throw new RuntimeException('Unknown setting: ' . $k); }
        q('INSERT INTO zg_settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = ?', [(string)$k, (string)$v, (string)$v]);
    }
}

function limited(string $scope, int $max, int $windowSeconds): bool {
    $key = hash('sha256', $scope . ':' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $now = time();
    q('DELETE FROM zg_limits WHERE expires < ?', [$now]);
    q('INSERT INTO zg_limits (bucket, hits, expires) VALUES (?, 1, ?) ON DUPLICATE KEY UPDATE hits = hits + 1', [$key, $now + $windowSeconds]);
    return (int)q('SELECT hits FROM zg_limits WHERE bucket = ?', [$key])->fetchColumn() > $max;
}

/** Reads a POST text field, enforcing a maximum length in characters. */
function text_field(string $key, int $max, bool $trim = true): string {
    $value = $_POST[$key] ?? '';
    if (!is_string($value) || strlen($value) > $max * 4) { fail(400, 'Invalid or oversized form field.'); }
    if ($trim) { $value = trim($value); }
    if (mb_strlen($value, 'UTF-8') > $max) { throw new UserError('One of the fields is longer than the allowed ' . $max . ' characters.'); }
    return $value;
}

/** Integer from the query string with sane bounds. */
function get_int(string $key, int $default, int $min, int $max): int {
    $v = $_GET[$key] ?? null;
    if (!is_string($v) || !preg_match('/^\d{1,9}$/', $v)) { return $default; }
    return max($min, min($max, (int)$v));
}

/** Returns the logged-in administrator or redirects to the admin login page. */
function admin_required(): array {
    if (empty($_SESSION['admin_id'])) { redirect('login.php'); }
    $admin = q('SELECT id, username, version FROM zg_admins WHERE id = ?', [(int)$_SESSION['admin_id']])->fetch();
    if (!$admin || (int)$admin['version'] !== (int)($_SESSION['admin_version'] ?? 0)) {
        $_SESSION = [];
        session_regenerate_id(true);
        redirect('login.php');
    }
    header('Cache-Control: no-store');
    header('X-Robots-Tag: noindex, nofollow');
    return $admin;
}
