<?php
declare(strict_types=1);
if (!defined('ZG_APP')) { http_response_code(404); exit; }

const MAX_LINE_QTY = 20;
const ORDER_STATUSES = ['pending', 'paid', 'shipped', 'completed', 'cancelled'];
const UPLOAD_MAX_BYTES = 3145728; // 3 MB per image
const IMG_PATTERN = '#^assets/(img|uploads)/[A-Za-z0-9_-]+(/[A-Za-z0-9_-]+)?\.(jpg|jpeg|png|webp)$#';

/* ------------------------------------------------------------------ money */

function money(int $cents): string {
    return settings()['currency'] . number_format($cents / 100, 2, '.', ',');
}

function cents_to_input(int $cents): string { return number_format($cents / 100, 2, '.', ''); }

/** "19.99" -> 1999. Throws UserError with a friendly message when invalid. */
function parse_money(string $raw, string $label): int {
    $raw = str_replace([',', ' '], '', trim($raw));
    if (!preg_match('/^\d{1,7}(\.\d{1,2})?$/', $raw)) {
        throw new UserError($label . ' must be a number such as 19.99 (maximum 9,999,999.99).');
    }
    $parts = explode('.', $raw, 2);
    return (int)$parts[0] * 100 + (int)str_pad($parts[1] ?? '', 2, '0');
}

/** "8.25" -> 825 (basis points). Allowed range 0 to 30 percent. */
function parse_percent_bp(string $raw, string $label): int {
    $raw = trim($raw);
    if (!preg_match('/^\d{1,2}(\.\d{1,2})?$/', $raw)) { throw new UserError($label . ' must be a number such as 8.25.'); }
    $parts = explode('.', $raw, 2);
    $bp = (int)$parts[0] * 100 + (int)str_pad($parts[1] ?? '', 2, '0');
    if ($bp > 3000) { throw new UserError($label . ' cannot be more than 30.'); }
    return $bp;
}

function bp_to_input(int $bp): string { return number_format($bp / 100, 2, '.', ''); }

/** Shipping, tax and total for a given items subtotal (all values in cents). */
function order_totals(int $subtotal): array {
    $s = settings();
    $shipping = 0;
    if ($subtotal > 0) {
        $shipping = (int)$s['shipping_flat'];
        $freeOver = (int)$s['free_ship_over'];
        if ($freeOver > 0 && $subtotal >= $freeOver) { $shipping = 0; }
    }
    $tax = intdiv($subtotal * (int)$s['tax_bp'] + 5000, 10000); // rounded to the nearest cent
    return ['subtotal' => $subtotal, 'shipping' => $shipping, 'tax' => $tax, 'total' => $subtotal + $shipping + $tax];
}

function store_open(): bool { return settings()['store_live'] === '1'; }

/* ---------------------------------------------------------- slugs, images */

function slugify(string $text): string {
    $s = strtolower(trim($text));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s) ?? '';
    $s = rtrim(substr(trim($s, '-'), 0, 80), '-');
    return $s !== '' ? $s : 'item';
}

/** $table must be one of the two fixed table names below. */
function unique_slug(string $table, string $slug, int $excludeId = 0): string {
    if (!in_array($table, ['zg_products', 'zg_categories'], true)) { throw new InvalidArgumentException('Bad table'); }
    $candidate = $slug;
    $i = 2;
    while (q("SELECT 1 FROM $table WHERE slug = ? AND id <> ?", [$candidate, $excludeId])->fetchColumn()) {
        $candidate = $slug . '-' . $i++;
    }
    return $candidate;
}

/** Returns the path if it is a safe, local image path; otherwise an empty string. */
function safe_image(?string $path): string {
    return ($path !== null && preg_match(IMG_PATTERN, $path)) ? $path : '';
}

/**
 * Saves an uploaded image from $_FILES[$field] into assets/uploads and returns its site path.
 * Returns null when no file was chosen. Throws UserError for unacceptable files.
 * Paths of files written are appended to $moved so the caller can clean up on failure.
 */
function store_upload(string $field, array &$moved): ?string {
    if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) { return null; }
    $f = $_FILES[$field];
    $err = $f['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($err === UPLOAD_ERR_NO_FILE) { return null; }
    if ($err !== UPLOAD_ERR_OK) { throw new UserError('An image could not be uploaded (it may be larger than the server allows).'); }
    if (!is_uploaded_file((string)$f['tmp_name'])) { throw new UserError('Invalid upload.'); }
    if ((int)$f['size'] > UPLOAD_MAX_BYTES) { throw new UserError('Each image must be 3 MB or smaller.'); }
    $info = @getimagesize((string)$f['tmp_name']);
    if ($info === false) { throw new UserError('Only JPG, PNG or WebP images are allowed.'); }
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!isset($types[$info[2]])) { throw new UserError('Only JPG, PNG or WebP images are allowed.'); }
    if ($info[0] > 6000 || $info[1] > 6000 || $info[0] < 200 || $info[1] < 120) {
        throw new UserError('Image dimensions must be between 200x120 and 6000x6000 pixels.');
    }
    $dir = dirname(__DIR__) . '/assets/uploads';
    if (!is_dir($dir) || !is_writable($dir)) {
        throw new UserError('The assets/uploads folder is missing or not writable. Check its permissions in your hosting File Manager.');
    }
    $name = bin2hex(random_bytes(12)) . '.' . $types[$info[2]];
    if (!move_uploaded_file((string)$f['tmp_name'], $dir . '/' . $name)) { throw new UserError('The image could not be saved.'); }
    @chmod($dir . '/' . $name, 0644);
    $moved[] = $dir . '/' . $name;
    return 'assets/uploads/' . $name;
}

/** Deletes a file previously saved by store_upload (never touches bundled images). */
function remove_upload(string $path): void {
    if (str_starts_with($path, 'assets/uploads/') && preg_match(IMG_PATTERN, $path)) {
        $file = dirname(__DIR__) . '/' . $path;
        if (is_file($file)) { @unlink($file); }
    }
}

/* ------------------------------------------------------------------- cart */

function cart_get(): array {
    $c = $_SESSION['cart'] ?? [];
    return is_array($c) ? $c : [];
}

function cart_set(array $cart): void { $_SESSION['cart'] = $cart; }

function cart_count(): int {
    $n = 0;
    foreach (cart_get() as $qty) { $n += max(0, (int)$qty); }
    return $n;
}

/**
 * Current cart priced from the database (never from the browser).
 * Removes unavailable products and clamps quantities to stock. 'changed' is true when it did so.
 */
function cart_summary(): array {
    $cart = cart_get();
    $lines = [];
    $subtotal = 0;
    $changed = false;
    if ($cart) {
        $ids = array_map('intval', array_keys($cart));
        $marks = implode(',', array_fill(0, count($ids), '?'));
        $rows = q("SELECT id, name, slug, sku, price_cents, stock, image FROM zg_products WHERE is_active = 1 AND id IN ($marks)", $ids)->fetchAll();
        $byId = [];
        foreach ($rows as $r) { $byId[(int)$r['id']] = $r; }
        foreach ($cart as $rawId => $want) {
            $id = (int)$rawId;
            $want = (int)$want;
            if (!isset($byId[$id])) { unset($cart[$rawId]); $changed = true; continue; }
            $r = $byId[$id];
            $qty = min($want, MAX_LINE_QTY, (int)$r['stock']);
            if ($qty < 1) { unset($cart[$rawId]); $changed = true; continue; }
            if ($qty !== $want) { $cart[$rawId] = $qty; $changed = true; }
            $lineCents = (int)$r['price_cents'] * $qty;
            $subtotal += $lineCents;
            $lines[] = [
                'id' => $id, 'name' => (string)$r['name'], 'slug' => (string)$r['slug'], 'image' => (string)$r['image'],
                'unit_cents' => (int)$r['price_cents'], 'qty' => $qty, 'max_qty' => min(MAX_LINE_QTY, (int)$r['stock']),
                'line_cents' => $lineCents,
            ];
        }
        if ($changed) { cart_set($cart); }
    }
    return ['lines' => $lines, 'totals' => order_totals($subtotal), 'changed' => $changed];
}

/* ----------------------------------------------------------------- orders */

/**
 * Creates an order from the session cart inside one transaction, locking the product rows so
 * stock cannot be oversold. $c holds the validated customer fields. Returns [order_no, token].
 */
function place_order(array $c): array {
    $cart = cart_get();
    if (!$cart) { throw new UserError('Your cart is empty.'); }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $ids = array_map('intval', array_keys($cart));
        sort($ids);
        $marks = implode(',', array_fill(0, count($ids), '?'));
        $rows = q("SELECT id, name, sku, price_cents, stock, is_active FROM zg_products WHERE id IN ($marks) ORDER BY id FOR UPDATE", $ids)->fetchAll();
        $byId = [];
        foreach ($rows as $r) { $byId[(int)$r['id']] = $r; }

        $items = [];
        $subtotal = 0;
        foreach ($cart as $rawId => $want) {
            $id = (int)$rawId;
            $qty = (int)$want;
            $r = $byId[$id] ?? null;
            if ($r === null || (int)$r['is_active'] !== 1) { throw new UserError('An item in your cart is no longer available. Please review your cart.'); }
            if ($qty < 1 || $qty > MAX_LINE_QTY) { throw new UserError('Please review the quantities in your cart.'); }
            if ((int)$r['stock'] < $qty) { throw new UserError('Sorry, "' . $r['name'] . '" does not have enough stock for your order. Please update your cart.'); }
            $line = (int)$r['price_cents'] * $qty;
            $subtotal += $line;
            $items[] = ['id' => $id, 'name' => (string)$r['name'], 'sku' => $r['sku'], 'unit' => (int)$r['price_cents'], 'qty' => $qty, 'line' => $line];
        }
        $t = order_totals($subtotal);
        $orderNo = 'ZG-' . strtoupper(bin2hex(random_bytes(4)));
        $token = bin2hex(random_bytes(16));

        q('INSERT INTO zg_orders (order_no, access_token, status, customer_name, customer_email, customer_phone, address1, address2, city, region, postal, country, notes, subtotal_cents, shipping_cents, tax_cents, total_cents, restocked, created)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)', [
            $orderNo, $token, 'pending', $c['name'], $c['email'], $c['phone'], $c['address1'], $c['address2'], $c['city'], $c['region'],
            $c['postal'], $c['country'], $c['notes'], $t['subtotal'], $t['shipping'], $t['tax'], $t['total'], gmdate('Y-m-d H:i:s'),
        ]);
        $orderId = (int)$pdo->lastInsertId();

        foreach ($items as $it) {
            q('INSERT INTO zg_order_items (order_id, product_id, name, sku, unit_cents, qty, line_cents) VALUES (?, ?, ?, ?, ?, ?, ?)',
              [$orderId, $it['id'], $it['name'], $it['sku'], $it['unit'], $it['qty'], $it['line']]);
            $upd = q('UPDATE zg_products SET stock = stock - ? WHERE id = ? AND stock >= ?', [$it['qty'], $it['id'], $it['qty']]);
            if ($upd->rowCount() !== 1) { throw new UserError('Stock changed while placing your order. Please review your cart and try again.'); }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        throw $e;
    }
    cart_set([]);
    return [$orderNo, $token];
}

/** Changes an order's status. Cancelling returns the stock exactly once. Cancelled orders are final. */
function set_order_status(int $orderId, string $new): void {
    if (!in_array($new, ORDER_STATUSES, true)) { throw new UserError('Unknown status.'); }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $o = q('SELECT id, status, restocked FROM zg_orders WHERE id = ? FOR UPDATE', [$orderId])->fetch();
        if (!$o) { throw new UserError('Order not found.'); }
        if ($o['status'] === 'cancelled') { throw new UserError('Cancelled orders cannot be changed.'); }
        if ($new === 'cancelled' && (int)$o['restocked'] === 0) {
            foreach (q('SELECT product_id, qty FROM zg_order_items WHERE order_id = ?', [$orderId])->fetchAll() as $it) {
                if ($it['product_id'] !== null) {
                    q('UPDATE zg_products SET stock = stock + ? WHERE id = ?', [(int)$it['qty'], (int)$it['product_id']]);
                }
            }
            q('UPDATE zg_orders SET restocked = 1 WHERE id = ?', [$orderId]);
        }
        q('UPDATE zg_orders SET status = ? WHERE id = ?', [$new, $orderId]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        throw $e;
    }
}

/* ------------------------------------------------------------ sample data */

/** Inserts demo categories and products (flagged is_sample so the admin can remove them in one click). */
function seed_sample_data(): void {
    $now = gmdate('Y-m-d H:i:s');
    $cats = [
        ['Home & Living', 'home-living', 'Comfort and character for the spaces you call home.', 'assets/img/home.jpg'],
        ['Travel & Bags', 'travel-bags', 'Carry-alls and companions for the journey.', 'assets/img/travel.jpg'],
        ['Kitchen & Dining', 'kitchen-dining', 'Tools and table linens for everyday meals.', 'assets/img/family.jpg'],
        ['Gifts & Everyday', 'gifts-everyday', 'Small things that make days better.', 'assets/img/shopping.jpg'],
    ];
    $catId = [];
    foreach ($cats as $i => [$name, $slug, $desc, $img]) {
        q('INSERT INTO zg_categories (name, slug, description, image, sort_order, is_sample) VALUES (?, ?, ?, ?, ?, 1)', [$name, $slug, $desc, $img, $i + 1]);
        $catId[$slug] = (int)db()->lastInsertId();
    }
    $note = 'Sample product. Replace this description, the price and the photo with your real product details in the admin panel.';
    // [category slug, name, slug, sku, short description, price cents, compare cents|null, stock, image, featured]
    $products = [
        ['home-living',    'Stoneware Mug Set',      'stoneware-mug-set',    'SMP-001', 'Set of four mugs.',          3400, 4200, 25, 'assets/img/products/mug-set.jpg',       1],
        ['home-living',    'Chunky Knit Throw',      'chunky-knit-throw',    'SMP-002', 'A cozy throw blanket.',      5900, null, 12, 'assets/img/products/knit-throw.jpg',    1],
        ['travel-bags',    'Leather Weekender Bag',  'leather-weekender-bag','SMP-003', 'A roomy overnight bag.',    18900, 21900, 6, 'assets/img/products/weekender-bag.jpg', 1],
        ['travel-bags',    'Insulated Water Bottle', 'insulated-water-bottle','SMP-004','A reusable bottle.',         2800, null, 40, 'assets/img/products/water-bottle.jpg',  1],
        ['kitchen-dining', 'Wooden Cutting Board',   'wooden-cutting-board', 'SMP-005', 'A board with a handle.',     4200, null, 18, 'assets/img/products/cutting-board.jpg', 0],
        ['kitchen-dining', 'Linen Napkin Set',       'linen-napkin-set',     'SMP-006', 'Set of four napkins.',       2400, 3000, 30, 'assets/img/products/linen-napkins.jpg', 0],
        ['gifts-everyday', 'Soy Candle',             'soy-candle',           'SMP-007', 'A candle in a glass jar.',   2200, null, 35, 'assets/img/products/soy-candle.jpg',    0],
        ['gifts-everyday', 'Cloth-Bound Journal',    'cloth-bound-journal',  'SMP-008', 'A notebook with a pen.',     1800, null, 50, 'assets/img/products/journal.jpg',       0],
    ];
    foreach ($products as [$cat, $name, $slug, $sku, $short, $price, $compare, $stock, $img, $featured]) {
        q('INSERT INTO zg_products (category_id, name, slug, sku, short_desc, description, price_cents, compare_cents, stock, image, is_active, is_featured, is_sample, created)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 1, ?)', [$catId[$cat], $name, $slug, $sku, $short, $note, $price, $compare, $stock, $img, $featured, $now]);
    }
}
