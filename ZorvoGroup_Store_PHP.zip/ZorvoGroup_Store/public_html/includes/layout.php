<?php
if (!defined('ZG_APP')) { http_response_code(404); exit; }

/** One product tile used on the home page and the shop listing. */
function product_card(array $p): void {
    $img = safe_image($p['image'] ?? '');
    $stock = (int)$p['stock'];
    $price = (int)$p['price_cents'];
    $compare = (int)($p['compare_cents'] ?? 0);
    $onSale = $compare > $price;
    $href = 'product.php?slug=' . rawurlencode((string)$p['slug']);
    ?>
    <article class="pcard">
      <a class="pcard-img" href="<?= e($href) ?>" tabindex="-1" aria-hidden="true">
        <?php if ($img !== ''): ?><img src="<?= e($img) ?>" alt="" loading="lazy" width="600" height="600"><?php else: ?><span class="noimg">No image</span><?php endif; ?>
        <?php if ($stock < 1): ?><span class="badge badge-out">Sold out</span><?php elseif ($onSale): ?><span class="badge badge-sale">Sale</span><?php endif; ?>
      </a>
      <div class="pcard-body">
        <h3><a href="<?= e($href) ?>"><?= e($p['name']) ?></a></h3>
        <?php if (!empty($p['short_desc'])): ?><p class="pcard-short"><?= e($p['short_desc']) ?></p><?php endif; ?>
        <p class="price"><span class="now"><?= e(money($price)) ?></span><?php if ($onSale): ?> <s class="was"><?= e(money($compare)) ?></s><?php endif; ?></p>
      </div>
    </article>
    <?php
}

/** Public storefront header, navigation, search and cart link. */
function page_header(array $s, string $title, string $description = ''): void {
    $desc = $description !== '' ? $description : (string)$s['tagline'];
    $count = cart_count();
    ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> | <?= e($s['store_name']) ?></title>
<meta name="description" content="<?= e($desc) ?>">
<link rel="stylesheet" href="assets/css/site.css">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<?php if ($s['store_live'] !== '1'): ?>
<div class="demo-bar" role="status">Store preview: browsing and cart are available, but ordering is not open yet.</div>
<?php endif; ?>
<header class="site-header">
  <div class="wrap bar">
    <a class="logo" href="index.php" aria-label="<?= e($s['store_name']) ?> home"><span class="logo-mark">Z</span><span class="logo-text"><?= e($s['store_name']) ?></span></a>
    <form class="search" action="shop.php" method="get" role="search">
      <label class="sr" for="site-q">Search products</label>
      <input id="site-q" type="search" name="q" placeholder="Search products" maxlength="80" value="<?= e(is_string($_GET['q'] ?? null) ? $_GET['q'] : '') ?>">
      <button type="submit" aria-label="Search"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"/><path d="M20 20l-4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
    </form>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="primary-nav" aria-label="Toggle menu"><span></span><span></span><span></span></button>
    <nav id="primary-nav" class="nav" aria-label="Main navigation">
      <a href="shop.php">Shop</a>
      <a href="index.php#categories">Categories</a>
      <a href="index.php#contact">Contact</a>
      <a class="cart-link" href="cart.php">Cart<?php if ($count > 0): ?> <span class="cart-count"><?= e((string)$count) ?></span><?php endif; ?></a>
    </nav>
  </div>
</header>
<?php foreach (take_flashes() as $m): ?>
<div class="flash" role="status"><div class="wrap"><?= e($m) ?></div></div>
<?php endforeach; ?>
<main id="main">
<?php
}

/** Public storefront footer. */
function page_footer(array $s): void {
    ?>
</main>
<footer class="site-footer">
  <div class="wrap foot">
    <div class="foot-brand">
      <a class="logo logo-light" href="index.php"><span class="logo-mark">Z</span><span class="logo-text"><?= e($s['store_name']) ?></span></a>
      <p class="foot-tag"><?= e($s['tagline']) ?></p>
    </div>
    <nav aria-label="Shop links" class="foot-col">
      <strong>Shop</strong>
      <a href="shop.php">All products</a>
      <a href="cart.php">Cart</a>
      <a href="index.php#contact">Contact us</a>
    </nav>
    <nav aria-label="Information" class="foot-col">
      <strong>Information</strong>
      <a href="page.php?p=shipping">Shipping &amp; returns</a>
      <a href="page.php?p=privacy">Privacy notice</a>
      <a href="page.php?p=terms">Terms of sale</a>
      <a href="admin/">Admin</a>
    </nav>
  </div>
  <div class="wrap legal-line">&copy; <?= e(date('Y')) ?> <?= e($s['store_name']) ?>. <?= e($s['footer_note']) ?></div>
</footer>
<script src="assets/js/site.js" defer></script>
</body>
</html>
<?php
}

/** Admin panel header + sidebar. $active matches a key in $items. */
function admin_header(array $s, array $admin, string $title, string $active): void {
    $pending = (int)q("SELECT COUNT(*) FROM zg_orders WHERE status = 'pending'")->fetchColumn();
    $items = [
        'dashboard'  => ['index.php', 'Dashboard'],
        'orders'     => ['orders.php', 'Orders' . ($pending > 0 ? ' (' . $pending . ')' : '')],
        'products'   => ['products.php', 'Products'],
        'categories' => ['categories.php', 'Categories'],
        'messages'   => ['messages.php', 'Messages'],
        'settings'   => ['settings.php', 'Store settings'],
        'account'    => ['account.php', 'Account'],
    ];
    ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($title) ?> | <?= e($s['store_name']) ?> Admin</title>
<link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
<a class="skip" href="#main">Skip to content</a>
<div class="shell">
  <aside class="side">
    <a class="side-logo" href="index.php"><span class="logo-mark">Z</span><span><?= e($s['store_name']) ?><small>ADMIN PANEL</small></span></a>
    <nav aria-label="Admin navigation">
      <?php foreach ($items as $key => [$href, $label]): ?>
        <a href="<?= e($href) ?>"<?= $key === $active ? ' class="on" aria-current="page"' : '' ?>><?= e($label) ?></a>
      <?php endforeach; ?>
      <a href="../index.php" target="_blank" rel="noopener">View store &#8599;</a>
    </nav>
    <div class="side-foot">
      <span>Signed in as <strong><?= e($admin['username']) ?></strong></span>
      <form method="post" action="logout.php"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><button class="link-btn" type="submit">Sign out</button></form>
    </div>
  </aside>
  <div class="content">
    <header class="top"><h1><?= e($title) ?></h1></header>
    <?php foreach (take_flashes() as $m): ?><div class="alert" role="status"><?= e($m) ?></div><?php endforeach; ?>
    <main id="main">
<?php
}

function admin_footer(): void {
    ?>
    </main>
  </div>
</div>
<script src="../assets/js/admin.js" defer></script>
</body>
</html>
<?php
}

/** Simple previous/next pager. $base is a URL ending in ? or &. */
function pager(string $base, int $page, int $pages): void {
    if ($pages < 2) { return; }
    ?>
    <nav class="pager" aria-label="Pages">
      <?php if ($page > 1): ?><a class="btn btn-outline btn-sm" href="<?= e($base . 'page=' . ($page - 1)) ?>">&larr; Previous</a><?php endif; ?>
      <span>Page <?= e((string)$page) ?> of <?= e((string)$pages) ?></span>
      <?php if ($page < $pages): ?><a class="btn btn-outline btn-sm" href="<?= e($base . 'page=' . ($page + 1)) ?>">Next &rarr;</a><?php endif; ?>
    </nav>
    <?php
}
