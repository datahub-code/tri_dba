<?php
if (!defined('ZG_APP')) { http_response_code(404); exit; }

/* Small form-field helpers for the admin panel. $extra must only ever be a fixed string from our own code. */

function input_row(string $name, string $label, string $value, int $max, string $type = 'text', string $extra = ''): void {
    echo '<label>' . e($label) . '<input type="' . e($type) . '" name="' . e($name) . '" value="' . e($value) . '" maxlength="' . $max . '" ' . $extra . '></label>';
}

function area_row(string $name, string $label, string $value, int $max, int $rows = 3): void {
    echo '<label>' . e($label) . '<textarea name="' . e($name) . '" rows="' . $rows . '" maxlength="' . $max . '">' . e($value) . '</textarea></label>';
}

function check_row(string $name, string $label, bool $checked): void {
    echo '<label class="check-row"><input type="checkbox" name="' . e($name) . '" value="1"' . ($checked ? ' checked' : '') . '><span>' . e($label) . '</span></label>';
}

function image_row(string $name, string $label, string $path, string $removeName = ''): void {
    $safe = safe_image($path);
    echo '<div class="img-row">';
    if ($safe !== '') { echo '<img src="../' . e($safe) . '" alt="" width="120" height="120">'; } else { echo '<span class="noimg">No image</span>'; }
    echo '<div><label>' . e($label) . '<input type="file" name="' . e($name) . '" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"><small>JPG, PNG or WebP, up to 3 MB. Leave empty to keep the current image.</small></label>';
    if ($removeName !== '' && $safe !== '') { check_row($removeName, 'Remove current image', false); }
    echo '</div></div>';
}

function status_badge(string $status): string {
    return '<span class="pill pill-' . e($status) . '">' . e(ucfirst($status)) . '</span>';
}
