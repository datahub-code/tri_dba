<?php
if (!defined('ZG_APP')) { http_response_code(404); exit; }

// Default store settings. Every value here is editable in Admin > Settings.
// Money values are stored in cents (e.g. 500 = 5.00). tax_bp is basis points (825 = 8.25%).
return [
    'store_name'    => 'Zorvo Group',
    'tagline'       => 'Everyday essentials, thoughtfully chosen',

    'hero_eyebrow'  => 'WELCOME TO ZORVO GROUP',
    'hero_title'    => "Shop smarter.\nLive better.",
    'hero_text'     => 'Browse our growing collection of everyday essentials for home, travel and gifting.',
    'hero_image'    => 'assets/img/hero.jpg',

    'trust_1'       => 'Simple ordering',
    'trust_2'       => 'Clear pricing',
    'trust_3'       => 'Friendly support',

    'about_title'   => 'A smarter way to shop for what you need',
    'about_text'    => "Zorvo Group is a new online store built around one idea: good choices should feel easy.\n\nOur team will publish confirmed company details here before the store opens.",
    'about_image'   => 'assets/img/about.jpg',

    'currency'      => '$',
    'shipping_flat' => '0',
    'free_ship_over'=> '0',
    'tax_bp'        => '0',
    'payment_note'  => 'After you place your order, our team will contact you by email with payment instructions.',

    'contact_email' => '',
    'contact_phone' => '',
    'contact_address' => '',
    'footer_note'   => 'Store preview. Company details are being finalized.',

    'shipping_policy' => "This is a preview shipping and returns policy.\n\nBefore opening the store, replace this text with your real delivery areas, delivery times, shipping costs, return window and refund process.",
    'privacy'       => "This is a preview privacy notice.\n\nWhen you place an order or send a message, we store your name, email, phone number and delivery address so that we can respond and fulfil your order. Please do not submit payment card numbers or other sensitive information through this website.\n\nBefore opening the store, replace this text with an approved privacy policy that includes your retention period and contact details.",
    'terms'         => "These are preview terms of sale.\n\nBefore opening the store, replace this text with approved terms covering pricing, payment, delivery, returns, liability and governing law.",

    // '1' = the store accepts orders. '0' = preview mode (browsing and cart only).
    'store_live'    => '0',
];
