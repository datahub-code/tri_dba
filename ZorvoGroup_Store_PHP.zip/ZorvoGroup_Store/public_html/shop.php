<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';
require __DIR__ . '/includes/layout.php';

$s = settings();
$catSlug = is_string($_GET['cat'] ?? null) ? substr($_GET['cat'], 0, 120) : '';
$search = is_string($_GET['q'] ?? null) ? mb_substr(trim($_GET['q']), 0, 80, 'UTF-8') : '';
$sorts = [
    'new'        => ['Newest', 'p.id DESC'],
    'price_asc'  => ['Price: low to high', 'p.price_cents ASC, p.id DESC'],
    'price_desc' => ['Price: high to low', 'p.price_cents DESC, p.id DESC'],
    'name'       => ['Name: A to Z', 'p.name ASC'],
];
$sortKey = is_string($_GET['sort'] ?? null) && isset($sorts[$_GET['sort']]) ? $_GET['sort'] : 'new';

$where = ['p.is_active = 1'];
$params = [];
$currentCat = null;
if ($catSlug !== '') {
    $currentCat = q('SELECT id, name, slug, description FROM zg_categories WHERE slug = ?', [$catSlug])->fetch() ?: null;
    if ($currentCat) { $where[] = 'p.category_id = ?'; $params[] = (int)$currentCat['id']; } else { $where[] = '1 = 0'; }
}
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where[] = '(p.name LIKE ? OR p.short_desc LIKE ?)';
    $params[] = $like;
    $params[] = $like;
}
$whereSql = implode(' AND ', $where);
$total = (int)q("SELECT COUNT(*) FROM zg_products p WHERE $whereSql", $params)->fetchColumn();
$perPage = 12;
$pages = max(1, (int)ceil($total / $perPage));
$page = get_int('page', 1, 1, $pages);
$offset = ($page - 1) * $perPage;
$orderSql = $sorts[$sortKey][1]; // from the fixed whitelist above
$rows = q("SELECT p.* FROM zg_products p WHERE $whereSql ORDER BY $orderSql LIMIT $perPage OFFSET $offset", $params)->fetchAll();
$cats = q('SELECT name, slug FROM zg_categories ORDER BY sort_order, name')->fetchAll();

$qs = [];
if ($catSlug !== '') { $qs['cat'] = $catSlug; }
if ($search !== '') { $qs['q'] = $search; }
if ($sortKey !== 'new') { $qs['sort'] = $sortKey; }
$pagerBase = 'shop.php?' . ($qs ? http_build_query($qs) . '&' : '');

$title = $currentCat ? (string)$currentCat['name'] : ($search !== '' ? 'Search: ' . $search : 'All products');
page_header($s, $title);
?>
<section class="section shop">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow eyebrow-dark">SHOP</p>
      <h1 class="h1-sm"><?= e($title) ?></h1>
      <?php if ($currentCat && $currentCat['description'] !== ''): ?><p class="muted"><?= e($currentCat['description']) ?></p><?php endif; ?>
    </div>
    <div class="shop-layout">
      <aside class="filters" aria-label="Filters">
        <h2>Categories</h2>
        <ul>
          <li><a href="shop.php"<?= $catSlug === '' ? ' class="on"' : '' ?>>All products</a></li>
          <?php foreach ($cats as $c): ?>
            <li><a href="shop.php?cat=<?= e(rawurlencode((string)$c['slug'])) ?>"<?= $catSlug === $c['slug'] ? ' class="on"' : '' ?>><?= e($c['name']) ?></a></li>
          <?php endforeach; ?>
        </ul>
      </aside>
      <div class="results">
        <form class="sortbar" method="get" action="shop.php">
          <span class="muted"><?= e((string)$total) ?> product<?= $total === 1 ? '' : 's' ?></span>
          <?php if ($catSlug !== ''): ?><input type="hidden" name="cat" value="<?= e($catSlug) ?>"><?php endif; ?>
          <?php if ($search !== ''): ?><input type="hidden" name="q" value="<?= e($search) ?>"><?php endif; ?>
          <label class="sortlabel">Sort by
            <select name="sort" data-autosubmit>
              <?php foreach ($sorts as $key => [$label]): ?><option value="<?= e($key) ?>"<?= $key === $sortKey ? ' selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
            </select>
          </label>
          <button class="btn btn-outline btn-sm" type="submit">Apply</button>
        </form>
        <?php if ($rows): ?>
          <div class="pgrid"><?php foreach ($rows as $p) { product_card($p); } ?></div>
          <?php pager($pagerBase, $page, $pages); ?>
        <?php else: ?>
          <div class="empty"><p>No products found.</p><a class="btn btn-navy" href="shop.php">View all products</a></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php page_footer($s);
