<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';
require __DIR__ . '/includes/layout.php';

$s = settings();
if (!store_open()) { flash('Ordering is not open yet.'); redirect('cart.php'); }

$fields = ['name' => 100, 'email' => 254, 'phone' => 40, 'address1' => 150, 'address2' => 150, 'city' => 80, 'region' => 80, 'postal' => 20, 'country' => 60, 'notes' => 1000];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (limited('checkout', 15, 3600)) { fail(429, 'Too many attempts. Please try again later.'); }
    try {
        $c = [];
        foreach ($fields as $key => $max) { $c[$key] = str_replace("\r", '', text_field($key, $max)); }
        foreach (['name' => 'your name', 'address1' => 'your address', 'city' => 'your city', 'postal' => 'your postal code', 'country' => 'your country'] as $key => $label) {
            if ($c[$key] === '') { throw new UserError('Please enter ' . $label . '.'); }
        }
        if (!filter_var($c['email'], FILTER_VALIDATE_EMAIL)) { throw new UserError('Please enter a valid email address.'); }
        if (($_POST['consent'] ?? '') !== 'yes') { throw new UserError('Please accept the terms of sale and privacy notice to continue.'); }
        [$orderNo, $token] = place_order($c);
        redirect('order.php?no=' . rawurlencode($orderNo) . '&t=' . $token);
    } catch (UserError $ex) {
        $error = $ex->getMessage();
    }
}

$sum = cart_summary();
if (!$sum['lines']) { flash('Your cart is empty.'); redirect('cart.php'); }
if ($sum['changed']) { flash('Some items in your cart were updated because availability changed. Please review your order.'); }
$t = $sum['totals'];
$val = static function (string $key): string { return is_string($_POST[$key] ?? null) ? $_POST[$key] : ''; };

page_header($s, 'Checkout');
?>
<section class="section checkout-page">
  <div class="wrap">
    <h1 class="h1-sm">Checkout</h1>
    <?php if ($error !== ''): ?><div class="error" role="alert"><?= e($error) ?></div><?php endif; ?>
    <div class="cart-layout">
      <form class="form form-light" method="post" action="checkout.php" id="checkout-form">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <h2>Contact</h2>
        <label>Full name<input name="name" autocomplete="name" maxlength="100" value="<?= e($val('name')) ?>" required></label>
        <div class="two">
          <label>Email<input type="email" name="email" autocomplete="email" maxlength="254" value="<?= e($val('email')) ?>" required></label>
          <label>Phone (optional)<input type="tel" name="phone" autocomplete="tel" maxlength="40" value="<?= e($val('phone')) ?>"></label>
        </div>
        <h2>Delivery address</h2>
        <label>Address<input name="address1" autocomplete="address-line1" maxlength="150" value="<?= e($val('address1')) ?>" required></label>
        <label>Apartment, suite, etc. (optional)<input name="address2" autocomplete="address-line2" maxlength="150" value="<?= e($val('address2')) ?>"></label>
        <div class="two">
          <label>City<input name="city" autocomplete="address-level2" maxlength="80" value="<?= e($val('city')) ?>" required></label>
          <label>State / region<input name="region" autocomplete="address-level1" maxlength="80" value="<?= e($val('region')) ?>"></label>
        </div>
        <div class="two">
          <label>Postal code<input name="postal" autocomplete="postal-code" maxlength="20" value="<?= e($val('postal')) ?>" required></label>
          <label>Country<input name="country" autocomplete="country-name" maxlength="60" value="<?= e($val('country')) ?>" required></label>
        </div>
        <label>Order notes (optional)<textarea name="notes" rows="3" maxlength="1000"><?= e($val('notes')) ?></textarea></label>
        <h2>Payment</h2>
        <p class="notice-box"><?= e($s['payment_note']) ?></p>
        <p class="muted small">Please do not send card numbers or other payment details through this website.</p>
        <label class="check"><input type="checkbox" name="consent" value="yes" required><span>I agree to the <a href="page.php?p=terms" target="_blank" rel="noopener">terms of sale</a> and <a href="page.php?p=privacy" target="_blank" rel="noopener">privacy notice</a>.</span></label>
        <button class="btn btn-gold block" type="submit" data-once>Place order &middot; <?= e(money($t['total'])) ?></button>
      </form>
      <aside class="summary" aria-label="Order summary">
        <h2>Your order</h2>
        <ul class="mini">
          <?php foreach ($sum['lines'] as $l): ?>
            <li><span><?= e($l['name']) ?> &times; <?= e((string)$l['qty']) ?></span><strong><?= e(money($l['line_cents'])) ?></strong></li>
          <?php endforeach; ?>
        </ul>
        <dl>
          <div><dt>Subtotal</dt><dd><?= e(money($t['subtotal'])) ?></dd></div>
          <div><dt>Shipping</dt><dd><?= $t['shipping'] > 0 ? e(money($t['shipping'])) : 'Free' ?></dd></div>
          <?php if ($t['tax'] > 0): ?><div><dt>Tax</dt><dd><?= e(money($t['tax'])) ?></dd></div><?php endif; ?>
          <div class="grand"><dt>Total</dt><dd><?= e(money($t['total'])) ?></dd></div>
        </dl>
        <p><a href="cart.php">&larr; Edit cart</a></p>
      </aside>
    </div>
  </div>
</section>
<?php page_footer($s);
