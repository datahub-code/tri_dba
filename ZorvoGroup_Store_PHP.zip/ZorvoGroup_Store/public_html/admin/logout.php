<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION = [];
    session_regenerate_id(true);
    flash('You have been signed out.');
}
redirect('login.php');
