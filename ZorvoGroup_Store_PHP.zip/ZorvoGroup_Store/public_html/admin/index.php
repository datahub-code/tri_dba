<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';
require dirname(__DIR__) . '/includes/admin_ui.php';

$admin = admin_required();
$s = settings();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'remove_samples') {
    $pdo = db();
    $pdo->beginTransaction();
    try {
        q('UPDATE zg_order_items SET product_id = NULL WHERE product_id IN (SELECT id FROM zg_products WHERE is_sample = 1)');
        q('UPDATE zg_products SET category_id = NULL WHERE category_id IN (SELECT id FROM zg_categories WHERE is_sample = 1)');
        q('DELETE FROM zg_products WHERE is_sample = 1');
        q('DELETE FROM zg_categories WHERE is_sample = 1');
        $pdo->commit();
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        throw $ex;
    }
    flash('Sample products and categories were removed.');
    redirect('index.php');
}

$ordersTotal = (int)q('SELECT COUNT(*) FROM zg_orders')->fetchColumn();
$ordersPending = (int)q("SELECT COUNT(*) FROM zg_orders WHERE status = 'pending'")->fetchColumn();
$revenue = (int)q("SELECT COALESCE(SUM(total_cents), 0) FROM zg_orders WHERE status IN ('paid', 'shipped', 'completed')")->fetchColumn();
$productsActive = (int)q('SELECT COUNT(*) FROM zg_products WHERE is_active = 1')->fetchColumn();
$lowStock = q('SELECT id, name, stock FROM zg_products WHERE is_active = 1 AND stock <= 5 ORDER BY stock, id LIMIT 8')->fetchAll();
$samples = (int)q('SELECT COUNT(*) FROM zg_products WHERE is_sample = 1')->fetchColumn() + (int)q('SELECT COUNT(*) FROM zg_categories WHERE is_sample = 1')->fetchColumn();
$messages = (int)q('SELECT COUNT(*) FROM zg_inquiries')->fetchColumn();
$recent = q('SELECT id, order_no, customer_name, total_cents, status, created FROM zg_orders ORDER BY id DESC LIMIT 6')->fetchAll();

$todo = [];
if ($s['contact_email'] === '') { $todo[] = 'Add a public contact email in Store settings.'; }
if (str_contains((string)$s['privacy'], 'preview privacy notice')) { $todo[] = 'Replace the preview privacy notice with your approved policy.'; }
if (str_contains((string)$s['terms'], 'preview terms')) { $todo[] = 'Replace the preview terms of sale with your approved terms.'; }
if (str_contains((string)$s['shipping_policy'], 'preview shipping')) { $todo[] = 'Replace the preview shipping and returns policy with your real policy.'; }
if ($samples > 0) { $todo[] = 'Remove the sample products and add your real products.'; }

admin_header($s, $admin, 'Dashboard', 'dashboard');
?>
<?php if ($s['store_live'] !== '1'): ?>
  <div class="alert alert-warn"><strong>Your store is in preview mode.</strong> Visitors can browse and fill a cart but cannot place orders. Open it in <a href="settings.php">Store settings</a> when you are ready.</div>
<?php endif; ?>

<div class="stats">
  <div class="stat"><span class="stat-n"><?= e((string)$ordersTotal) ?></span><span class="stat-l">Orders</span></div>
  <div class="stat"><span class="stat-n"><?= e((string)$ordersPending) ?></span><span class="stat-l">Pending orders</span></div>
  <div class="stat"><span class="stat-n small"><?= e(money($revenue)) ?></span><span class="stat-l">Paid, shipped and completed orders</span></div>
  <div class="stat"><span class="stat-n"><?= e((string)$productsActive) ?></span><span class="stat-l">Active products</span></div>
  <div class="stat"><span class="stat-n"><?= e((string)$messages) ?></span><span class="stat-l">Contact messages</span></div>
</div>

<div class="grid-2">
  <section class="panel">
    <h2>Recent orders</h2>
    <?php if ($recent): ?>
      <table class="table"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead><tbody>
        <?php foreach ($recent as $o): ?>
          <tr><td><a href="order-view.php?id=<?= e((string)$o['id']) ?>"><?= e($o['order_no']) ?></a></td><td><?= e($o['customer_name']) ?></td><td><?= e(money((int)$o['total_cents'])) ?></td><td><?= status_badge((string)$o['status']) ?></td></tr>
        <?php endforeach; ?>
      </tbody></table>
      <p><a class="btn btn-outline btn-sm" href="orders.php">View all orders</a></p>
    <?php else: ?>
      <p class="muted">No orders yet.</p>
    <?php endif; ?>
  </section>
  <section class="panel">
    <h2>Before you launch</h2>
    <?php if ($todo): ?><ul class="todo"><?php foreach ($todo as $t): ?><li><?= e($t) ?></li><?php endforeach; ?></ul>
    <?php else: ?><p class="muted">Nothing outstanding. Nice work.</p><?php endif; ?>
    <?php if ($samples > 0): ?>
      <form method="post" action="index.php" class="confirm-form" data-confirm="Delete ALL sample products and categories? Real products you added are not affected.">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="remove_samples">
        <button class="btn btn-danger btn-sm" type="submit">Remove sample products</button>
      </form>
    <?php endif; ?>
  </section>
</div>

<?php if ($lowStock): ?>
<section class="panel">
  <h2>Low stock (5 or fewer)</h2>
  <ul class="todo"><?php foreach ($lowStock as $p): ?><li><a href="product-edit.php?id=<?= e((string)$p['id']) ?>"><?= e($p['name']) ?></a>: <?= (int)$p['stock'] < 1 ? 'sold out' : e((string)$p['stock']) . ' left' ?></li><?php endforeach; ?></ul>
</section>
<?php endif; ?>
<?php admin_footer();
