<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';
require dirname(__DIR__) . '/includes/admin_ui.php';

$admin = admin_required();
$s = settings();

$editId = get_int('edit', 0, 0, 999999999);
$edit = $editId > 0 ? (q('SELECT * FROM zg_categories WHERE id = ?', [$editId])->fetch() ?: null) : null;
$form = ['name' => $edit['name'] ?? '', 'description' => $edit['description'] ?? '', 'sort_order' => (string)($edit['sort_order'] ?? '0')];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : 'save';
    $targetId = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]) ?: 0;

    if ($action === 'delete') {
        $cat = $targetId > 0 ? q('SELECT id, image FROM zg_categories WHERE id = ?', [$targetId])->fetch() : false;
        if ($cat) {
            $pdo = db();
            $pdo->beginTransaction();
            try {
                q('UPDATE zg_products SET category_id = NULL WHERE category_id = ?', [(int)$cat['id']]);
                q('DELETE FROM zg_categories WHERE id = ?', [(int)$cat['id']]);
                $pdo->commit();
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                throw $ex;
            }
            remove_upload((string)$cat['image']);
            flash('Category deleted. Its products are now uncategorised.');
        }
        redirect('categories.php');
    }

    $moved = [];
    try {
        $existing = $targetId > 0 ? (q('SELECT * FROM zg_categories WHERE id = ?', [$targetId])->fetch() ?: null) : null;
        $name = text_field('name', 80);
        if ($name === '') { throw new UserError('Please enter a category name.'); }
        $desc = text_field('description', 300);
        $sort = filter_var(text_field('sort_order', 6), FILTER_VALIDATE_INT, ['options' => ['min_range' => -9999, 'max_range' => 9999]]);
        if ($sort === false) { throw new UserError('Sort order must be a whole number (lower numbers show first).'); }
        $slug = unique_slug('zg_categories', slugify($name), $existing ? (int)$existing['id'] : 0);
        $oldImage = $existing ? (string)$existing['image'] : '';
        $image = isset($_POST['remove_image']) ? '' : $oldImage;
        $uploaded = store_upload('image', $moved);
        if ($uploaded !== null) { $image = $uploaded; }
        if ($existing) {
            q('UPDATE zg_categories SET name = ?, slug = ?, description = ?, image = ?, sort_order = ?, is_sample = 0 WHERE id = ?', [$name, $slug, $desc, $image, $sort, (int)$existing['id']]);
            if ($oldImage !== '' && $oldImage !== $image) { remove_upload($oldImage); }
            flash('Category updated.');
        } else {
            q('INSERT INTO zg_categories (name, slug, description, image, sort_order, is_sample) VALUES (?, ?, ?, ?, ?, 0)', [$name, $slug, $desc, $image, $sort]);
            flash('Category added.');
        }
        redirect('categories.php');
    } catch (UserError $ex) {
        foreach ($moved as $file) { if (is_file($file)) { @unlink($file); } }
        flash('Not saved: ' . $ex->getMessage());
        $edit = $targetId > 0 ? (q('SELECT * FROM zg_categories WHERE id = ?', [$targetId])->fetch() ?: null) : null;
        $post = static function (string $k): string { return is_string($_POST[$k] ?? null) ? $_POST[$k] : ''; };
        $form = ['name' => $post('name'), 'description' => $post('description'), 'sort_order' => $post('sort_order')];
    }
}

$rows = q('SELECT c.*, (SELECT COUNT(*) FROM zg_products p WHERE p.category_id = c.id) AS product_count FROM zg_categories c ORDER BY c.sort_order, c.name')->fetchAll();

admin_header($s, $admin, 'Categories', 'categories');
?>
<div class="grid-2 cat-admin">
  <section class="panel">
    <h2><?= $edit ? 'Edit category' : 'Add a category' ?></h2>
    <form method="post" action="categories.php<?= $edit ? '?edit=' . e((string)$edit['id']) : '' ?>" enctype="multipart/form-data">
      <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= e((string)($edit['id'] ?? 0)) ?>">
      <?php input_row('name', 'Category name', (string)$form['name'], 80, 'text', 'required'); ?>
      <?php area_row('description', 'Short description (optional)', (string)$form['description'], 300, 2); ?>
      <?php input_row('sort_order', 'Sort order (lower shows first)', (string)$form['sort_order'], 6, 'number', 'required inputmode="numeric"'); ?>
      <?php image_row('image', 'Category image (shown on the home page)', $edit ? (string)$edit['image'] : '', 'remove_image'); ?>
      <button class="btn" type="submit"><?= $edit ? 'Save category' : 'Add category' ?></button>
      <?php if ($edit): ?><a class="btn btn-outline" href="categories.php">Cancel</a><?php endif; ?>
    </form>
  </section>

  <section class="panel">
    <h2>All categories</h2>
    <?php if ($rows): ?>
    <table class="table"><thead><tr><th>Name</th><th>Products</th><th></th></tr></thead><tbody>
      <?php foreach ($rows as $c): ?>
        <tr>
          <td><strong><?= e($c['name']) ?></strong><br><small>Order: <?= e((string)$c['sort_order']) ?></small></td>
          <td><?= e((string)$c['product_count']) ?></td>
          <td class="actions">
            <a class="btn btn-outline btn-sm" href="categories.php?edit=<?= e((string)$c['id']) ?>">Edit</a>
            <form method="post" action="categories.php" class="confirm-form inline-form" data-confirm="Delete this category? Its products are kept but become uncategorised.">
              <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e((string)$c['id']) ?>">
              <button class="btn btn-danger btn-sm" type="submit">Delete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody></table>
    <?php else: ?><p class="muted">No categories yet. Add your first one.</p><?php endif; ?>
  </section>
</div>
<?php admin_footer();
