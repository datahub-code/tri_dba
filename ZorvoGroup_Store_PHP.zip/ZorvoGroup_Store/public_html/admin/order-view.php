<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';
require dirname(__DIR__) . '/includes/admin_ui.php';

$admin = admin_required();
$s = settings();
$id = get_int('id', 0, 1, 999999999);
$order = q('SELECT * FROM zg_orders WHERE id = ?', [$id])->fetch();
if (!$order) { fail(404, 'Order not found.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    try {
        if ($action === 'status') {
            $new = is_string($_POST['status'] ?? null) ? $_POST['status'] : '';
            set_order_status($id, $new);
            flash($new === 'cancelled' ? 'Order cancelled and stock returned.' : 'Order status updated.');
        } elseif ($action === 'delete') {
            if ($order['status'] !== 'cancelled') { throw new UserError('Only cancelled orders can be deleted.'); }
            q('DELETE FROM zg_orders WHERE id = ?', [$id]);
            flash('Order deleted.');
            redirect('orders.php');
        }
    } catch (UserError $ex) {
        flash($ex->getMessage());
    }
    redirect('order-view.php?id=' . $id);
}

$items = q('SELECT name, sku, unit_cents, qty, line_cents FROM zg_order_items WHERE order_id = ? ORDER BY id', [$id])->fetchAll();
$addressText = implode("\n", array_filter([
    (string)$order['customer_name'],
    (string)$order['address1'],
    (string)$order['address2'],
    trim($order['city'] . ' ' . $order['region'] . ' ' . $order['postal']),
    (string)$order['country'],
], static fn(string $line): bool => $line !== ''));

admin_header($s, $admin, 'Order ' . $order['order_no'], 'orders');
?>
<p><a href="orders.php">&larr; All orders</a></p>
<div class="grid-2">
  <section class="panel">
    <h2>Status</h2>
    <p>Current status: <?= status_badge((string)$order['status']) ?></p>
    <?php if ($order['status'] === 'cancelled'): ?>
      <p class="muted">Cancelled orders are final. Stock was returned to the products.</p>
      <form method="post" action="order-view.php?id=<?= e((string)$id) ?>" class="confirm-form" data-confirm="Permanently delete this cancelled order?">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="delete">
        <button class="btn btn-danger btn-sm" type="submit">Delete order</button>
      </form>
    <?php else: ?>
      <form method="post" action="order-view.php?id=<?= e((string)$id) ?>" class="confirm-form" data-confirm="Change the order status? Choosing Cancelled returns the stock and cannot be undone.">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="status">
        <label>Change status
          <select name="status">
            <?php foreach (ORDER_STATUSES as $st): ?><option value="<?= e($st) ?>"<?= $st === $order['status'] ? ' selected' : '' ?>><?= e(ucfirst($st)) ?></option><?php endforeach; ?>
          </select>
        </label>
        <button class="btn" type="submit">Update status</button>
      </form>
      <p class="muted small">Pending = waiting for payment. No payment is taken on this website: contact the customer using the email below, then mark the order as paid when you receive payment.</p>
    <?php endif; ?>
  </section>
  <section class="panel">
    <h2>Customer</h2>
    <p class="prose"><?= e($addressText) ?></p>
    <p><a href="mailto:<?= e($order['customer_email']) ?>"><?= e($order['customer_email']) ?></a><?php if ($order['customer_phone'] !== ''): ?><br><?= e($order['customer_phone']) ?><?php endif; ?></p>
    <?php if (trim((string)$order['notes']) !== ''): ?><p class="small"><strong>Customer notes:</strong></p><p class="prose"><?= e($order['notes']) ?></p><?php endif; ?>
    <p class="muted small">Placed <?= e($order['created']) ?> UTC</p>
  </section>
</div>
<section class="panel">
  <h2>Items</h2>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Item</th><th>SKU</th><th>Price</th><th>Qty</th><th>Total</th></tr></thead>
    <tbody>
      <?php foreach ($items as $it): ?>
        <tr><td><?= e($it['name']) ?></td><td><?= e($it['sku'] ?? '') ?></td><td><?= e(money((int)$it['unit_cents'])) ?></td><td><?= e((string)$it['qty']) ?></td><td><?= e(money((int)$it['line_cents'])) ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
  <dl class="totals">
    <div><dt>Subtotal</dt><dd><?= e(money((int)$order['subtotal_cents'])) ?></dd></div>
    <div><dt>Shipping</dt><dd><?= e(money((int)$order['shipping_cents'])) ?></dd></div>
    <div><dt>Tax</dt><dd><?= e(money((int)$order['tax_cents'])) ?></dd></div>
    <div class="grand"><dt>Total</dt><dd><?= e(money((int)$order['total_cents'])) ?></dd></div>
  </dl>
</section>
<?php admin_footer();
