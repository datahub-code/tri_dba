<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';
require dirname(__DIR__) . '/includes/admin_ui.php';

$admin = admin_required();
$s = settings();

$id = get_int('id', 0, 0, 999999999);
$p = null;
if ($id > 0) {
    $p = q('SELECT * FROM zg_products WHERE id = ?', [$id])->fetch() ?: null;
    if ($p === null) { fail(404, 'Product not found.'); }
}

$cats = q('SELECT id, name FROM zg_categories ORDER BY sort_order, name')->fetchAll();

// Values shown in the form (replaced by the submitted values when saving fails).
$form = [
    'name' => $p['name'] ?? '', 'slug' => $p['slug'] ?? '', 'sku' => $p['sku'] ?? '',
    'category_id' => (string)($p['category_id'] ?? ''), 'short_desc' => $p['short_desc'] ?? '', 'description' => $p['description'] ?? '',
    'price' => $p ? cents_to_input((int)$p['price_cents']) : '', 'compare' => ($p && $p['compare_cents'] !== null) ? cents_to_input((int)$p['compare_cents']) : '',
    'stock' => (string)($p['stock'] ?? '0'), 'is_active' => $p ? (int)$p['is_active'] === 1 : true, 'is_featured' => $p ? (int)$p['is_featured'] === 1 : false,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : 'save';

    if ($action === 'delete' && $p !== null) {
        $pdo = db();
        $pdo->beginTransaction();
        try {
            q('UPDATE zg_order_items SET product_id = NULL WHERE product_id = ?', [$id]);
            q('DELETE FROM zg_products WHERE id = ?', [$id]);
            $pdo->commit();
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            throw $ex;
        }
        remove_upload((string)$p['image']);
        flash('Product deleted. Past orders keep their item details.');
        redirect('products.php');
    }

    $moved = [];
    try {
        $name = text_field('name', 160);
        if ($name === '') { throw new UserError('Please enter a product name.'); }
        $slugInput = text_field('slug', 190);
        $slug = unique_slug('zg_products', slugify($slugInput !== '' ? $slugInput : $name), $id);
        $sku = text_field('sku', 60);
        $shortDesc = str_replace("\r", '', text_field('short_desc', 300));
        $description = str_replace("\r", '', text_field('description', 10000));
        $price = parse_money(text_field('price', 12, true), 'Price');
        $compareRaw = text_field('compare', 12);
        $compare = $compareRaw === '' ? null : parse_money($compareRaw, 'Compare-at price');
        if ($compare !== null && $compare <= $price) { throw new UserError('The compare-at price must be higher than the price. Leave it empty if there is no discount.'); }
        $stock = filter_var(text_field('stock', 9), FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 1000000]]);
        if ($stock === false) { throw new UserError('Stock must be a whole number from 0 to 1,000,000.'); }
        $catId = filter_var(text_field('category_id', 9), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($catId !== false && !q('SELECT 1 FROM zg_categories WHERE id = ?', [$catId])->fetchColumn()) { $catId = false; }
        $active = isset($_POST['is_active']) ? 1 : 0;
        $featured = isset($_POST['is_featured']) ? 1 : 0;

        $oldImage = $p ? (string)$p['image'] : '';
        $image = $oldImage;
        if (isset($_POST['remove_image'])) { $image = ''; }
        $uploaded = store_upload('image', $moved);
        if ($uploaded !== null) { $image = $uploaded; }

        $skuValue = $sku === '' ? null : $sku;
        $catValue = $catId === false ? null : $catId;
        if ($p === null) {
            q('INSERT INTO zg_products (category_id, name, slug, sku, short_desc, description, price_cents, compare_cents, stock, image, is_active, is_featured, is_sample, created)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)',
              [$catValue, $name, $slug, $skuValue, $shortDesc, $description, $price, $compare, $stock, $image, $active, $featured, gmdate('Y-m-d H:i:s')]);
            $id = (int)db()->lastInsertId();
        } else {
            q('UPDATE zg_products SET category_id = ?, name = ?, slug = ?, sku = ?, short_desc = ?, description = ?, price_cents = ?, compare_cents = ?, stock = ?, image = ?, is_active = ?, is_featured = ?, is_sample = 0 WHERE id = ?',
              [$catValue, $name, $slug, $skuValue, $shortDesc, $description, $price, $compare, $stock, $image, $active, $featured, $id]);
            if ($oldImage !== '' && $oldImage !== $image) { remove_upload($oldImage); }
        }
        flash('Product saved.');
        redirect('product-edit.php?id=' . $id);
    } catch (UserError $ex) {
        foreach ($moved as $file) { if (is_file($file)) { @unlink($file); } }
        flash('Not saved: ' . $ex->getMessage());
        $post = static function (string $k): string { return is_string($_POST[$k] ?? null) ? $_POST[$k] : ''; };
        $form = [
            'name' => $post('name'), 'slug' => $post('slug'), 'sku' => $post('sku'), 'category_id' => $post('category_id'),
            'short_desc' => $post('short_desc'), 'description' => $post('description'), 'price' => $post('price'), 'compare' => $post('compare'),
            'stock' => $post('stock'), 'is_active' => isset($_POST['is_active']), 'is_featured' => isset($_POST['is_featured']),
        ];
    }
}

admin_header($s, $admin, $p ? 'Edit product' : 'Add product', 'products');
?>
<p><a href="products.php">&larr; All products</a><?php if ($p): ?> &middot; <a href="../product.php?slug=<?= e(rawurlencode((string)$p['slug'])) ?>" target="_blank" rel="noopener">View in store &#8599;</a><?php endif; ?></p>

<form method="post" action="product-edit.php<?= $p ? '?id=' . e((string)$id) : '' ?>" enctype="multipart/form-data">
  <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
  <input type="hidden" name="action" value="save">

  <section class="panel">
    <h2>Details</h2>
    <?php input_row('name', 'Product name', (string)$form['name'], 160, 'text', 'required'); ?>
    <div class="two">
      <label>Category
        <select name="category_id">
          <option value="">No category</option>
          <?php foreach ($cats as $c): ?><option value="<?= e((string)$c['id']) ?>"<?= (string)$form['category_id'] === (string)$c['id'] ? ' selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
        </select>
      </label>
      <?php input_row('sku', 'SKU (optional)', (string)$form['sku'], 60); ?>
    </div>
    <?php area_row('short_desc', 'Short description (shown on product tiles)', (string)$form['short_desc'], 300, 2); ?>
    <?php area_row('description', 'Full description', (string)$form['description'], 10000, 8); ?>
  </section>

  <section class="panel">
    <h2>Price &amp; stock</h2>
    <div class="three">
      <?php input_row('price', 'Price (' . $s['currency'] . ')', (string)$form['price'], 12, 'text', 'required inputmode="decimal"'); ?>
      <?php input_row('compare', 'Compare-at price (optional)', (string)$form['compare'], 12, 'text', 'inputmode="decimal"'); ?>
      <?php input_row('stock', 'Stock quantity', (string)$form['stock'], 9, 'number', 'min="0" required inputmode="numeric"'); ?>
    </div>
    <p class="muted small">Enter prices like 19.99. A compare-at price higher than the price shows the item as on sale. Stock goes down automatically when an order is placed.</p>
  </section>

  <section class="panel">
    <h2>Photo</h2>
    <?php image_row('image', 'Product image', $p ? (string)$p['image'] : '', 'remove_image'); ?>
    <p class="muted small">Use a square photo you own or have permission to use.</p>
  </section>

  <section class="panel">
    <h2>Visibility</h2>
    <?php check_row('is_active', 'Visible in the store', (bool)$form['is_active']); ?>
    <?php check_row('is_featured', 'Show in "Featured products" on the home page', (bool)$form['is_featured']); ?>
    <?php input_row('slug', 'Web address ending (optional)', (string)$form['slug'], 190); ?>
  </section>

  <div class="sticky-save"><button class="btn" type="submit">Save product</button><a class="btn btn-outline" href="products.php">Cancel</a></div>
</form>

<?php if ($p): ?>
<form method="post" action="product-edit.php?id=<?= e((string)$id) ?>" class="confirm-form danger-zone" data-confirm="Permanently delete this product? Past orders keep their item details.">
  <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="delete">
  <button class="btn btn-danger btn-sm" type="submit">Delete this product</button>
  <small>Tip: untick "Visible in the store" instead if you may sell it again.</small>
</form>
<?php endif; ?>
<?php admin_footer();
