<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';

$admin = admin_required();
$s = settings();
$search = is_string($_GET['q'] ?? null) ? mb_substr(trim($_GET['q']), 0, 80, 'UTF-8') : '';
$where = '1 = 1';
$params = [];
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where = '(p.name LIKE ? OR p.sku LIKE ?)';
    $params = [$like, $like];
}
$total = (int)q("SELECT COUNT(*) FROM zg_products p WHERE $where", $params)->fetchColumn();
$perPage = 25;
$pages = max(1, (int)ceil($total / $perPage));
$page = get_int('page', 1, 1, $pages);
$offset = ($page - 1) * $perPage;
$rows = q("SELECT p.*, c.name AS cat_name FROM zg_products p LEFT JOIN zg_categories c ON c.id = p.category_id WHERE $where ORDER BY p.id DESC LIMIT $perPage OFFSET $offset", $params)->fetchAll();

admin_header($s, $admin, 'Products', 'products');
?>
<div class="toolbar">
  <form method="get" action="products.php" class="inline-form"><input type="search" name="q" placeholder="Search name or SKU" maxlength="80" value="<?= e($search) ?>"><button class="btn btn-outline btn-sm" type="submit">Search</button></form>
  <a class="btn btn-sm" href="product-edit.php">+ Add product</a>
</div>
<?php if ($rows): ?>
<div class="table-wrap"><table class="table">
  <thead><tr><th></th><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $p): $img = safe_image($p['image']); ?>
    <tr>
      <td class="thumb"><?php if ($img !== ''): ?><img src="../<?= e($img) ?>" alt="" width="48" height="48"><?php endif; ?></td>
      <td><a href="product-edit.php?id=<?= e((string)$p['id']) ?>"><strong><?= e($p['name']) ?></strong></a><?php if ($p['sku'] !== null && $p['sku'] !== ''): ?><br><small><?= e($p['sku']) ?></small><?php endif; ?></td>
      <td><?= e($p['cat_name'] ?? '-') ?></td>
      <td><?= e(money((int)$p['price_cents'])) ?></td>
      <td><?= (int)$p['stock'] < 1 ? '<span class="pill pill-cancelled">Sold out</span>' : e((string)$p['stock']) ?></td>
      <td><?= (int)$p['is_active'] === 1 ? '<span class="pill pill-completed">Visible</span>' : '<span class="pill pill-pending">Hidden</span>' ?></td>
      <td><a class="btn btn-outline btn-sm" href="product-edit.php?id=<?= e((string)$p['id']) ?>">Edit</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php pager('products.php?' . ($search !== '' ? http_build_query(['q' => $search]) . '&' : ''), $page, $pages); ?>
<?php else: ?>
  <div class="panel"><p class="muted">No products found. <a href="product-edit.php">Add your first product</a>.</p></div>
<?php endif; ?>
<?php admin_footer();
