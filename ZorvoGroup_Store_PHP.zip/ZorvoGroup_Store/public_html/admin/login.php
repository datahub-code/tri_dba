<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');

if (!empty($_SESSION['admin_id'])) { redirect('index.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (limited('login', 10, 900)) { fail(429, 'Too many sign-in attempts. Please wait 15 minutes and try again.'); }
    try {
        $username = text_field('username', 100);
        $password = text_field('password', 72, false);
    } catch (UserError $ex) {
        flash('Invalid username or password.');
        redirect('login.php');
    }
    $row = q('SELECT id, password, version FROM zg_admins WHERE username = ?', [$username])->fetch();
    // Always verify against a hash so the response time does not reveal valid usernames.
    $hash = $row ? $row['password'] : '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
    $ok = password_verify($password, (string)$hash);
    if ($row && $ok) {
        session_regenerate_id(true);
        $_SESSION = [];
        $_SESSION['admin_id'] = (int)$row['id'];
        $_SESSION['admin_version'] = (int)$row['version'];
        $_SESSION['last_seen'] = time();
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        redirect('index.php');
    }
    flash('Invalid username or password.');
    redirect('login.php');
}
$messages = take_flashes();
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Admin sign in</title>
<link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="login-body">
<main class="login-card">
  <div class="login-brand"><span class="logo-mark">Z</span><div><strong>Store admin</strong><small>SIGN IN</small></div></div>
  <h1>Welcome back</h1>
  <p class="muted">Sign in to manage your store.</p>
  <?php foreach ($messages as $m): ?><div class="alert" role="alert"><?= e($m) ?></div><?php endforeach; ?>
  <form method="post" action="login.php">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <label>Username<input name="username" autocomplete="username" maxlength="100" required autofocus></label>
    <label>Password<input type="password" name="password" autocomplete="current-password" maxlength="72" required></label>
    <button class="btn" type="submit">Sign in</button>
  </form>
  <p class="back"><a href="../index.php">← Back to website</a></p>
</main>
</body>
</html>
