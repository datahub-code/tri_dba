<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';
require dirname(__DIR__) . '/includes/admin_ui.php';

$admin = admin_required();
$s = settings();
$view = $s; // values shown in the form

// Plain text settings and their maximum lengths (characters).
$textFields = [
    'store_name' => 60, 'tagline' => 120,
    'hero_eyebrow' => 80, 'hero_title' => 120, 'hero_text' => 400,
    'trust_1' => 60, 'trust_2' => 60, 'trust_3' => 60,
    'about_title' => 140, 'about_text' => 2000,
    'payment_note' => 600,
    'contact_email' => 254, 'contact_phone' => 40, 'contact_address' => 300,
    'footer_note' => 300,
    'shipping_policy' => 10000, 'privacy' => 10000, 'terms' => 10000,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $moved = [];
    $new = [];
    try {
        foreach ($textFields as $key => $max) { $new[$key] = str_replace("\r", '', text_field($key, $max)); }
        if ($new['store_name'] === '') { throw new UserError('The store name cannot be empty.'); }
        if ($new['contact_email'] !== '' && !filter_var($new['contact_email'], FILTER_VALIDATE_EMAIL)) { throw new UserError('Please enter a valid contact email address, or leave it blank.'); }

        $currency = text_field('currency', 5);
        if ($currency === '') { throw new UserError('Please enter a currency symbol such as $, EUR or GBP.'); }
        $new['currency'] = $currency;
        $new['shipping_flat'] = (string)parse_money(text_field('shipping_flat', 12) ?: '0', 'Shipping cost');
        $new['free_ship_over'] = (string)parse_money(text_field('free_ship_over', 12) ?: '0', 'Free shipping threshold');
        $new['tax_bp'] = (string)parse_percent_bp(text_field('tax_percent', 6) ?: '0', 'Tax rate');
        $new['store_live'] = isset($_POST['store_live']) ? '1' : '0';

        if ($new['store_live'] === '1') {
            if ($new['contact_email'] === '') { throw new UserError('Add a public contact email before opening the store to orders.'); }
            if (trim($new['payment_note']) === '') { throw new UserError('Add the payment instructions note before opening the store to orders.'); }
        }

        $oldHero = (string)$s['hero_image'];
        $oldAbout = (string)$s['about_image'];
        $hero = store_upload('hero_image', $moved) ?? $oldHero;
        $about = isset($_POST['remove_about_image']) ? '' : $oldAbout;
        $about = store_upload('about_image', $moved) ?? $about;
        $new['hero_image'] = $hero;
        $new['about_image'] = $about;

        save_settings($new);
        if ($oldHero !== $hero) { remove_upload($oldHero); }
        if ($oldAbout !== $about) { remove_upload($oldAbout); }
        flash($new['store_live'] === '1' ? 'Settings saved. Your store is OPEN for orders.' : 'Settings saved. Your store is in preview mode (orders are not accepted).');
        redirect('settings.php');
    } catch (UserError $ex) {
        foreach ($moved as $file) { if (is_file($file)) { @unlink($file); } }
        flash('Not saved: ' . $ex->getMessage());
        $post = static function (string $k): string { return is_string($_POST[$k] ?? null) ? $_POST[$k] : ''; };
        foreach ($textFields as $key => $max) { $view[$key] = $post($key); }
        $view['currency'] = $post('currency');
        $view['store_live'] = isset($_POST['store_live']) ? '1' : '0';
        $formMoney = ['shipping' => $post('shipping_flat'), 'free' => $post('free_ship_over'), 'tax' => $post('tax_percent')];
    }
}
$formMoney = $formMoney ?? [
    'shipping' => cents_to_input((int)$s['shipping_flat']),
    'free' => cents_to_input((int)$s['free_ship_over']),
    'tax' => bp_to_input((int)$s['tax_bp']),
];

admin_header($s, $admin, 'Store settings', 'settings');
?>
<p class="muted">Edit your store's text, pictures, shipping, tax and policies. Press <strong>Save settings</strong> at the bottom. Only upload images you own or have permission to use.</p>

<form method="post" action="settings.php" enctype="multipart/form-data" class="editor-form">
  <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">

  <details class="panel" open>
    <summary>Store status</summary>
    <div class="fields">
      <?php check_row('store_live', 'Open the store for orders (customers can check out)', $view['store_live'] === '1'); ?>
      <p class="muted small">While this is off, visitors can browse and use the cart but cannot place orders. Before opening: add real products, a contact email, payment instructions, and replace the preview policies. This website does not take card payments; you collect payment yourself after each order.</p>
    </div>
  </details>

  <details class="panel">
    <summary>Store name &amp; home page banner</summary>
    <div class="fields">
      <?php input_row('store_name', 'Store name', (string)$view['store_name'], 60, 'text', 'required'); ?>
      <?php input_row('tagline', 'Tagline', (string)$view['tagline'], 120); ?>
      <?php input_row('hero_eyebrow', 'Banner small heading', (string)$view['hero_eyebrow'], 80); ?>
      <?php area_row('hero_title', 'Banner headline (a new line breaks it)', (string)$view['hero_title'], 120, 2); ?>
      <?php area_row('hero_text', 'Banner text', (string)$view['hero_text'], 400, 3); ?>
      <?php image_row('hero_image', 'Banner image', (string)$s['hero_image']); ?>
      <h3>Highlights under the banner</h3>
      <?php input_row('trust_1', 'Highlight 1', (string)$view['trust_1'], 60); ?>
      <?php input_row('trust_2', 'Highlight 2', (string)$view['trust_2'], 60); ?>
      <?php input_row('trust_3', 'Highlight 3', (string)$view['trust_3'], 60); ?>
      <p class="muted small">Only state things that are true for your business.</p>
    </div>
  </details>

  <details class="panel">
    <summary>Shipping, tax &amp; payment</summary>
    <div class="fields">
      <?php input_row('currency', 'Currency symbol', (string)$view['currency'], 5, 'text', 'required'); ?>
      <?php input_row('shipping_flat', 'Flat shipping cost per order', $formMoney['shipping'], 12, 'text', 'inputmode="decimal"'); ?>
      <?php input_row('free_ship_over', 'Free shipping when items total at least (0 = never free)', $formMoney['free'], 12, 'text', 'inputmode="decimal"'); ?>
      <?php input_row('tax_percent', 'Sales tax rate in % (0 = none)', $formMoney['tax'], 6, 'text', 'inputmode="decimal"'); ?>
      <p class="muted small">Tax is one flat rate applied to the items total. Confirm what tax you must charge with a qualified adviser.</p>
      <?php area_row('payment_note', 'Payment instructions shown at checkout and on the order page', (string)$view['payment_note'], 600, 3); ?>
    </div>
  </details>

  <details class="panel">
    <summary>About section</summary>
    <div class="fields">
      <?php input_row('about_title', 'Heading', (string)$view['about_title'], 140); ?>
      <?php area_row('about_text', 'Text (leave a blank line between paragraphs)', (string)$view['about_text'], 2000, 6); ?>
      <?php image_row('about_image', 'About image', (string)$s['about_image'], 'remove_about_image'); ?>
    </div>
  </details>

  <details class="panel">
    <summary>Contact details &amp; footer</summary>
    <div class="fields">
      <?php input_row('contact_email', 'Public contact email', (string)$view['contact_email'], 254, 'email'); ?>
      <?php input_row('contact_phone', 'Phone (optional)', (string)$view['contact_phone'], 40); ?>
      <?php input_row('contact_address', 'Business address (optional)', (string)$view['contact_address'], 300); ?>
      <?php area_row('footer_note', 'Footer note', (string)$view['footer_note'], 300, 2); ?>
    </div>
  </details>

  <details class="panel">
    <summary>Shipping &amp; returns, privacy and terms</summary>
    <div class="fields">
      <p class="muted">These are preview texts. Replace them with policies approved for your business before opening the store.</p>
      <?php area_row('shipping_policy', 'Shipping and returns policy', (string)$view['shipping_policy'], 10000, 9); ?>
      <?php area_row('privacy', 'Privacy notice', (string)$view['privacy'], 10000, 9); ?>
      <?php area_row('terms', 'Terms of sale', (string)$view['terms'], 10000, 9); ?>
    </div>
  </details>

  <div class="sticky-save"><button class="btn" type="submit">Save settings</button><a class="btn btn-outline" href="../index.php" target="_blank" rel="noopener">View store &#8599;</a></div>
</form>
<?php admin_footer();
