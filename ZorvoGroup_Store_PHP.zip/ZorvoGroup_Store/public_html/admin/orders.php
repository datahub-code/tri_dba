<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';
require dirname(__DIR__) . '/includes/admin_ui.php';

$admin = admin_required();
$s = settings();
$status = is_string($_GET['status'] ?? null) && in_array($_GET['status'], ORDER_STATUSES, true) ? $_GET['status'] : '';
$search = is_string($_GET['q'] ?? null) ? mb_substr(trim($_GET['q']), 0, 80, 'UTF-8') : '';

$where = ['1 = 1'];
$params = [];
if ($status !== '') { $where[] = 'status = ?'; $params[] = $status; }
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where[] = '(order_no LIKE ? OR customer_email LIKE ? OR customer_name LIKE ?)';
    array_push($params, $like, $like, $like);
}
$whereSql = implode(' AND ', $where);
$total = (int)q("SELECT COUNT(*) FROM zg_orders WHERE $whereSql", $params)->fetchColumn();
$perPage = 25;
$pages = max(1, (int)ceil($total / $perPage));
$page = get_int('page', 1, 1, $pages);
$offset = ($page - 1) * $perPage;
$rows = q("SELECT id, order_no, customer_name, customer_email, total_cents, status, created FROM zg_orders WHERE $whereSql ORDER BY id DESC LIMIT $perPage OFFSET $offset", $params)->fetchAll();

$qs = [];
if ($status !== '') { $qs['status'] = $status; }
if ($search !== '') { $qs['q'] = $search; }

admin_header($s, $admin, 'Orders', 'orders');
?>
<div class="toolbar">
  <form method="get" action="orders.php" class="inline-form">
    <select name="status" aria-label="Filter by status">
      <option value="">All statuses</option>
      <?php foreach (ORDER_STATUSES as $st): ?><option value="<?= e($st) ?>"<?= $st === $status ? ' selected' : '' ?>><?= e(ucfirst($st)) ?></option><?php endforeach; ?>
    </select>
    <input type="search" name="q" placeholder="Order no., name or email" maxlength="80" value="<?= e($search) ?>">
    <button class="btn btn-outline btn-sm" type="submit">Filter</button>
  </form>
  <span class="muted"><?= e((string)$total) ?> order<?= $total === 1 ? '' : 's' ?></span>
</div>
<?php if ($rows): ?>
<div class="table-wrap"><table class="table">
  <thead><tr><th>Order</th><th>Date (UTC)</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $o): ?>
    <tr>
      <td><a href="order-view.php?id=<?= e((string)$o['id']) ?>"><strong><?= e($o['order_no']) ?></strong></a></td>
      <td><?= e($o['created']) ?></td>
      <td><?= e($o['customer_name']) ?><br><small><?= e($o['customer_email']) ?></small></td>
      <td><?= e(money((int)$o['total_cents'])) ?></td>
      <td><?= status_badge((string)$o['status']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php pager('orders.php?' . ($qs ? http_build_query($qs) . '&' : ''), $page, $pages); ?>
<?php else: ?>
  <div class="panel"><p class="muted">No orders found.</p></div>
<?php endif; ?>
<?php admin_footer();
