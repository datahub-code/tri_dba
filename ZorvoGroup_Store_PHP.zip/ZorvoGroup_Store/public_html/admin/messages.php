<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';

$admin = admin_required();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!$id) { fail(400, 'Invalid message ID.'); }
    q('DELETE FROM zg_inquiries WHERE id = ?', [$id]);
    flash('Message deleted.');
    redirect('messages.php');
}

$s = settings();
$leads = q('SELECT id, name, email, message, created FROM zg_inquiries ORDER BY id DESC LIMIT 200')->fetchAll();
admin_header($s, $admin, 'Messages', 'messages');
?>
<p class="muted">Latest 200 messages from the contact form. Email notifications are not configured, so check here regularly.</p>
<?php if (!$leads): ?>
  <div class="panel"><p class="muted">Your inbox is clear. New messages will appear here.</p></div>
<?php endif; ?>
<?php foreach ($leads as $lead): ?>
  <article class="panel msg">
    <div class="msg-head">
      <div><strong><?= e($lead['name']) ?></strong> <a href="mailto:<?= e($lead['email']) ?>"><?= e($lead['email']) ?></a></div>
      <small>#<?= e($lead['id']) ?> · <?= e($lead['created']) ?> UTC</small>
    </div>
    <p class="msg-body"><?= e($lead['message']) ?></p>
    <form method="post" action="messages.php" class="confirm-form" data-confirm="Permanently delete this message?">
      <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
      <input type="hidden" name="id" value="<?= e($lead['id']) ?>">
      <button class="btn btn-danger btn-sm" type="submit">Delete</button>
    </form>
  </article>
<?php endforeach; ?>
<?php admin_footer();
