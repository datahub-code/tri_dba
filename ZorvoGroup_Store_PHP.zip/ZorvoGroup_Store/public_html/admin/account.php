<?php
declare(strict_types=1);
define('ZG_APP', true);
define('ZG_ADMIN', true);
require dirname(__DIR__) . '/includes/bootstrap.php';
require dirname(__DIR__) . '/includes/store.php';
require dirname(__DIR__) . '/includes/layout.php';

$admin = admin_required();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (limited('password', 10, 900)) { fail(429, 'Too many attempts. Please try again later.'); }
    try {
        $current = text_field('current', 72, false);
        $new     = text_field('new', 72, false);
        $confirm = text_field('confirm', 72, false);
    } catch (UserError $ex) {
        flash('Passwords can be at most 72 characters long.');
        redirect('account.php');
    }
    $hash = (string)q('SELECT password FROM zg_admins WHERE id = ?', [$admin['id']])->fetchColumn();
    if (!password_verify($current, $hash)) {
        flash('Your current password is not correct.');
    } elseif (strlen($new) < 16 || strlen($new) > 72) {
        flash('The new password must be 16 to 72 characters.');
    } elseif (!hash_equals($new, $confirm)) {
        flash('The new password and confirmation do not match.');
    } else {
        q('UPDATE zg_admins SET password = ?, version = version + 1 WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $admin['id']]);
        $_SESSION = [];
        session_regenerate_id(true);
        flash('Password changed. Please sign in again.');
        redirect('login.php');
    }
    redirect('account.php');
}

$s = settings();
admin_header($s, $admin, 'Account', 'account');
?>
<section class="panel narrow-panel">
  <h2>Change password</h2>
  <p class="muted">Use at least 16 characters. A password manager is recommended. Changing it signs out all admin sessions.</p>
  <form method="post" action="account.php">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <label>Current password<input type="password" name="current" autocomplete="current-password" maxlength="72" required></label>
    <label>New password<input type="password" name="new" autocomplete="new-password" minlength="16" maxlength="72" required></label>
    <label>Confirm new password<input type="password" name="confirm" autocomplete="new-password" minlength="16" maxlength="72" required></label>
    <button class="btn" type="submit">Update password</button>
  </form>
</section>
<?php admin_footer();
