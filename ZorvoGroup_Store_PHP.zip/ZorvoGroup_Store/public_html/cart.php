<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';
require __DIR__ . '/includes/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    $cart = cart_get();

    if ($action === 'add') {
        $id = filter_var($_POST['product_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $qty = filter_var($_POST['qty'] ?? 1, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => MAX_LINE_QTY]]);
        if (!$id || !$qty) { flash('Please choose a quantity between 1 and ' . MAX_LINE_QTY . '.'); redirect('cart.php'); }
        $p = q('SELECT id, name, stock FROM zg_products WHERE id = ? AND is_active = 1', [$id])->fetch();
        if (!$p || (int)$p['stock'] < 1) { flash('Sorry, that item is not available.'); redirect('cart.php'); }
        $before = (int)($cart[$id] ?? 0);
        $after = min(MAX_LINE_QTY, (int)$p['stock'], $before + $qty);
        $cart[$id] = $after;
        cart_set($cart);
        flash($after - $before < $qty
            ? '"' . $p['name'] . '" was added, limited to the quantity currently available.'
            : '"' . $p['name'] . '" was added to your cart.');
        redirect('cart.php');
    }

    if ($action === 'update') {
        if (isset($_POST['remove']) && is_string($_POST['remove']) && ctype_digit($_POST['remove'])) {
            unset($cart[(int)$_POST['remove']]);
            cart_set($cart);
            flash('Item removed from your cart.');
            redirect('cart.php');
        }
        $qtys = $_POST['qty'] ?? [];
        if (is_array($qtys)) {
            foreach ($qtys as $rawId => $v) {
                $id = (int)$rawId;
                if (!isset($cart[$id])) { continue; }
                $n = (is_string($v) && ctype_digit($v) && strlen($v) <= 3) ? (int)$v : 0;
                if ($n < 1) { unset($cart[$id]); } else { $cart[$id] = min($n, MAX_LINE_QTY); }
            }
        }
        cart_set($cart);
        flash('Cart updated.');
        redirect('cart.php');
    }
    redirect('cart.php');
}

$s = settings();
$sum = cart_summary();
if ($sum['changed']) { flash('Some items in your cart were updated because availability changed.'); }
$t = $sum['totals'];
$freeOver = (int)$s['free_ship_over'];

page_header($s, 'Your cart');
?>
<section class="section cart-page">
  <div class="wrap">
    <h1 class="h1-sm">Your cart</h1>
    <?php if (!$sum['lines']): ?>
      <div class="empty"><p>Your cart is empty.</p><a class="btn btn-navy" href="shop.php">Start shopping</a></div>
    <?php else: ?>
    <div class="cart-layout">
      <form class="cart-lines" method="post" action="cart.php">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <input type="hidden" name="action" value="update">
        <button class="sr" type="submit" tabindex="-1" aria-hidden="true">Update cart</button><?php /* default button: pressing Enter in a quantity box updates the cart instead of removing the first item */ ?>
        <?php foreach ($sum['lines'] as $l): $li = safe_image($l['image']); ?>
          <div class="line">
            <a class="line-img" href="product.php?slug=<?= e(rawurlencode($l['slug'])) ?>"><?php if ($li !== ''): ?><img src="<?= e($li) ?>" alt="" width="120" height="120"><?php else: ?><span class="noimg">No image</span><?php endif; ?></a>
            <div class="line-info">
              <a class="line-name" href="product.php?slug=<?= e(rawurlencode($l['slug'])) ?>"><?= e($l['name']) ?></a>
              <span class="muted"><?= e(money($l['unit_cents'])) ?> each</span>
              <button class="link-remove" type="submit" name="remove" value="<?= e((string)$l['id']) ?>">Remove</button>
            </div>
            <label class="line-qty">Qty
              <input type="number" name="qty[<?= e((string)$l['id']) ?>]" value="<?= e((string)$l['qty']) ?>" min="0" max="<?= e((string)$l['max_qty']) ?>" inputmode="numeric">
            </label>
            <strong class="line-total"><?= e(money($l['line_cents'])) ?></strong>
          </div>
        <?php endforeach; ?>
        <div class="cart-actions"><a class="btn btn-outline" href="shop.php">Continue shopping</a><button class="btn btn-navy" type="submit">Update cart</button></div>
      </form>
      <aside class="summary" aria-label="Order summary">
        <h2>Order summary</h2>
        <dl>
          <div><dt>Subtotal</dt><dd><?= e(money($t['subtotal'])) ?></dd></div>
          <div><dt>Shipping</dt><dd><?= $t['shipping'] > 0 ? e(money($t['shipping'])) : 'Free' ?></dd></div>
          <?php if ($t['tax'] > 0): ?><div><dt>Tax</dt><dd><?= e(money($t['tax'])) ?></dd></div><?php endif; ?>
          <div class="grand"><dt>Total</dt><dd><?= e(money($t['total'])) ?></dd></div>
        </dl>
        <?php if ($freeOver > 0 && $t['subtotal'] < $freeOver): ?><p class="muted small">Add <?= e(money($freeOver - $t['subtotal'])) ?> more for free shipping.</p><?php endif; ?>
        <?php if (store_open()): ?>
          <a class="btn btn-gold block" href="checkout.php">Proceed to checkout</a>
        <?php else: ?>
          <p class="notice-box">Ordering is not open yet. Your cart is saved while you browse.</p>
        <?php endif; ?>
      </aside>
    </div>
    <?php endif; ?>
  </div>
</section>
<?php page_footer($s);
