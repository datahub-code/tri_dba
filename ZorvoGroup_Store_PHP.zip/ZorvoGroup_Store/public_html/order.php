<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';
require __DIR__ . '/includes/layout.php';

$s = settings();
$no = is_string($_GET['no'] ?? null) ? substr($_GET['no'], 0, 20) : '';
$token = is_string($_GET['t'] ?? null) ? substr($_GET['t'], 0, 64) : '';
$order = $no !== '' ? q('SELECT * FROM zg_orders WHERE order_no = ?', [$no])->fetch() : false;
if (!$order || !hash_equals((string)$order['access_token'], $token)) {
    http_response_code(404);
    fail(404, 'Order not found. Please use the link shown after checkout.');
}
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');
$items = q('SELECT name, unit_cents, qty, line_cents FROM zg_order_items WHERE order_id = ? ORDER BY id', [(int)$order['id']])->fetchAll();

$addressText = implode("\n", array_filter([
    (string)$order['customer_name'],
    (string)$order['address1'],
    (string)$order['address2'],
    trim($order['city'] . ' ' . $order['region'] . ' ' . $order['postal']),
    (string)$order['country'],
], static fn(string $line): bool => $line !== ''));

page_header($s, 'Order ' . $order['order_no']);
?>
<section class="section order-page">
  <div class="wrap narrow">
    <p class="eyebrow eyebrow-dark">THANK YOU</p>
    <h1 class="h1-sm">Order <?= e($order['order_no']) ?></h1>
    <p>Status: <strong class="status status-<?= e($order['status']) ?>"><?= e(ucfirst((string)$order['status'])) ?></strong></p>
    <?php if ($order['status'] === 'pending'): ?><div class="notice-box"><?= e($s['payment_note']) ?></div><?php endif; ?>
    <p class="muted small">Keep this page's link to check your order later. We do not send automatic emails from this website, so please bookmark it.</p>
    <div class="panel-plain">
      <h2>Items</h2>
      <ul class="mini">
        <?php foreach ($items as $it): ?><li><span><?= e($it['name']) ?> &times; <?= e((string)$it['qty']) ?></span><strong><?= e(money((int)$it['line_cents'])) ?></strong></li><?php endforeach; ?>
      </ul>
      <dl>
        <div><dt>Subtotal</dt><dd><?= e(money((int)$order['subtotal_cents'])) ?></dd></div>
        <div><dt>Shipping</dt><dd><?= (int)$order['shipping_cents'] > 0 ? e(money((int)$order['shipping_cents'])) : 'Free' ?></dd></div>
        <?php if ((int)$order['tax_cents'] > 0): ?><div><dt>Tax</dt><dd><?= e(money((int)$order['tax_cents'])) ?></dd></div><?php endif; ?>
        <div class="grand"><dt>Total</dt><dd><?= e(money((int)$order['total_cents'])) ?></dd></div>
      </dl>
    </div>
    <div class="panel-plain">
      <h2>Delivery details</h2>
      <p class="prose"><?= e($addressText) ?></p>
    </div>
    <p><a class="btn btn-navy" href="shop.php">Continue shopping</a></p>
  </div>
</section>
<?php page_footer($s);
