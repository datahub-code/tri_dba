<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';
require __DIR__ . '/includes/layout.php';

$key = (string)($config['setup_key'] ?? '');
if (strlen($key) < 32 || str_contains($key, 'REPLACE_')) {
    fail(503, 'Set your own unique setup_key (32 or more characters) in zorvo-config.php first.');
}

$schema = [
    'CREATE TABLE IF NOT EXISTS zg_settings (k VARCHAR(60) NOT NULL PRIMARY KEY, v MEDIUMTEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
    'CREATE TABLE IF NOT EXISTS zg_admins (id INT NOT NULL PRIMARY KEY, username VARCHAR(100) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, version INT NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
    'CREATE TABLE IF NOT EXISTS zg_categories (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(80) NOT NULL,
        slug VARCHAR(100) NOT NULL UNIQUE,
        description VARCHAR(300) NOT NULL DEFAULT \'\',
        image VARCHAR(255) NOT NULL DEFAULT \'\',
        sort_order INT NOT NULL DEFAULT 0,
        is_sample TINYINT NOT NULL DEFAULT 0
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
    'CREATE TABLE IF NOT EXISTS zg_products (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        category_id INT UNSIGNED NULL,
        name VARCHAR(160) NOT NULL,
        slug VARCHAR(190) NOT NULL UNIQUE,
        sku VARCHAR(60) NULL,
        short_desc VARCHAR(300) NOT NULL DEFAULT \'\',
        description TEXT NOT NULL,
        price_cents INT UNSIGNED NOT NULL,
        compare_cents INT UNSIGNED NULL,
        stock INT NOT NULL DEFAULT 0,
        image VARCHAR(255) NOT NULL DEFAULT \'\',
        is_active TINYINT NOT NULL DEFAULT 1,
        is_featured TINYINT NOT NULL DEFAULT 0,
        is_sample TINYINT NOT NULL DEFAULT 0,
        created DATETIME NOT NULL,
        KEY idx_category (category_id),
        KEY idx_active (is_active, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
    'CREATE TABLE IF NOT EXISTS zg_orders (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        order_no VARCHAR(20) NOT NULL UNIQUE,
        access_token CHAR(32) NOT NULL,
        status VARCHAR(20) NOT NULL,
        customer_name VARCHAR(100) NOT NULL,
        customer_email VARCHAR(254) NOT NULL,
        customer_phone VARCHAR(40) NOT NULL DEFAULT \'\',
        address1 VARCHAR(150) NOT NULL,
        address2 VARCHAR(150) NOT NULL DEFAULT \'\',
        city VARCHAR(80) NOT NULL,
        region VARCHAR(80) NOT NULL DEFAULT \'\',
        postal VARCHAR(20) NOT NULL,
        country VARCHAR(60) NOT NULL,
        notes TEXT NOT NULL,
        subtotal_cents INT UNSIGNED NOT NULL,
        shipping_cents INT UNSIGNED NOT NULL,
        tax_cents INT UNSIGNED NOT NULL,
        total_cents INT UNSIGNED NOT NULL,
        restocked TINYINT NOT NULL DEFAULT 0,
        created DATETIME NOT NULL,
        KEY idx_status (status, id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
    'CREATE TABLE IF NOT EXISTS zg_order_items (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        order_id BIGINT UNSIGNED NOT NULL,
        product_id INT UNSIGNED NULL,
        name VARCHAR(160) NOT NULL,
        sku VARCHAR(60) NULL,
        unit_cents INT UNSIGNED NOT NULL,
        qty INT UNSIGNED NOT NULL,
        line_cents INT UNSIGNED NOT NULL,
        KEY idx_order (order_id),
        CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES zg_orders (id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
    'CREATE TABLE IF NOT EXISTS zg_inquiries (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(254) NOT NULL, message TEXT NOT NULL, created DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
    'CREATE TABLE IF NOT EXISTS zg_limits (bucket CHAR(64) NOT NULL PRIMARY KEY, hits INT NOT NULL, expires BIGINT NOT NULL, INDEX (expires)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4',
];
foreach ($schema as $sql) { db()->exec($sql); }

if (q('SELECT id FROM zg_admins WHERE id = 1')->fetch()) {
    fail(403, 'Already installed. Delete setup.php from your hosting. Existing admin credentials cannot be replaced here.');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $provided = text_field('setup_key', 200, false);
        if (!hash_equals($key, $provided)) { usleep(500000); fail(403, 'Invalid setup key.'); }
        $username = text_field('username', 100);
        $password = text_field('password', 72, false);
        if (!preg_match('/^[A-Za-z0-9_.@-]{3,100}$/', $username) || strlen($password) < 16 || strlen($password) > 72) {
            throw new UserError('Use a username of 3-100 letters, numbers or _ . @ - and a password of 16-72 characters.');
        }
        $withSamples = ($_POST['samples'] ?? '') === 'yes';
        $pdo = db();
        $pdo->beginTransaction();
        try {
            q('INSERT INTO zg_admins (id, username, password, version) VALUES (1, ?, ?, 1)', [$username, password_hash($password, PASSWORD_DEFAULT)]);
            if ($withSamples) { seed_sample_data(); }
            $pdo->commit();
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            throw $ex;
        }
        flash('Setup complete. Now delete setup.php from your hosting, then sign in.');
        redirect('admin/login.php');
    } catch (UserError $ex) {
        $error = $ex->getMessage();
    }
}

$s = defaults();
page_header($s, 'Installation');
?>
<section class="section">
  <div class="wrap narrow">
    <p class="eyebrow eyebrow-dark">FIRST-TIME INSTALLATION</p>
    <h1 class="h1-sm">Set up your store</h1>
    <p class="muted">This creates the database tables and your administrator account. Run it once, then delete <strong>setup.php</strong>.</p>
    <?php if ($error !== ''): ?><p class="error" role="alert"><?= e($error) ?></p><?php endif; ?>
    <form class="form form-light" method="post">
      <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
      <label>Private setup key (from zorvo-config.php)<input type="password" name="setup_key" maxlength="200" autocomplete="off" required></label>
      <label>Choose an administrator username<input name="username" minlength="3" maxlength="100" autocomplete="username" required></label>
      <label>Choose an administrator password (16-72 characters)<input type="password" name="password" minlength="16" maxlength="72" autocomplete="new-password" required></label>
      <label class="check"><input type="checkbox" name="samples" value="yes" checked><span>Install sample categories and products so I can see how the store looks (removable in one click from the admin dashboard).</span></label>
      <button class="btn btn-navy" type="submit">Install store</button>
    </form>
  </div>
</section>
<?php page_footer($s);
