<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';
require __DIR__ . '/includes/layout.php';

$s = settings();
$slug = is_string($_GET['slug'] ?? null) ? substr($_GET['slug'], 0, 190) : '';
$p = q('SELECT p.*, c.name AS cat_name, c.slug AS cat_slug FROM zg_products p LEFT JOIN zg_categories c ON c.id = p.category_id WHERE p.slug = ? AND p.is_active = 1', [$slug])->fetch();

if (!$p) {
    http_response_code(404);
    page_header($s, 'Product not found');
    ?>
    <section class="section"><div class="wrap narrow"><h1 class="h1-sm">Product not found</h1><p class="muted">This product may have been removed or is no longer available.</p><p><a class="btn btn-navy" href="shop.php">Continue shopping</a></p></div></section>
    <?php
    page_footer($s);
    exit;
}

$img = safe_image($p['image']);
$stock = (int)$p['stock'];
$price = (int)$p['price_cents'];
$compare = (int)($p['compare_cents'] ?? 0);
$onSale = $compare > $price;
$maxQty = max(1, min(MAX_LINE_QTY, $stock));
$related = [];
if ($p['category_id'] !== null) {
    $related = q('SELECT * FROM zg_products WHERE is_active = 1 AND category_id = ? AND id <> ? ORDER BY id DESC LIMIT 4', [(int)$p['category_id'], (int)$p['id']])->fetchAll();
}

page_header($s, (string)$p['name'], (string)($p['short_desc'] ?? ''));
?>
<section class="section product-page">
  <div class="wrap">
    <nav class="crumbs" aria-label="Breadcrumb">
      <a href="index.php">Home</a> / <a href="shop.php">Shop</a>
      <?php if ($p['cat_slug'] !== null): ?> / <a href="shop.php?cat=<?= e(rawurlencode((string)$p['cat_slug'])) ?>"><?= e($p['cat_name']) ?></a><?php endif; ?>
    </nav>
    <div class="pdetail">
      <div class="pdetail-media">
        <?php if ($img !== ''): ?><img src="<?= e($img) ?>" alt="<?= e($p['name']) ?>" width="900" height="900"><?php else: ?><span class="noimg big">No image</span><?php endif; ?>
      </div>
      <div class="pdetail-info">
        <h1 class="h1-sm"><?= e($p['name']) ?></h1>
        <p class="price big"><span class="now"><?= e(money($price)) ?></span><?php if ($onSale): ?> <s class="was"><?= e(money($compare)) ?></s> <span class="badge badge-sale inline">Save <?= e(money($compare - $price)) ?></span><?php endif; ?></p>
        <?php if (!empty($p['short_desc'])): ?><p class="lead-dark"><?= e($p['short_desc']) ?></p><?php endif; ?>
        <?php if ($stock < 1): ?>
          <p class="stock out">Sold out</p>
        <?php else: ?>
          <p class="stock <?= $stock <= 5 ? 'low' : 'in' ?>"><?= $stock <= 5 ? 'Only ' . e((string)$stock) . ' left' : 'In stock' ?></p>
          <form class="buy" action="cart.php" method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="product_id" value="<?= e((string)$p['id']) ?>">
            <label class="qty">Quantity
              <input type="number" name="qty" value="1" min="1" max="<?= e((string)$maxQty) ?>" inputmode="numeric" required>
            </label>
            <button class="btn btn-gold" type="submit">Add to cart</button>
          </form>
        <?php endif; ?>
        <?php if (!empty($p['sku'])): ?><p class="meta">SKU: <?= e($p['sku']) ?></p><?php endif; ?>
        <?php if (trim((string)$p['description']) !== ''): ?>
          <div class="pdesc"><h2>Description</h2><p class="prose"><?= e($p['description']) ?></p></div>
        <?php endif; ?>
        <p class="meta"><a href="page.php?p=shipping">Shipping &amp; returns</a></p>
      </div>
    </div>
    <?php if ($related): ?>
      <div class="related"><h2>You may also like</h2><div class="pgrid"><?php foreach ($related as $r) { product_card($r); } ?></div></div>
    <?php endif; ?>
  </div>
</section>
<?php page_footer($s);
