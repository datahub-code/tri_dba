<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('index.php#contact'); }
if (limited('contact', 5, 3600)) { fail(429, 'Too many messages. Please try again later.'); }
if (!empty($_POST['website'])) { redirect('index.php#contact'); } // honeypot

try {
    $name    = text_field('name', 100);
    $email   = text_field('email', 254);
    $message = str_replace("\r", '', text_field('message', 4000));
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($message, 'UTF-8') < 10 || ($_POST['consent'] ?? '') !== 'yes') {
        throw new UserError('Please check your name, email address, message (at least 10 characters) and privacy consent.');
    }
    q('INSERT INTO zg_inquiries (name, email, message, created) VALUES (?, ?, ?, ?)', [$name, $email, $message, gmdate('Y-m-d H:i:s')]);
    flash('Thank you. Your message has been received and the team will review it.');
} catch (UserError $ex) {
    flash($ex->getMessage());
}
redirect('index.php#contact');
