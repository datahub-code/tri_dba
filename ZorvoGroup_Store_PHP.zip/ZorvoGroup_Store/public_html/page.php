<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';
require __DIR__ . '/includes/layout.php';

$s = settings();
$pages = ['privacy' => ['Privacy notice', 'privacy'], 'terms' => ['Terms of sale', 'terms'], 'shipping' => ['Shipping & returns', 'shipping_policy']];
$key = is_string($_GET['p'] ?? null) ? $_GET['p'] : '';
if (!isset($pages[$key])) { fail(404, 'Page not found.'); }
[$title, $settingKey] = $pages[$key];

page_header($s, $title);
?>
<section class="section legal-page">
  <div class="wrap narrow">
    <p class="eyebrow eyebrow-dark"><?= e($s['store_name']) ?></p>
    <h1><?= e($title) ?></h1>
    <div class="prose"><?= e($s[$settingKey]) ?></div>
    <p><a class="btn btn-navy" href="index.php">&larr; Back to store</a></p>
  </div>
</section>
<?php page_footer($s);
