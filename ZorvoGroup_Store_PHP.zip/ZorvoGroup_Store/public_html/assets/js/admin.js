(function () {
  document.querySelectorAll('form.confirm-form').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!window.confirm(form.getAttribute('data-confirm') || 'Are you sure?')) { e.preventDefault(); }
    });
  });
})();
