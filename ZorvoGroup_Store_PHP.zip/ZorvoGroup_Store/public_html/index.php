<?php
declare(strict_types=1);
define('ZG_APP', true);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/store.php';
require __DIR__ . '/includes/layout.php';

$s = settings();
$cats = q('SELECT id, name, slug, description, image FROM zg_categories ORDER BY sort_order, name LIMIT 8')->fetchAll();
$featured = q('SELECT * FROM zg_products WHERE is_active = 1 AND is_featured = 1 ORDER BY id DESC LIMIT 8')->fetchAll();
$featuredTitle = 'Featured products';
if (!$featured) {
    $featured = q('SELECT * FROM zg_products WHERE is_active = 1 ORDER BY id DESC LIMIT 8')->fetchAll();
    $featuredTitle = 'Latest products';
}
$freeOver = (int)$s['free_ship_over'];
$heroImg = safe_image($s['hero_image']) ?: 'assets/img/hero.jpg';
$aboutImg = safe_image($s['about_image']);
$hasContact = $s['contact_email'] !== '' || $s['contact_phone'] !== '' || $s['contact_address'] !== '';

page_header($s, (string)$s['tagline'], (string)$s['hero_text']);
?>
<section class="hero">
  <div class="wrap hero-grid">
    <div class="hero-copy">
      <p class="eyebrow"><?= e($s['hero_eyebrow']) ?></p>
      <h1><?= e($s['hero_title']) ?></h1>
      <p class="lead"><?= e($s['hero_text']) ?></p>
      <div class="hero-actions">
        <a class="btn btn-gold" href="shop.php">Shop now</a>
        <a class="btn btn-ghost" href="#categories">Browse categories</a>
      </div>
    </div>
    <div class="hero-media">
      <img src="<?= e($heroImg) ?>" alt="" width="1400" height="933" fetchpriority="high">
    </div>
  </div>
</section>

<section class="values" aria-label="Store highlights">
  <div class="wrap values-grid">
    <?php foreach ([$s['trust_1'], $s['trust_2'], $s['trust_3']] as $t): if (trim((string)$t) === '') { continue; } ?>
      <div class="value"><span class="tick" aria-hidden="true">&#10003;</span><?= e($t) ?></div>
    <?php endforeach; ?>
    <?php if ($freeOver > 0): ?><div class="value"><span class="tick" aria-hidden="true">&#10003;</span>Free shipping over <?= e(money($freeOver)) ?></div><?php endif; ?>
  </div>
</section>

<?php if ($cats): ?>
<section class="section" id="categories">
  <div class="wrap">
    <div class="section-head"><p class="eyebrow eyebrow-dark">SHOP BY CATEGORY</p><h2>Find what you need</h2></div>
    <div class="cat-grid">
      <?php foreach ($cats as $c): $ci = safe_image($c['image']); ?>
        <a class="cat-tile" href="shop.php?cat=<?= e(rawurlencode((string)$c['slug'])) ?>">
          <?php if ($ci !== ''): ?><img src="<?= e($ci) ?>" alt="" loading="lazy" width="700" height="500"><?php endif; ?>
          <span class="cat-name"><?= e($c['name']) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="section tint" id="featured">
  <div class="wrap">
    <div class="section-head row"><div><p class="eyebrow eyebrow-dark">OUR PICKS</p><h2><?= e($featuredTitle) ?></h2></div><a class="btn btn-navy btn-sm" href="shop.php">View all products</a></div>
    <?php if ($featured): ?>
      <div class="pgrid"><?php foreach ($featured as $p) { product_card($p); } ?></div>
    <?php else: ?>
      <p class="muted">Products are coming soon. Please check back shortly.</p>
    <?php endif; ?>
  </div>
</section>

<section class="section about" id="about">
  <div class="wrap split">
    <?php if ($aboutImg !== ''): ?><div class="split-media"><img src="<?= e($aboutImg) ?>" alt="" width="1400" height="933" loading="lazy"></div><?php endif; ?>
    <div class="split-copy">
      <p class="eyebrow eyebrow-dark">ABOUT US</p>
      <h2><?= e($s['about_title']) ?></h2>
      <p class="prose"><?= e($s['about_text']) ?></p>
      <a class="btn btn-navy" href="shop.php">Start shopping</a>
    </div>
  </div>
</section>

<section class="section contact" id="contact">
  <div class="wrap contact-grid">
    <div class="contact-copy">
      <p class="eyebrow">CONTACT</p>
      <h2>Questions? We're here.</h2>
      <p class="lead">Send us a message and our team will review it.</p>
      <?php if ($hasContact): ?>
      <ul class="contact-list">
        <?php if ($s['contact_email'] !== ''): ?><li><span>Email</span><a href="mailto:<?= e($s['contact_email']) ?>"><?= e($s['contact_email']) ?></a></li><?php endif; ?>
        <?php if ($s['contact_phone'] !== ''): ?><li><span>Phone</span><?= e($s['contact_phone']) ?></li><?php endif; ?>
        <?php if ($s['contact_address'] !== ''): ?><li><span>Address</span><?= e($s['contact_address']) ?></li><?php endif; ?>
      </ul>
      <?php endif; ?>
    </div>
    <form class="form" action="contact.php" method="post">
      <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
      <label>Your name<input name="name" autocomplete="name" maxlength="100" required></label>
      <label>Email address<input type="email" name="email" autocomplete="email" maxlength="254" required></label>
      <label>Message<textarea name="message" rows="5" minlength="10" maxlength="4000" required></textarea></label>
      <div class="trap" aria-hidden="true"><label>Leave this empty<input name="website" tabindex="-1" autocomplete="off"></label></div>
      <label class="check"><input type="checkbox" name="consent" value="yes" required><span>I agree to the <a href="page.php?p=privacy">privacy notice</a> and to my message being stored so the team can reply.</span></label>
      <button class="btn btn-gold" type="submit">Send message</button>
      <p class="form-note">Please do not include payment card numbers or other sensitive information.</p>
    </form>
  </div>
</section>
<?php page_footer($s);
