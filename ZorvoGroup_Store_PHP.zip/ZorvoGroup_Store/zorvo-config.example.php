<?php
// 1) Rename this file to  zorvo-config.php
// 2) Keep it in the folder that CONTAINS public_html (NOT inside public_html).
// 3) Fill in the values from hPanel > Databases > MySQL Databases.
return [
    'db_host'     => 'localhost',
    'db_port'     => 3306,
    'db_name'     => 'YOUR_FULL_DATABASE_NAME',      // e.g. u123456789_zorvo
    'db_user'     => 'YOUR_FULL_DATABASE_USER',      // e.g. u123456789_admin
    'db_password' => 'YOUR_DATABASE_PASSWORD',

    // A private random code of 32+ characters that protects setup.php.
    // Generate one in a password manager. It is NOT your admin password.
    'setup_key'   => 'REPLACE_WITH_YOUR_OWN_RANDOM_CODE_OF_32_OR_MORE_CHARACTERS',

    // Keep true on the live website (requires HTTPS).
    'require_https' => true,
];
