require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// ── Alpaca credentials from .env ──
const ALPACA_KEY    = process.env.ALPACA_KEY_ID;
const ALPACA_SECRET = process.env.ALPACA_SECRET_KEY;
const DATA_URL      = process.env.ALPACA_DATA_URL || 'https://data.alpaca.markets/v2';

const HEADERS = {
  'APCA-API-KEY-ID':     ALPACA_KEY,
  'APCA-API-SECRET-KEY': ALPACA_SECRET,
  'Accept':              'application/json'
};

// ── Simple in-memory cache (avoid hammering Alpaca on 3s frontend polling) ──
const indicatorCache = {};  // { 'AAPL': { data: {...}, ts: Date.now() } }
const CACHE_TTL = 30000;    // 30 seconds — 5min bars don't change faster than this

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// ════════════════════════════════════════════════════════
// TECHNICAL INDICATOR MATH
// ════════════════════════════════════════════════════════

function emaCalc(data, period) {
  const k = 2 / (period + 1);
  const result = [data[0]];
  for (let i = 1; i < data.length; i++) {
    result.push(data[i] * k + result[i - 1] * (1 - k));
  }
  return result;
}

function smaCalc(data, period) {
  const result = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) { result.push(null); continue; }
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += data[j];
    result.push(sum / period);
  }
  return result;
}

function calcRSI(closes, period = 14) {
  if (closes.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff > 0) gains += diff; else losses -= diff;
  }
  let avgGain = gains / period;
  let avgLoss = losses / period;
  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    avgGain = (avgGain * (period - 1) + (diff > 0 ? diff : 0)) / period;
    avgLoss = (avgLoss * (period - 1) + (diff < 0 ? -diff : 0)) / period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function calcMACD(closes) {
  if (closes.length < 26) return { line: 0, signal: 0, hist: 0 };
  const ema12 = emaCalc(closes, 12);
  const ema26 = emaCalc(closes, 26);
  const macdLine = ema12.map((v, i) => v - ema26[i]);
  const signalLine = emaCalc(macdLine, 9);
  const last = closes.length - 1;
  return {
    line: macdLine[last],
    signal: signalLine[last],
    hist: macdLine[last] - signalLine[last]
  };
}

function calcADX(highs, lows, closes, period = 14) {
  if (highs.length < period * 2) return 20;
  const trueRanges = [], plusDM = [], minusDM = [];
  for (let i = 1; i < highs.length; i++) {
    const hl = highs[i] - lows[i];
    const hpc = Math.abs(highs[i] - closes[i - 1]);
    const lpc = Math.abs(lows[i] - closes[i - 1]);
    trueRanges.push(Math.max(hl, hpc, lpc));
    const upMove = highs[i] - highs[i - 1];
    const downMove = lows[i - 1] - lows[i];
    plusDM.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDM.push(downMove > upMove && downMove > 0 ? downMove : 0);
  }
  let atr = trueRanges.slice(0, period).reduce((a, b) => a + b, 0);
  let aPlusDM = plusDM.slice(0, period).reduce((a, b) => a + b, 0);
  let aMinusDM = minusDM.slice(0, period).reduce((a, b) => a + b, 0);
  const dxValues = [];
  for (let i = period; i < trueRanges.length; i++) {
    atr = atr - atr / period + trueRanges[i];
    aPlusDM = aPlusDM - aPlusDM / period + plusDM[i];
    aMinusDM = aMinusDM - aMinusDM / period + minusDM[i];
    const plusDI = (aPlusDM / atr) * 100;
    const minusDI = (aMinusDM / atr) * 100;
    const diSum = plusDI + minusDI;
    dxValues.push(diSum === 0 ? 0 : Math.abs(plusDI - minusDI) / diSum * 100);
  }
  if (dxValues.length < period) return dxValues.length > 0 ? dxValues[dxValues.length - 1] : 20;
  let adx = dxValues.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < dxValues.length; i++) {
    adx = (adx * (period - 1) + dxValues[i]) / period;
  }
  return adx;
}

function calcStochastic(highs, lows, closes, kPeriod = 14, dPeriod = 3) {
  if (closes.length < kPeriod) return { k: 50, d: 50 };
  const kValues = [];
  for (let i = kPeriod - 1; i < closes.length; i++) {
    const highSlice = highs.slice(i - kPeriod + 1, i + 1);
    const lowSlice = lows.slice(i - kPeriod + 1, i + 1);
    const hh = Math.max(...highSlice);
    const ll = Math.min(...lowSlice);
    kValues.push(hh === ll ? 50 : ((closes[i] - ll) / (hh - ll)) * 100);
  }
  const dValues = smaCalc(kValues, dPeriod);
  return {
    k: Math.round(kValues[kValues.length - 1]),
    d: Math.round(dValues[dValues.length - 1] || kValues[kValues.length - 1])
  };
}

function calcVWAP(highs, lows, closes, volumes) {
  let cumVol = 0, cumTP = 0;
  for (let i = 0; i < closes.length; i++) {
    const tp = (highs[i] + lows[i] + closes[i]) / 3;
    cumVol += volumes[i];
    cumTP += tp * volumes[i];
  }
  return cumVol === 0 ? closes[closes.length - 1] : cumTP / cumVol;
}

// ════════════════════════════════════════════════════════
// FETCH BARS FROM ALPACA
// ════════════════════════════════════════════════════════

async function fetchBars(symbol, timeframe = '5Min', limit = 200) {
  // Calculate start date: go back enough calendar days to cover the requested bars
  const now = new Date();
  let daysBack = 10; // default for 5min (covers weekends + holidays)
  if (timeframe === '1Hour') daysBack = 30;
  if (timeframe === '1Day')  daysBack = 365;
  const start = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
  const startISO = start.toISOString();

  // Use sort=desc to get the LATEST bars first, then reverse for chronological order
  const url = `${DATA_URL}/stocks/${symbol}/bars?timeframe=${timeframe}&limit=${limit}&start=${startISO}&adjustment=raw&sort=desc`;
  console.log(`[fetchBars] ${symbol} ${timeframe} limit=${limit}`);
  const res = await fetch(url, { headers: HEADERS });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Alpaca API error ${res.status}: ${errText}`);
  }
  const data = await res.json();
  const bars = (data.bars || []).reverse(); // oldest → newest for indicator math
  console.log(`[fetchBars] ${symbol} ${timeframe} → ${bars.length} bars (latest: ${bars.length ? bars[bars.length-1].t : 'none'})`);
  return bars;
}

// ════════════════════════════════════════════════════════
// API: GET /api/indicators/:symbol
// ════════════════════════════════════════════════════════

app.get('/api/indicators/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol.toUpperCase();

    // Timeframe from query: 1, 5, 15, 30, 60, 240 (minutes)
    const tfMinutes = parseInt(req.query.tf) || 5;
    const tfMap = { 1: '1Min', 5: '5Min', 15: '15Min', 30: '30Min', 60: '1Hour', 240: '4Hour' };
    const alpacaTF = tfMap[tfMinutes] || '5Min';
    // How many bars to fetch (more for smaller timeframes)
    const barLimit = tfMinutes <= 5 ? 500 : tfMinutes <= 30 ? 300 : 500;
    // Days back for start date
    const daysBack = tfMinutes <= 5 ? 10 : tfMinutes <= 30 ? 20 : 60;
    // HTF for trend analysis (one step above selected tf)
    const htfTFMap = { 1: '5Min', 5: '1Hour', 15: '1Hour', 30: '1Hour', 60: '4Hour', 240: '1Day' };
    const htfTF = htfTFMap[tfMinutes] || '1Hour';

    console.log(`[API] ${symbol} tf=${tfMinutes}min → bars=${alpacaTF}, htf=${htfTF}`);

    // Check cache (key includes timeframe)
    const cacheKey = `${symbol}_${tfMinutes}`;
    const cached = indicatorCache[cacheKey];
    if (cached && (Date.now() - cached.ts) < CACHE_TTL) {
      return res.json(cached.data);
    }

    const [rawBars, htfBars] = await Promise.all([
      fetchBars(symbol, alpacaTF, barLimit),
      fetchBars(symbol, htfTF, 100)
    ]);

    // ── Filter to Regular Trading Hours only (9:30 AM – 4:00 PM ET) ──
    // Extended hours bars have near-zero movement which corrupts ADX/RSI/MACD
    const bars5m = rawBars.filter(b => {
      const d = new Date(b.t);
      // Convert UTC → ET (EST = UTC-5, EDT = UTC-4)
      // Use simple approach: check if US daylight saving is active
      const month = d.getUTCMonth(); // 0-indexed
      const isDST = month >= 2 && month <= 10; // Mar-Nov rough DST
      const etHour = d.getUTCHours() - (isDST ? 4 : 5);
      const etMin  = d.getUTCMinutes();
      const etTime = etHour + etMin / 60;
      // RTH = 9:30 AM (9.5) to 4:00 PM (16.0) ET
      return etTime >= 9.5 && etTime < 16;
    });

    console.log(`[RTH filter] ${symbol} ${alpacaTF}: ${rawBars.length} raw → ${bars5m.length} RTH bars`);

    if (!bars5m.length) {
      return res.json({ error: 'No regular-hours bar data available. Market may be closed.', stale: true });
    }

    const highs   = bars5m.map(b => b.h);
    const lows    = bars5m.map(b => b.l);
    const closes  = bars5m.map(b => b.c);
    const volumes = bars5m.map(b => b.v);

    const lastPrice = closes[closes.length - 1];
    const lastBar   = bars5m[bars5m.length - 1];

    // ── Compute indicators ──
    const rsi       = calcRSI(closes, 14);
    const macd      = calcMACD(closes);
    const stoch     = calcStochastic(highs, lows, closes, 14, 3);
    const vwap      = calcVWAP(highs, lows, closes, volumes);
    const ema9vals  = emaCalc(closes, 9);
    const ema21vals = emaCalc(closes, 21);
    const ema9      = ema9vals[ema9vals.length - 1];
    const ema21     = ema21vals[ema21vals.length - 1];

    // ── ADX from the SAME timeframe bars (so it changes per TF selection) ──
    let adx = 20; // default
    if (highs.length >= 30) {
      adx = calcADX(highs, lows, closes, 14);
    }
    console.log(`[Indicators] ${symbol}: ADX(${alpacaTF})=${adx.toFixed(1)} RSI=${rsi.toFixed(1)} MACD=${macd.hist.toFixed(4)}`);

    // Volume ratio
    const recentVols = volumes.slice(-20);
    const avgVol = recentVols.reduce((a, b) => a + b, 0) / recentVols.length;
    const lastVol = volumes[volumes.length - 1];
    const volRatio = avgVol > 0 ? lastVol / avgVol : 1;
    const volIncreasing = volumes.length >= 3 && volumes[volumes.length - 1] > volumes[volumes.length - 2];

    // ── ATR (Average True Range) — realistic stop/target sizing per timeframe ──
    let atr = 0;
    if (highs.length >= 3) {
      const trList = [];
      for (let i = 1; i < highs.length; i++) {
        const tr = Math.max(
          highs[i] - lows[i],
          Math.abs(highs[i] - closes[i - 1]),
          Math.abs(lows[i] - closes[i - 1])
        );
        trList.push(tr);
      }
      // ATR-14: smoothed average (or simple average if fewer bars)
      const atrPeriod = Math.min(14, trList.length);
      let atrSum = trList.slice(0, atrPeriod).reduce((a, b) => a + b, 0);
      let atrVal = atrSum / atrPeriod;
      for (let i = atrPeriod; i < trList.length; i++) {
        atrVal = (atrVal * (atrPeriod - 1) + trList[i]) / atrPeriod;
      }
      atr = atrVal;
    }
    // Suggested stop = 1.5 × ATR (tight enough for the timeframe, wide enough to avoid noise)
    const suggestedStop = +(atr * 1.5).toFixed(2);
    // Suggested targets: T1 = 1.5×ATR (1:1), T2 = 3×ATR (2:1)
    const suggestedT1   = +(atr * 1.5).toFixed(2);
    const suggestedT2   = +(atr * 3.0).toFixed(2);
    console.log(`[ATR] ${symbol} ${alpacaTF}: ATR=${atr.toFixed(4)} → stop=$${suggestedStop} t1=$${suggestedT1} t2=$${suggestedT2}`);

    // Candle analysis
    const bodySize = Math.abs(lastBar.c - lastBar.o);
    const totalRange = lastBar.h - lastBar.l;
    const strongCandle = totalRange > 0 && (bodySize / totalRange) > 0.5;
    const bullCandle = lastBar.c > lastBar.o;

    // Opening Range (first 30 min of the most recent trading day)
    // Group bars by date, pick the latest date
    const barsByDate = {};
    bars5m.forEach(b => {
      const dateKey = b.t.slice(0, 10);
      if (!barsByDate[dateKey]) barsByDate[dateKey] = [];
      barsByDate[dateKey].push(b);
    });
    const tradingDates = Object.keys(barsByDate).sort();
    const latestDate = tradingDates[tradingDates.length - 1];
    const latestDayBars = barsByDate[latestDate] || [];
    // Number of bars in 30-min OR depends on timeframe
    const orBarCount = Math.max(1, Math.ceil(30 / tfMinutes));
    const orBars = latestDayBars.slice(0, orBarCount);
    let orHigh, orLow;
    if (orBars.length > 0) {
      orHigh = Math.max(...orBars.map(b => b.h));
      orLow  = Math.min(...orBars.map(b => b.l));
    } else {
      orHigh = lastPrice + 1;
      orLow  = lastPrice - 1;
    }

    // HTF analysis (using higher timeframe bars)
    let htfBull = true;
    if (htfBars.length >= 21) {
      const htfCloses1h = htfBars.map(b => b.c);
      const htfEma9  = emaCalc(htfCloses1h, 9);
      const htfEma21 = emaCalc(htfCloses1h, 21);
      htfBull = htfEma9[htfEma9.length - 1] > htfEma21[htfEma21.length - 1];
    }

    // Consolidation check
    const last5 = bars5m.slice(-5);
    const last5Range = Math.max(...last5.map(b => b.h)) - Math.min(...last5.map(b => b.l));
    const avgRange = bars5m.slice(-20).reduce((s, b) => s + (b.h - b.l), 0) / 20;
    const consolidated = last5Range < avgRange * 2.5;

    // RSI divergence
    let divergence = false;
    if (closes.length >= 24) {
      const rsiNow  = calcRSI(closes, 14);
      const rsiBack = calcRSI(closes.slice(0, -10), 14);
      const priceNow  = closes[closes.length - 1];
      const priceBack = closes[closes.length - 11];
      if (priceNow > priceBack && rsiNow < rsiBack - 5) divergence = true;
      if (priceNow < priceBack && rsiNow > rsiBack + 5) divergence = true;
    }

    // ── ADX thresholds scale with timeframe (lower TFs have naturally lower ADX) ──
    const adxThresholds = {
      1:   { low: 8,  high: 15 },
      5:   { low: 10, high: 18 },
      15:  { low: 11, high: 20 },
      30:  { low: 12, high: 22 },
      60:  { low: 15, high: 25 },
      240: { low: 18, high: 30 }
    };
    const adxTH = adxThresholds[tfMinutes] || { low: 15, high: 25 };

    // ── Determine mode ──
    const vwapAbove = lastPrice > vwap;
    const emaBull = ema9 > ema21;
    const macdBull = macd.hist > 0;

    let mode = 'wait';
    const bullSignals = [vwapAbove, emaBull, macdBull, rsi > 50, adx >= adxTH.low].filter(Boolean).length;
    const bearSignals = [!vwapAbove, !emaBull, !macdBull, rsi < 50, adx >= adxTH.low].filter(Boolean).length;

    if (adx < adxTH.low) {
      mode = 'dead';
    } else if (bullSignals >= 4 && lastPrice > orHigh) {
      mode = 'long';
    } else if (bearSignals >= 4) {
      mode = 'short';
    }

    const result = {
      symbol,
      timeframe: tfMinutes,
      lastPrice: +lastPrice.toFixed(2),
      timestamp: lastBar.t,
      stale: false,
      mode,
      adxThresholds: adxTH,
      atr:           +atr.toFixed(4),
      suggestedStop: suggestedStop,
      suggestedT1:   suggestedT1,
      suggestedT2:   suggestedT2,
      indicators: {
        adx:         +adx.toFixed(1),
        rsi:         +rsi.toFixed(1),
        macdBull,
        macdHist:    +macd.hist.toFixed(4),
        macdLine:    +macd.line.toFixed(4),
        macdSignal:  +macd.signal.toFixed(4),
        stochK:      stoch.k,
        stochD:      stoch.d,
        vwapAbove,
        vwapVal:     +vwap.toFixed(2),
        emaBull,
        ema9:        +ema9.toFixed(2),
        ema21:       +ema21.toFixed(2),
        volume:      +volRatio.toFixed(2),
        volInc:      volIncreasing,
        strongCandle,
        bullCandle,
        htfBull,
        consolidated,
        divergence,
        orHigh:      +orHigh.toFixed(2),
        orLow:       +orLow.toFixed(2)
      }
    };

    // Cache the result (keyed by symbol+timeframe)
    indicatorCache[cacheKey] = { data: result, ts: Date.now() };
    res.json(result);

  } catch (err) {
    console.error('Indicator API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
// API: GET /api/bars/:symbol — raw OHLCV + RSI + SMA for charting
// ════════════════════════════════════════════════════════
const barsCache = {};
const BARS_CACHE_TTL = 10000;  // 10s — keep main chart responsive during market hours

app.get('/api/bars/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol.toUpperCase();
    const tfMinutes = parseInt(req.query.tf) || 5;
    const tfMap = { 1:'1Min', 5:'5Min', 15:'15Min', 30:'30Min', 60:'1Hour', 240:'4Hour' };
    const alpacaTF = tfMap[tfMinutes] || '5Min';
    // More bars for lower TFs to get enough multi-day data after RTH filter
    const barLimit = tfMinutes <= 1 ? 500 : tfMinutes <= 5 ? 500 : tfMinutes <= 15 ? 400 : 200;
    const daysBack = tfMinutes <= 1 ? 5 : tfMinutes <= 5 ? 10 : tfMinutes <= 60 ? 60 : 365;

    const cacheKey = `bars_${symbol}_${tfMinutes}`;
    const cached = barsCache[cacheKey];
    if (cached && (Date.now() - cached.ts) < BARS_CACHE_TTL) {
      return res.json(cached.data);
    }

    const now = new Date();
    const start = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
    const url = `${DATA_URL}/stocks/${symbol}/bars?timeframe=${alpacaTF}&limit=${barLimit}&start=${start.toISOString()}&adjustment=raw&sort=desc`;
    const apiRes = await fetch(url, { headers: HEADERS });
    if (!apiRes.ok) throw new Error(`Alpaca ${apiRes.status}`);
    const raw = await apiRes.json();
    const bars = (raw.bars || []).reverse();

    // Filter RTH
    const rthBars = bars.filter(b => {
      const d = new Date(b.t);
      const month = d.getUTCMonth();
      const isDST = month >= 2 && month <= 10;
      const etHour = d.getUTCHours() - (isDST ? 4 : 5);
      const etMin  = d.getUTCMinutes();
      const etTime = etHour + etMin / 60;
      return etTime >= 9.5 && etTime < 16;
    });

    if (!rthBars.length) {
      return res.json({ bars: [], rsi: [], sma20: [], sma9: [], vwap: [], macdLine: [], macdSignal: [], macdHist: [] });
    }

    const closes  = rthBars.map(b => b.c);
    const highs   = rthBars.map(b => b.h);
    const lows    = rthBars.map(b => b.l);
    const volumes = rthBars.map(b => b.v);

    // RSI series (14-period, for each bar)
    const rsiSeries = [];
    for (let i = 0; i < closes.length; i++) {
      if (i < 14) { rsiSeries.push(null); continue; }
      const slice = closes.slice(0, i + 1);
      rsiSeries.push(+calcRSI(slice, 14).toFixed(1));
    }

    // SMA-9 and SMA-20 series
    const sma9  = smaCalc(closes, 9).map(v => v !== null ? +v.toFixed(2) : null);
    const sma20 = smaCalc(closes, 20).map(v => v !== null ? +v.toFixed(2) : null);

    // ── VWAP series (resets each trading day for intraday TFs, continuous for higher TFs) ──
    const vwapSeries = [];
    let vCumVol = 0, vCumTP = 0, prevDate = '';
    const resetVwapDaily = tfMinutes <= 30;  // only reset VWAP daily for ≤30min TFs
    for (let i = 0; i < rthBars.length; i++) {
      if (resetVwapDaily) {
        const dateKey = rthBars[i].t.slice(0, 10);
        if (dateKey !== prevDate) { vCumVol = 0; vCumTP = 0; prevDate = dateKey; }
      }
      const tp = (highs[i] + lows[i] + closes[i]) / 3;
      vCumVol += volumes[i];
      vCumTP  += tp * volumes[i];
      vwapSeries.push(vCumVol === 0 ? +closes[i].toFixed(2) : +(vCumTP / vCumVol).toFixed(2));
    }

    // ── MACD series (12, 26, 9) ──
    const ema12 = emaCalc(closes, 12);
    const ema26 = emaCalc(closes, 26);
    const macdLineArr = ema12.map((v, i) => v - ema26[i]);
    const macdSignalArr = emaCalc(macdLineArr, 9);
    const macdLineSeries   = macdLineArr.map(v => +v.toFixed(4));
    const macdSignalSeries = macdSignalArr.map(v => +v.toFixed(4));
    const macdHistSeries   = macdLineArr.map((v, i) => +((v - macdSignalArr[i]).toFixed(4)));

    // Format bars for lightweight-charts
    // Use sequential business-time to eliminate overnight/weekend gaps
    // Strategy: keep timestamps within each day, but stitch days together seamlessly
    const chartBars = [];
    let prevDayEnd = null;
    const intervalSec = tfMinutes * 60;
    
    for (let i = 0; i < rthBars.length; i++) {
      const b = rthBars[i];
      const realTime = Math.floor(new Date(b.t).getTime() / 1000);
      
      let chartTime;
      if (i === 0) {
        chartTime = realTime;
      } else {
        const prevTime = chartBars[i - 1].time;
        const gap = realTime - Math.floor(new Date(rthBars[i - 1].t).getTime() / 1000);
        
        // If gap is larger than 2x the interval, it's an overnight/weekend gap — compress it
        if (gap > intervalSec * 2) {
          chartTime = prevTime + intervalSec;  // just advance by 1 bar width
        } else {
          chartTime = prevTime + gap;  // keep natural spacing within the day
        }
      }
      
      chartBars.push({
        time: chartTime,
        open: +b.o.toFixed(2),
        high: +b.h.toFixed(2),
        low:  +b.l.toFixed(2),
        close: +b.c.toFixed(2),
        volume: b.v,
        realTime: b.t  // keep original for tooltip reference
      });
    }

    const result = { bars: chartBars, rsi: rsiSeries, sma9, sma20, vwap: vwapSeries, macdLine: macdLineSeries, macdSignal: macdSignalSeries, macdHist: macdHistSeries };
    barsCache[cacheKey] = { data: result, ts: Date.now() };
    res.json(result);
  } catch (err) {
    console.error('Bars API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
// API: GET /api/bars-all/:symbol — ALL 6 TFs in one response (for synced MTF charts)
// ════════════════════════════════════════════════════════
const ALL_TFS = [1, 5, 15, 30, 60, 240];

app.get('/api/bars-all/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol.toUpperCase();
    const tfMap = { 1:'1Min', 5:'5Min', 15:'15Min', 30:'30Min', 60:'1Hour', 240:'4Hour' };

    // Fetch all 6 TFs in parallel (use cache where available)
    const results = {};
    await Promise.all(ALL_TFS.map(async (tfMin) => {
      const cacheKey = `bars_${symbol}_${tfMin}`;
      const cached = barsCache[cacheKey];
      if (cached && (Date.now() - cached.ts) < BARS_CACHE_TTL) {
        results[tfMin] = cached.data;
        return;
      }

      const alpacaTF = tfMap[tfMin];
      const barLimit = tfMin <= 1 ? 500 : tfMin <= 5 ? 500 : tfMin <= 15 ? 400 : 200;
      const daysBack = tfMin <= 1 ? 5 : tfMin <= 5 ? 10 : tfMin <= 60 ? 60 : 365;
      const now = new Date();
      const start = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
      const url = `${DATA_URL}/stocks/${symbol}/bars?timeframe=${alpacaTF}&limit=${barLimit}&start=${start.toISOString()}&adjustment=raw&sort=desc`;

      try {
        const apiRes = await fetch(url, { headers: HEADERS });
        if (!apiRes.ok) { results[tfMin] = { bars: [], rsi: [], sma9: [], sma20: [] }; return; }
        const raw = await apiRes.json();
        const bars = (raw.bars || []).reverse();

        const rthBars = bars.filter(b => {
          const d = new Date(b.t);
          const month = d.getUTCMonth();
          const isDST = month >= 2 && month <= 10;
          const etHour = d.getUTCHours() - (isDST ? 4 : 5);
          const etMin  = d.getUTCMinutes();
          const etTime = etHour + etMin / 60;
          return etTime >= 9.5 && etTime < 16;
        });

        if (!rthBars.length) { results[tfMin] = { bars: [], rsi: [], sma9: [], sma20: [] }; return; }

        const closes = rthBars.map(b => b.c);
        const rsiSeries = [];
        for (let i = 0; i < closes.length; i++) {
          if (i < 14) { rsiSeries.push(null); continue; }
          rsiSeries.push(+calcRSI(closes.slice(0, i + 1), 14).toFixed(1));
        }
        const sma9  = smaCalc(closes, 9).map(v => v !== null ? +v.toFixed(2) : null);
        const sma20 = smaCalc(closes, 20).map(v => v !== null ? +v.toFixed(2) : null);

        const chartBars = [];
        const intervalSec = tfMin * 60;
        for (let i = 0; i < rthBars.length; i++) {
          const b = rthBars[i];
          const realTime = Math.floor(new Date(b.t).getTime() / 1000);
          let chartTime;
          if (i === 0) { chartTime = realTime; }
          else {
            const prevTime = chartBars[i - 1].time;
            const gap = realTime - Math.floor(new Date(rthBars[i - 1].t).getTime() / 1000);
            chartTime = gap > intervalSec * 2 ? prevTime + intervalSec : prevTime + gap;
          }
          chartBars.push({ time: chartTime, open: +b.o.toFixed(2), high: +b.h.toFixed(2), low: +b.l.toFixed(2), close: +b.c.toFixed(2), volume: b.v });
        }

        const tfResult = { bars: chartBars, rsi: rsiSeries, sma9, sma20 };
        barsCache[cacheKey] = { data: tfResult, ts: Date.now() };
        results[tfMin] = tfResult;
      } catch (e) {
        results[tfMin] = { bars: [], rsi: [], sma9: [], sma20: [] };
      }
    }));

    res.json(results);
  } catch (err) {
    console.error('Bars-all API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ════════════════════════════════════════════════════════
// API: GET /api/snapshot/:symbol — real-time price from Alpaca latest trade + minuteBar
// No caching — this must be as fresh as possible
// ════════════════════════════════════════════════════════
app.get('/api/snapshot/:symbol', async (req, res) => {
  try {
    const symbol = req.params.symbol.toUpperCase();
    const url = `${DATA_URL}/stocks/${symbol}/snapshot`;
    const apiRes = await fetch(url, { headers: HEADERS });
    if (!apiRes.ok) throw new Error(`Alpaca snapshot ${apiRes.status}`);
    const snap = await apiRes.json();

    const trade = snap.latestTrade || {};
    const mBar  = snap.minuteBar || {};
    const dBar  = snap.dailyBar || {};
    const prevDBar = snap.prevDailyBar || {};

    res.json({
      symbol,
      price:     trade.p || mBar.c || 0,
      tradeTime: trade.t || null,
      minuteBar: mBar.t ? {
        time: mBar.t,
        open: mBar.o, high: mBar.h, low: mBar.l, close: mBar.c, volume: mBar.v
      } : null,
      dailyBar: dBar.t ? {
        open: dBar.o, high: dBar.h, low: dBar.l, close: dBar.c, volume: dBar.v
      } : null,
      prevClose: prevDBar.c || null,
    });
  } catch (err) {
    console.error('Snapshot API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Health check ──
app.get('/api/status', (req, res) => {
  res.json({ status: 'running', timestamp: new Date().toISOString() });
});

// Catch-all
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n  ⚡ Trading Command Center is live!`);
  console.log(`  ➜ Open: http://localhost:${PORT}`);
  console.log(`  ➜ Alpaca: Paper account connected`);
  console.log(`  ➜ API:  http://localhost:${PORT}/api/indicators/SPY\n`);
});
